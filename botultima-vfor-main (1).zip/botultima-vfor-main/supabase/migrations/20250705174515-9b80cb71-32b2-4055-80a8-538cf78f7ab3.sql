
-- Create security audit log table
CREATE TABLE IF NOT EXISTS public.security_audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  event_type text NOT NULL,
  ip_address inet,
  user_agent text,
  details jsonb DEFAULT '{}',
  created_at timestamp with time zone DEFAULT now()
);

-- Create rate limiting table
CREATE TABLE IF NOT EXISTS public.rate_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  identifier text NOT NULL, -- IP address or user ID
  endpoint text NOT NULL,
  attempts integer DEFAULT 1,
  blocked_until timestamp with time zone,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  UNIQUE(identifier, endpoint)
);

-- Create password reset tokens table
CREATE TABLE IF NOT EXISTS public.password_reset_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  token_hash text NOT NULL UNIQUE,
  expires_at timestamp with time zone NOT NULL,
  used boolean DEFAULT false,
  created_at timestamp with time zone DEFAULT now()
);

-- Create 2FA tokens table
CREATE TABLE IF NOT EXISTS public.two_factor_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  token_hash text NOT NULL,
  expires_at timestamp with time zone NOT NULL,
  verified boolean DEFAULT false,
  created_at timestamp with time zone DEFAULT now()
);

-- Create encrypted user data table
CREATE TABLE IF NOT EXISTS public.encrypted_user_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  data_type text NOT NULL,
  encrypted_data text NOT NULL,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  UNIQUE(user_id, data_type)
);

-- Enable RLS on all new tables
ALTER TABLE public.security_audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rate_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.password_reset_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.two_factor_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.encrypted_user_data ENABLE ROW LEVEL SECURITY;

-- RLS policies for security audit logs (admin only)
CREATE POLICY "Admin can view audit logs" ON public.security_audit_logs
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- RLS policies for rate limits (system use only)
CREATE POLICY "System can manage rate limits" ON public.rate_limits
  FOR ALL USING (true);

-- RLS policies for password reset tokens
CREATE POLICY "Users can view their own reset tokens" ON public.password_reset_tokens
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "System can manage reset tokens" ON public.password_reset_tokens
  FOR ALL USING (true);

-- RLS policies for 2FA tokens
CREATE POLICY "Users can view their own 2FA tokens" ON public.two_factor_tokens
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "System can manage 2FA tokens" ON public.two_factor_tokens
  FOR ALL USING (true);

-- RLS policies for encrypted user data
CREATE POLICY "Users can manage their own encrypted data" ON public.encrypted_user_data
  FOR ALL USING (auth.uid() = user_id);

-- Function to clean up expired tokens
CREATE OR REPLACE FUNCTION public.cleanup_expired_tokens()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  DELETE FROM public.password_reset_tokens 
  WHERE expires_at < now() OR used = true;
  
  DELETE FROM public.two_factor_tokens 
  WHERE expires_at < now();
  
  DELETE FROM public.rate_limits 
  WHERE blocked_until < now() AND blocked_until IS NOT NULL;
END;
$$;

-- Function to log security events
CREATE OR REPLACE FUNCTION public.log_security_event(
  p_user_id uuid,
  p_event_type text,
  p_ip_address inet,
  p_user_agent text,
  p_details jsonb DEFAULT '{}'
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.security_audit_logs (
    user_id, event_type, ip_address, user_agent, details
  ) VALUES (
    p_user_id, p_event_type, p_ip_address, p_user_agent, p_details
  );
END;
$$;

-- Function to check rate limit
CREATE OR REPLACE FUNCTION public.check_rate_limit(
  p_identifier text,
  p_endpoint text,
  p_max_attempts integer DEFAULT 5,
  p_window_minutes integer DEFAULT 15
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_attempts integer;
  is_blocked boolean;
BEGIN
  -- Check if currently blocked
  SELECT EXISTS (
    SELECT 1 FROM public.rate_limits 
    WHERE identifier = p_identifier 
    AND endpoint = p_endpoint 
    AND blocked_until > now()
  ) INTO is_blocked;
  
  IF is_blocked THEN
    RETURN false;
  END IF;

  -- Get or create rate limit record
  INSERT INTO public.rate_limits (identifier, endpoint, attempts, updated_at)
  VALUES (p_identifier, p_endpoint, 1, now())
  ON CONFLICT (identifier, endpoint) 
  DO UPDATE SET 
    attempts = CASE 
      WHEN rate_limits.updated_at < now() - interval '1 minute' * p_window_minutes 
      THEN 1 
      ELSE rate_limits.attempts + 1 
    END,
    updated_at = now()
  RETURNING attempts INTO current_attempts;

  -- Block if exceeded attempts
  IF current_attempts >= p_max_attempts THEN
    UPDATE public.rate_limits 
    SET blocked_until = now() + interval '1 minute' * p_window_minutes
    WHERE identifier = p_identifier AND endpoint = p_endpoint;
    RETURN false;
  END IF;

  RETURN true;
END;
$$;

-- Fix SixMorph key generation function
CREATE OR REPLACE FUNCTION public.generate_sixmorph_key(user_uuid uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_key TEXT;
  key_exists BOOLEAN;
  counter INTEGER := 0;
BEGIN
  LOOP
    -- Generate a more secure and unique key
    new_key := 'SM_' || 
               UPPER(SUBSTRING(user_uuid::text FROM 1 FOR 8)) || '_' ||
               UPPER(SUBSTRING(MD5(RANDOM()::text || clock_timestamp()::text) FROM 1 FOR 8)) || '_' ||
               UPPER(SUBSTRING(MD5(RANDOM()::text || user_uuid::text) FROM 1 FOR 8));
    
    -- Check if key already exists
    SELECT EXISTS(
      SELECT 1 FROM public.sixmorph_keys WHERE key_value = new_key
    ) INTO key_exists;
    
    -- Exit if key is unique or we've tried too many times
    IF NOT key_exists OR counter > 10 THEN
      EXIT;
    END IF;
    
    counter := counter + 1;
  END LOOP;
  
  -- Log key generation
  INSERT INTO public.security_audit_logs (
    user_id, event_type, details
  ) VALUES (
    user_uuid, 'sixmorph_key_generated', 
    jsonb_build_object('key_prefix', SUBSTRING(new_key FROM 1 FOR 10))
  );
  
  RETURN new_key;
END;
$$;

-- Improved create SixMorph key function
CREATE OR REPLACE FUNCTION public.create_sixmorph_key_for_user()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_user_id UUID;
  new_key TEXT;
  existing_keys_count INTEGER;
BEGIN
  -- Get current user ID
  current_user_id := auth.uid();
  
  IF current_user_id IS NULL THEN
    RAISE EXCEPTION 'User not authenticated' USING ERRCODE = 'insufficient_privilege';
  END IF;
  
  -- Check if user already has maximum keys (limit to 5 per user)
  SELECT COUNT(*) INTO existing_keys_count
  FROM public.sixmorph_keys 
  WHERE user_id = current_user_id AND is_active = true;
  
  IF existing_keys_count >= 5 THEN
    RAISE EXCEPTION 'Maximum number of SixMorph keys reached' USING ERRCODE = 'program_limit_exceeded';
  END IF;
  
  -- Generate new key
  new_key := public.generate_sixmorph_key(current_user_id);
  
  -- Insert the new key
  INSERT INTO public.sixmorph_keys (user_id, key_value, key_name, is_active)
  VALUES (
    current_user_id, 
    new_key, 
    'SixMorph Key #' || (existing_keys_count + 1),
    true
  );
  
  RETURN new_key;
EXCEPTION
  WHEN OTHERS THEN
    -- Log the error
    INSERT INTO public.security_audit_logs (
      user_id, event_type, details
    ) VALUES (
      current_user_id, 'sixmorph_key_generation_failed', 
      jsonb_build_object('error', SQLERRM)
    );
    RAISE;
END;
$$;


-- Create workflow executions tracking table
CREATE TABLE IF NOT EXISTS public.workflow_executions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  workflow_id UUID REFERENCES public.bots(id),
  started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  completed_at TIMESTAMP WITH TIME ZONE,
  execution_data JSONB,
  nodes_executed INTEGER DEFAULT 0,
  total_nodes INTEGER DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'running',
  error_message TEXT
);

-- Enable RLS for workflow executions
ALTER TABLE public.workflow_executions ENABLE ROW LEVEL SECURITY;

-- Create policies for workflow executions
CREATE POLICY "Users can view their own executions" ON public.workflow_executions
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own executions" ON public.workflow_executions
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own executions" ON public.workflow_executions
  FOR UPDATE USING (auth.uid() = user_id);

-- Create workflow templates table for sharing
CREATE TABLE IF NOT EXISTS public.workflow_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL,
  difficulty_level TEXT NOT NULL DEFAULT 'beginner',
  template_data JSONB NOT NULL,
  required_skills JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for workflow templates
ALTER TABLE public.workflow_templates ENABLE ROW LEVEL SECURITY;

-- Create policy for workflow templates (public read)
CREATE POLICY "Anyone can view workflow templates" ON public.workflow_templates
  FOR SELECT USING (true);

-- Add real-time support for workflow executions
ALTER TABLE public.workflow_executions REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.workflow_executions;

-- Insert some sample workflow templates
INSERT INTO public.workflow_templates (name, description, category, difficulty_level, template_data, required_skills) VALUES
('Email Automation', 'Send automated emails based on triggers', 'communication', 'beginner', 
  '{"nodes": [{"id": "trigger", "type": "trigger", "data": {"label": "Manual Trigger"}}, {"id": "email", "type": "gmail", "data": {"label": "Send Email"}}], "edges": [{"id": "e1", "source": "trigger", "target": "email"}]}', 
  '["email", "automation"]'),
('Data Processing Pipeline', 'Transform and process data from APIs', 'data', 'intermediate', 
  '{"nodes": [{"id": "webhook", "type": "webhook", "data": {"label": "Webhook Trigger"}}, {"id": "transform", "type": "ai-transform", "data": {"label": "AI Transform"}}, {"id": "db", "type": "store-db", "data": {"label": "Store Data"}}], "edges": [{"id": "e1", "source": "webhook", "target": "transform"}, {"id": "e2", "source": "transform", "target": "db"}]}', 
  '["api", "data-processing", "ai"]'),
('Conditional Logic Flow', 'Advanced workflow with conditional branching', 'logic', 'advanced', 
  '{"nodes": [{"id": "trigger", "type": "trigger", "data": {"label": "Start"}}, {"id": "condition", "type": "condition", "data": {"label": "Check Condition"}}, {"id": "action1", "type": "gmail", "data": {"label": "Send Success Email"}}, {"id": "action2", "type": "discord", "data": {"label": "Send Alert"}}], "edges": [{"id": "e1", "source": "trigger", "target": "condition"}, {"id": "e2", "source": "condition", "target": "action1"}, {"id": "e3", "source": "condition", "target": "action2"}]}', 
  '["logic", "conditions", "branching"]');

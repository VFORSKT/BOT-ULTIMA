
-- Create quiz questions table
CREATE TABLE public.quiz_questions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  question TEXT NOT NULL,
  options JSONB NOT NULL,
  category TEXT NOT NULL,
  weight INTEGER DEFAULT 1,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create agent templates table
CREATE TABLE public.agent_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL,
  difficulty_level TEXT NOT NULL DEFAULT 'beginner',
  required_skills JSONB DEFAULT '[]'::jsonb,
  template_data JSONB NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create workflow templates table
CREATE TABLE public.workflow_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL,
  difficulty_level TEXT NOT NULL DEFAULT 'beginner',
  required_skills JSONB DEFAULT '[]'::jsonb,
  template_data JSONB NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create quiz results table
CREATE TABLE public.quiz_results (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  answers JSONB NOT NULL,
  analysis_result JSONB NOT NULL,
  recommended_agents JSONB DEFAULT '[]'::jsonb,
  recommended_workflows JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.quiz_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.agent_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workflow_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quiz_results ENABLE ROW LEVEL SECURITY;

-- Create policies for quiz questions (public read)
CREATE POLICY "Anyone can view quiz questions" 
  ON public.quiz_questions 
  FOR SELECT 
  USING (true);

-- Create policies for agent templates (public read)
CREATE POLICY "Anyone can view agent templates" 
  ON public.agent_templates 
  FOR SELECT 
  USING (true);

-- Create policies for workflow templates (public read)
CREATE POLICY "Anyone can view workflow templates" 
  ON public.workflow_templates 
  FOR SELECT 
  USING (true);

-- Create policies for quiz results
CREATE POLICY "Users can view their own quiz results" 
  ON public.quiz_results 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own quiz results" 
  ON public.quiz_results 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

-- Insert sample quiz questions
INSERT INTO public.quiz_questions (question, options, category) VALUES
('What is your primary goal with AI automation?', '["Streamline business processes", "Create customer support solutions", "Build personal productivity tools", "Develop creative applications"]', 'goals'),
('What is your technical experience level?', '["Complete beginner", "Some coding experience", "Intermediate developer", "Advanced developer"]', 'experience'),
('Which industry best describes your focus?', '["E-commerce", "Healthcare", "Education", "Finance", "Marketing", "Other"]', 'industry'),
('What type of tasks do you want to automate most?', '["Data processing", "Customer communication", "Content creation", "Task scheduling"]', 'tasks'),
('How do you prefer to build solutions?', '["Visual drag-and-drop", "Code-based", "Template-based", "Hybrid approach"]', 'approach'),
('What is your target audience?', '["Small businesses", "Enterprise clients", "Individual consumers", "Developers"]', 'audience'),
('Which platform integration is most important?', '["Telegram", "WhatsApp", "Email", "Web dashboard", "Mobile app"]', 'integration'),
('What is your budget range for tools?', '["Free/open source", "Under $50/month", "$50-200/month", "Enterprise level"]', 'budget'),
('How much time can you dedicate to learning?', '["1-2 hours/week", "5-10 hours/week", "20+ hours/week", "Full-time"]', 'time'),
('What motivates you most?', '["Solving problems", "Making money", "Learning new tech", "Helping others"]', 'motivation');

-- Insert sample agent templates
INSERT INTO public.agent_templates (name, description, category, difficulty_level, required_skills, template_data) VALUES
('Customer Support Bot', 'AI-powered customer service agent that handles common inquiries', 'customer-service', 'beginner', '["basic AI", "customer service"]', '{"type": "support", "features": ["FAQ", "ticket routing", "escalation"]}'),
('Lead Generation Assistant', 'Qualify leads and schedule meetings automatically', 'sales', 'intermediate', '["CRM integration", "sales process"]', '{"type": "sales", "features": ["lead scoring", "appointment booking", "follow-up"]}'),
('Content Creator Bot', 'Generate blog posts, social media content, and marketing copy', 'content', 'beginner', '["content strategy", "copywriting"]', '{"type": "content", "features": ["blog writing", "social posts", "SEO optimization"]}'),
('Data Analysis Agent', 'Process and analyze business data to generate insights', 'analytics', 'advanced', '["data analysis", "reporting", "SQL"]', '{"type": "analytics", "features": ["data processing", "visualization", "reporting"]}'),
('Personal Assistant', 'Manage tasks, calendar, and personal productivity', 'productivity', 'beginner', '["task management", "scheduling"]', '{"type": "personal", "features": ["calendar", "reminders", "task tracking"]}');

-- Insert sample workflow templates
INSERT INTO public.workflow_templates (name, description, category, difficulty_level, required_skills, template_data) VALUES
('E-commerce Order Processing', 'Automated workflow for handling online orders', 'ecommerce', 'intermediate', '["API integration", "payment processing"]', '{"type": "ecommerce", "steps": ["order received", "payment verification", "inventory check", "fulfillment"]}'),
('Email Marketing Campaign', 'Automated email sequences for marketing', 'marketing', 'beginner', '["email marketing", "segmentation"]', '{"type": "marketing", "steps": ["trigger event", "segment audience", "send email", "track engagement"]}'),
('Social Media Scheduler', 'Schedule and publish content across platforms', 'social-media', 'beginner', '["social media", "content planning"]', '{"type": "social", "steps": ["content creation", "scheduling", "publishing", "analytics"]}'),
('Invoice Generation System', 'Automatically generate and send invoices', 'finance', 'intermediate', '["accounting", "PDF generation"]', '{"type": "finance", "steps": ["service completion", "invoice generation", "email sending", "payment tracking"]}'),
('Backup and Sync Workflow', 'Automated data backup and synchronization', 'productivity', 'advanced', '["cloud storage", "data management"]', '{"type": "backup", "steps": ["file monitoring", "backup creation", "cloud upload", "verification"]}');

-- Function to analyze quiz results and generate recommendations
CREATE OR REPLACE FUNCTION public.analyze_quiz_results(answers JSONB)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  analysis JSONB;
  user_profile JSONB;
  recommended_agents JSONB;
  recommended_workflows JSONB;
BEGIN
  -- Initialize analysis object
  analysis := '{}'::jsonb;
  
  -- Analyze user profile based on answers
  user_profile := jsonb_build_object(
    'experience_level', CASE 
      WHEN answers->>'1' = 'Complete beginner' THEN 'beginner'
      WHEN answers->>'1' = 'Some coding experience' THEN 'intermediate'
      WHEN answers->>'1' = 'Intermediate developer' THEN 'intermediate'
      ELSE 'advanced'
    END,
    'primary_goal', answers->>'0',
    'industry', answers->>'2',
    'preferred_approach', answers->>'4',
    'budget_range', answers->>'7',
    'time_commitment', answers->>'8'
  );
  
  -- Get recommended agents based on profile
  SELECT jsonb_agg(
    jsonb_build_object(
      'id', id,
      'name', name,
      'description', description,
      'category', category,
      'difficulty_level', difficulty_level,
      'match_score', 
        CASE 
          WHEN difficulty_level = (user_profile->>'experience_level') THEN 100
          WHEN difficulty_level = 'beginner' AND (user_profile->>'experience_level') IN ('intermediate', 'advanced') THEN 90
          WHEN difficulty_level = 'intermediate' AND (user_profile->>'experience_level') = 'advanced' THEN 95
          ELSE 70
        END
    )
  ) INTO recommended_agents
  FROM public.agent_templates
  WHERE difficulty_level <= CASE 
    WHEN (user_profile->>'experience_level') = 'beginner' THEN 'beginner'
    WHEN (user_profile->>'experience_level') = 'intermediate' THEN 'intermediate'
    ELSE 'advanced'
  END
  LIMIT 3;
  
  -- Get recommended workflows based on profile
  SELECT jsonb_agg(
    jsonb_build_object(
      'id', id,
      'name', name,
      'description', description,
      'category', category,
      'difficulty_level', difficulty_level,
      'match_score',
        CASE 
          WHEN difficulty_level = (user_profile->>'experience_level') THEN 100
          WHEN difficulty_level = 'beginner' AND (user_profile->>'experience_level') IN ('intermediate', 'advanced') THEN 90
          WHEN difficulty_level = 'intermediate' AND (user_profile->>'experience_level') = 'advanced' THEN 95
          ELSE 70
        END
    )
  ) INTO recommended_workflows
  FROM public.workflow_templates
  WHERE difficulty_level <= CASE 
    WHEN (user_profile->>'experience_level') = 'beginner' THEN 'beginner'
    WHEN (user_profile->>'experience_level') = 'intermediate' THEN 'intermediate'
    ELSE 'advanced'
  END
  LIMIT 3;
  
  -- Build final analysis
  analysis := jsonb_build_object(
    'user_profile', user_profile,
    'recommended_agents', COALESCE(recommended_agents, '[]'::jsonb),
    'recommended_workflows', COALESCE(recommended_workflows, '[]'::jsonb),
    'next_steps', jsonb_build_array(
      'Start with beginner-friendly templates',
      'Join our community for support',
      'Explore the recommended solutions above',
      'Begin with one project and expand gradually'
    )
  );
  
  RETURN analysis;
END;
$$;

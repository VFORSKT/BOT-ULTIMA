
-- Create tables for workflow builder
CREATE TABLE public.workflows (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users NOT NULL,
  name text NOT NULL,
  description text,
  flow_data jsonb DEFAULT '{}'::jsonb,
  is_published boolean DEFAULT false,
  is_template boolean DEFAULT false,
  category text DEFAULT 'general',
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Create tables for pricing and purchases
CREATE TABLE public.subscription_plans (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  price decimal(10,2) NOT NULL,
  currency text DEFAULT 'USD',
  interval_type text NOT NULL, -- monthly, yearly
  features jsonb DEFAULT '[]'::jsonb,
  is_active boolean DEFAULT true,
  created_at timestamp with time zone DEFAULT now()
);

CREATE TABLE public.user_subscriptions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users NOT NULL,
  plan_id uuid REFERENCES public.subscription_plans NOT NULL,
  status text DEFAULT 'active', -- active, cancelled, expired
  current_period_start timestamp with time zone,
  current_period_end timestamp with time zone,
  stripe_subscription_id text,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

CREATE TABLE public.purchases (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users NOT NULL,
  item_type text NOT NULL, -- subscription, one_time
  item_id uuid,
  amount decimal(10,2) NOT NULL,
  currency text DEFAULT 'USD',
  status text DEFAULT 'pending', -- pending, completed, failed, refunded
  stripe_payment_intent_id text,
  created_at timestamp with time zone DEFAULT now()
);

-- Enhanced profiles table for profile builder
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS company_name text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS job_title text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS phone text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS location text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS logo_url text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS cover_image_url text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS skills jsonb DEFAULT '[]'::jsonb;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS social_links jsonb DEFAULT '{}'::jsonb;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS preferences jsonb DEFAULT '{}'::jsonb;

-- Create table for user sessions tracking
CREATE TABLE public.user_sessions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users NOT NULL,
  session_token text NOT NULL,
  expires_at timestamp with time zone NOT NULL,
  ip_address inet,
  user_agent text,
  is_active boolean DEFAULT true,
  created_at timestamp with time zone DEFAULT now()
);

-- Create table for API usage tracking
CREATE TABLE public.api_usage (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users NOT NULL,
  endpoint text NOT NULL,
  method text NOT NULL,
  status_code integer,
  response_time_ms integer,
  created_at timestamp with time zone DEFAULT now()
);

-- Add RLS policies for workflows
ALTER TABLE public.workflows ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can create their own workflows" 
  ON public.workflows 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own workflows" 
  ON public.workflows 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own workflows" 
  ON public.workflows 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own workflows" 
  ON public.workflows 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Add RLS policies for subscription plans (public read)
ALTER TABLE public.subscription_plans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view subscription plans" 
  ON public.subscription_plans 
  FOR SELECT 
  USING (true);

-- Add RLS policies for user subscriptions
ALTER TABLE public.user_subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own subscriptions" 
  ON public.user_subscriptions 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own subscriptions" 
  ON public.user_subscriptions 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own subscriptions" 
  ON public.user_subscriptions 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Add RLS policies for purchases
ALTER TABLE public.purchases ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own purchases" 
  ON public.purchases 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own purchases" 
  ON public.purchases 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

-- Add RLS policies for user sessions
ALTER TABLE public.user_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own sessions" 
  ON public.user_sessions 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can manage their own sessions" 
  ON public.user_sessions 
  FOR ALL 
  USING (auth.uid() = user_id);

-- Add RLS policies for API usage
ALTER TABLE public.api_usage ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own API usage" 
  ON public.api_usage 
  FOR SELECT 
  USING (auth.uid() = user_id);

-- Insert default subscription plans
INSERT INTO public.subscription_plans (name, price, interval_type, features) VALUES
('Free', 0.00, 'monthly', '["5 workflows", "Basic support", "Community access"]'),
('Pro', 29.99, 'monthly', '["Unlimited workflows", "Priority support", "Advanced features", "API access"]'),
('Premium', 99.99, 'monthly', '["Everything in Pro", "Custom integrations", "White-label options", "Dedicated support"]');

-- Create enhanced functions for authentication
CREATE OR REPLACE FUNCTION public.create_user_session(
  p_user_id uuid,
  p_session_token text,
  p_expires_at timestamp with time zone,
  p_ip_address inet DEFAULT NULL,
  p_user_agent text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  session_id uuid;
BEGIN
  INSERT INTO public.user_sessions (user_id, session_token, expires_at, ip_address, user_agent)
  VALUES (p_user_id, p_session_token, p_expires_at, p_ip_address, p_user_agent)
  RETURNING id INTO session_id;
  
  RETURN session_id;
END;
$$;

-- Function to validate user session
CREATE OR REPLACE FUNCTION public.validate_user_session(p_session_token text)
RETURNS TABLE(user_id uuid, is_valid boolean)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    us.user_id,
    (us.expires_at > now() AND us.is_active = true) as is_valid
  FROM public.user_sessions us
  WHERE us.session_token = p_session_token;
END;
$$;

-- Function to track API usage
CREATE OR REPLACE FUNCTION public.log_api_usage(
  p_user_id uuid,
  p_endpoint text,
  p_method text,
  p_status_code integer DEFAULT NULL,
  p_response_time_ms integer DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.api_usage (user_id, endpoint, method, status_code, response_time_ms)
  VALUES (p_user_id, p_endpoint, p_method, p_status_code, p_response_time_ms);
END;
$$;

-- Function to get user subscription status
CREATE OR REPLACE FUNCTION public.get_user_subscription_status(p_user_id uuid)
RETURNS TABLE(
  plan_name text,
  status text,
  expires_at timestamp with time zone,
  features jsonb
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    sp.name as plan_name,
    us.status,
    us.current_period_end as expires_at,
    sp.features
  FROM public.user_subscriptions us
  JOIN public.subscription_plans sp ON us.plan_id = sp.id
  WHERE us.user_id = p_user_id 
    AND us.status = 'active'
  ORDER BY us.created_at DESC
  LIMIT 1;
END;
$$;

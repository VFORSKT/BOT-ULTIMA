
-- Create a table for SixMorph Keys
CREATE TABLE public.sixmorph_keys (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  key_value TEXT NOT NULL UNIQUE,
  key_name TEXT NOT NULL DEFAULT 'Default Key',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  last_used_at TIMESTAMP WITH TIME ZONE,
  usage_count INTEGER DEFAULT 0
);

-- Enable RLS
ALTER TABLE public.sixmorph_keys ENABLE ROW LEVEL SECURITY;

-- Create policies for SixMorph Keys
CREATE POLICY "Users can view their own keys" 
  ON public.sixmorph_keys 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own keys" 
  ON public.sixmorph_keys 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own keys" 
  ON public.sixmorph_keys 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own keys" 
  ON public.sixmorph_keys 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Create workflow execution logs table
CREATE TABLE public.workflow_executions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  workflow_id UUID REFERENCES public.bots(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'running',
  started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  completed_at TIMESTAMP WITH TIME ZONE,
  execution_data JSONB,
  error_message TEXT,
  nodes_executed INTEGER DEFAULT 0,
  total_nodes INTEGER DEFAULT 0
);

-- Enable RLS for workflow executions
ALTER TABLE public.workflow_executions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own executions" 
  ON public.workflow_executions 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own executions" 
  ON public.workflow_executions 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own executions" 
  ON public.workflow_executions 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Create API keys storage table
CREATE TABLE public.user_api_keys (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  service_name TEXT NOT NULL,
  encrypted_key TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, service_name)
);

-- Enable RLS for API keys
ALTER TABLE public.user_api_keys ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage their own API keys" 
  ON public.user_api_keys 
  FOR ALL 
  USING (auth.uid() = user_id);

-- Function to generate SixMorph Key
CREATE OR REPLACE FUNCTION public.generate_sixmorph_key(user_uuid UUID)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_key TEXT;
  key_exists BOOLEAN;
BEGIN
  LOOP
    -- Generate a unique SixMorph key
    new_key := 'SM_' || 
               UPPER(SUBSTRING(user_uuid::text, 1, 8)) || '_' ||
               UPPER(SUBSTRING(MD5(RANDOM()::text), 1, 8)) || '_' ||
               EXTRACT(EPOCH FROM NOW())::bigint;
    
    -- Check if key already exists
    SELECT EXISTS(SELECT 1 FROM public.sixmorph_keys WHERE key_value = new_key) INTO key_exists;
    
    -- If key doesn't exist, break the loop
    IF NOT key_exists THEN
      EXIT;
    END IF;
  END LOOP;
  
  RETURN new_key;
END;
$$;

-- Function to create SixMorph key for user
CREATE OR REPLACE FUNCTION public.create_sixmorph_key_for_user()
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_user_id UUID;
  new_key TEXT;
BEGIN
  -- Get current user ID
  current_user_id := auth.uid();
  
  IF current_user_id IS NULL THEN
    RAISE EXCEPTION 'User not authenticated';
  END IF;
  
  -- Generate new key
  new_key := public.generate_sixmorph_key(current_user_id);
  
  -- Insert the new key
  INSERT INTO public.sixmorph_keys (user_id, key_value, key_name)
  VALUES (current_user_id, new_key, 'Default Key');
  
  RETURN new_key;
END;
$$;

-- Update profiles table to include more fields
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS last_login_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS login_count INTEGER DEFAULT 0;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS subscription_status TEXT DEFAULT 'free';


import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Eye, EyeOff, Shield, Lock, Mail, AlertCircle, CheckCircle } from "lucide-react";
import { useAuth } from "@/components/AuthenticationManager";
import { SecurityService } from "@/services/SecurityService";
import { useToast } from "@/hooks/use-toast";

interface SecureAuthFormProps {
  mode: 'login' | 'signup';
  onSuccess?: () => void;
  onModeChange?: (mode: 'login' | 'signup') => void;
}

const SecureAuthForm = ({ mode, onSuccess, onModeChange }: SecureAuthFormProps) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [passwordStrength, setPasswordStrength] = useState({ isValid: false, errors: [] as string[] });
  const { signIn, signUp } = useAuth();
  const { toast } = useToast();

  // Real-time password validation
  useEffect(() => {
    if (mode === 'signup' && password) {
      setPasswordStrength(SecurityService.validatePassword(password));
    }
  }, [password, mode]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsSubmitting(true);

    // Input validation
    const sanitizedEmail = SecurityService.sanitizeInput(email);
    
    if (!SecurityService.validateEmail(sanitizedEmail)) {
      setError("Please enter a valid email address");
      setIsSubmitting(false);
      return;
    }

    if (mode === 'signup') {
      if (!passwordStrength.isValid) {
        setError("Password does not meet security requirements");
        setIsSubmitting(false);
        return;
      }

      if (password !== confirmPassword) {
        setError("Passwords do not match");
        setIsSubmitting(false);
        return;
      }
    }

    try {
      let result;
      
      if (mode === 'login') {
        result = await signIn(sanitizedEmail, password);
      } else {
        result = await signUp(sanitizedEmail, password, {
          full_name: "",
        });
      }

      if (!result.error) {
        onSuccess?.();
      } else {
        setError(result.error.message || "Authentication failed");
      }
    } catch (error) {
      console.error("Auth error:", error);
      setError("An unexpected error occurred. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const getPasswordStrengthColor = () => {
    if (!password) return "text-gray-400";
    return passwordStrength.isValid ? "text-green-500" : "text-red-500";
  };

  const toggleMode = () => {
    const newMode = mode === 'login' ? 'signup' : 'login';
    onModeChange?.(newMode);
    setError("");
    setPassword("");
    setConfirmPassword("");
  };

  return (
    <Card className="bg-gray-800/95 border-gray-700 backdrop-blur-xl">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Shield className="h-5 w-5 mr-2 text-green-400" />
          {mode === 'login' ? 'Secure Sign In' : 'Create Account'}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Mode Toggle */}
        <div className="flex space-x-2 mb-6">
          <Button
            type="button"
            variant={mode === 'login' ? "default" : "ghost"}
            onClick={() => onModeChange?.('login')}
            className={`flex-1 ${mode === 'login' ? "bg-green-600 hover:bg-green-700" : "text-green-400 hover:bg-green-500/20"}`}
          >
            Sign In
          </Button>
          <Button
            type="button"
            variant={mode === 'signup' ? "default" : "ghost"}
            onClick={() => onModeChange?.('signup')}
            className={`flex-1 ${mode === 'signup' ? "bg-green-600 hover:bg-green-700" : "text-green-400 hover:bg-green-500/20"}`}
          >
            Sign Up
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <Alert className="border-red-500/50 bg-red-500/10">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription className="text-red-400">{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="email" className="text-gray-300 flex items-center">
              <Mail className="h-4 w-4 mr-1" />
              Email Address
            </Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-gray-700/50 border-gray-600 text-white focus:border-green-400"
              placeholder="Enter your email"
              required
              autoComplete="email"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password" className="text-gray-300 flex items-center">
              <Lock className="h-4 w-4 mr-1" />
              Password
            </Label>
            <div className="relative">
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-gray-700/50 border-gray-600 text-white focus:border-green-400 pr-10"
                placeholder="Enter your password"
                required
                autoComplete={mode === 'login' ? "current-password" : "new-password"}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center"
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4 text-gray-400" />
                ) : (
                  <Eye className="h-4 w-4 text-gray-400" />
                )}
              </button>
            </div>
            
            {mode === 'signup' && password && (
              <div className="space-y-1">
                <div className={`text-sm font-medium ${getPasswordStrengthColor()}`}>
                  Password Strength: {passwordStrength.isValid ? "Strong" : "Weak"}
                </div>
                {passwordStrength.errors.length > 0 && (
                  <ul className="text-xs text-red-400 space-y-1">
                    {passwordStrength.errors.map((error, index) => (
                      <li key={index} className="flex items-center">
                        <AlertCircle className="h-3 w-3 mr-1" />
                        {error}
                      </li>
                    ))}
                  </ul>
                )}
                {passwordStrength.isValid && (
                  <div className="flex items-center text-xs text-green-400">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Password meets all security requirements
                  </div>
                )}
              </div>
            )}
          </div>

          {mode === 'signup' && (
            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="text-gray-300 flex items-center">
                <Lock className="h-4 w-4 mr-1" />
                Confirm Password
              </Label>
              <Input
                id="confirmPassword"
                type={showPassword ? "text" : "password"}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="bg-gray-700/50 border-gray-600 text-white focus:border-green-400"
                placeholder="Confirm your password"
                required
                autoComplete="new-password"
              />
              {confirmPassword && password !== confirmPassword && (
                <div className="text-xs text-red-400 flex items-center">
                  <AlertCircle className="h-3 w-3 mr-1" />
                  Passwords do not match
                </div>
              )}
            </div>
          )}

          <Button
            type="submit"
            disabled={isSubmitting || (mode === 'signup' && !passwordStrength.isValid)}
            className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 disabled:opacity-50"
          >
            {isSubmitting ? (
              <div className="flex items-center">
                <div className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                {mode === 'login' ? 'Signing In...' : 'Creating Account...'}
              </div>
            ) : (
              mode === 'login' ? 'Sign In Securely' : 'Create Secure Account'
            )}
          </Button>

          {/* Security Notice */}
          <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3 text-xs">
            <div className="flex items-start space-x-2">
              <Shield className="h-4 w-4 text-blue-400 mt-0.5" />
              <div className="text-blue-400">
                <p className="font-medium">Security Features Active</p>
                <ul className="mt-1 space-y-1 text-blue-300">
                  <li>• End-to-end encryption</li>
                  <li>• Rate limiting protection</li>
                  <li>• Secure password requirements</li>
                  <li>• Security audit logging</li>
                </ul>
              </div>
            </div>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default SecureAuthForm;

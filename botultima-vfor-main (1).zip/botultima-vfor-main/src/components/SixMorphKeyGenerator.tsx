
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Key, Copy, RefreshCw, Plus, Shield, AlertTriangle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface SixMorphKey {
  id: string;
  key_value: string;
  key_name: string;
  created_at: string;
  last_used_at: string | null;
  usage_count: number;
  is_active: boolean;
}

const SixMorphKeyGenerator = () => {
  const [keys, setKeys] = useState<SixMorphKey[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadKeys();
  }, []);

  const loadKeys = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('sixmorph_keys')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setKeys(data || []);
    } catch (error) {
      console.error('Error loading keys:', error);
      toast({
        title: "Error",
        description: "Failed to load SixMorph keys",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const generateNewKey = async () => {
    setIsGenerating(true);
    try {
      const { data: newKey, error } = await supabase.rpc('create_sixmorph_key_for_user');
      
      if (error) {
        if (error.code === 'program_limit_exceeded') {
          toast({
            title: "Limit Reached",
            description: "You can only have up to 5 active SixMorph keys",
            variant: "destructive",
          });
        } else {
          throw error;
        }
        return;
      }
      
      toast({
        title: "Success!",
        description: "New SixMorph key generated successfully",
      });
      
      // Reload keys to show the new one
      await loadKeys();
    } catch (error) {
      console.error('Error generating key:', error);
      toast({
        title: "Error",
        description: "Failed to generate SixMorph key. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = (keyValue: string) => {
    navigator.clipboard.writeText(keyValue);
    toast({
      title: "Copied!",
      description: "SixMorph key copied to clipboard",
    });
  };

  const deactivateKey = async (keyId: string) => {
    try {
      const { error } = await supabase
        .from('sixmorph_keys')
        .update({ is_active: false })
        .eq('id', keyId);

      if (error) throw error;

      toast({
        title: "Key Deactivated",
        description: "SixMorph key has been deactivated",
      });

      await loadKeys();
    } catch (error) {
      console.error('Error deactivating key:', error);
      toast({
        title: "Error",
        description: "Failed to deactivate key",
        variant: "destructive",
      });
    }
  };

  const activeKeys = keys.filter(key => key.is_active);
  const inactiveKeys = keys.filter(key => !key.is_active);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">SixMorph Keys</h2>
          <p className="text-gray-400">Secure API access keys with enhanced protection</p>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            onClick={loadKeys}
            disabled={isLoading}
            variant="outline"
            className="border-gray-600"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button
            onClick={generateNewKey}
            disabled={isGenerating || activeKeys.length >= 5}
            className="bg-green-600 hover:bg-green-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            {isGenerating ? "Generating..." : "Generate Key"}
          </Button>
        </div>
      </div>

      {/* Security Notice */}
      <Card className="bg-blue-500/10 border-blue-500/30">
        <CardContent className="p-4">
          <div className="flex items-start space-x-3">
            <Shield className="h-5 w-5 text-blue-400 mt-0.5" />
            <div className="text-blue-400">
              <h3 className="font-medium mb-1">Enhanced Security Features</h3>
              <ul className="text-sm text-blue-300 space-y-1">
                <li>• Cryptographically secure key generation</li>
                <li>• Usage tracking and audit logging</li>
                <li>• Rate limiting protection</li>
                <li>• Automatic security event monitoring</li>
                <li>• Maximum 5 active keys per user</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Keys */}
      {activeKeys.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-white mb-4">Active Keys ({activeKeys.length}/5)</h3>
          <div className="grid gap-4">
            {activeKeys.map((key) => (
              <Card key={key.id} className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center">
                      <Key className="h-5 w-5 mr-2 text-green-400" />
                      {key.key_name}
                    </CardTitle>
                    <Badge className="bg-green-500/20 text-green-400">
                      Active
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-gray-900/50 p-3 rounded-lg font-mono text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-green-400 break-all">{key.key_value}</span>
                      <div className="flex items-center space-x-2 ml-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyToClipboard(key.key_value)}
                          className="hover:bg-gray-700"
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => deactivateKey(key.id)}
                          className="hover:bg-red-700 text-red-400"
                        >
                          <AlertTriangle className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <span className="text-gray-400">Created:</span>
                      <p className="text-white">{new Date(key.created_at).toLocaleDateString()}</p>
                    </div>
                    <div>
                      <span className="text-gray-400">Last Used:</span>
                      <p className="text-white">
                        {key.last_used_at ? new Date(key.last_used_at).toLocaleDateString() : 'Never'}
                      </p>
                    </div>
                    <div>
                      <span className="text-gray-400">Usage Count:</span>
                      <p className="text-white">{key.usage_count || 0}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Inactive Keys */}
      {inactiveKeys.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-white mb-4">Inactive Keys</h3>
          <div className="grid gap-4">
            {inactiveKeys.map((key) => (
              <Card key={key.id} className="bg-gray-800/30 border-gray-700 opacity-75">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-gray-400 flex items-center">
                      <Key className="h-5 w-5 mr-2 text-gray-500" />
                      {key.key_name}
                    </CardTitle>
                    <Badge className="bg-gray-500/20 text-gray-400">
                      Inactive
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-sm text-gray-500">
                    <p>Created: {new Date(key.created_at).toLocaleDateString()}</p>
                    <p>Usage Count: {key.usage_count || 0}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {keys.length === 0 && !isLoading && (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-8 text-center">
            <Key className="h-16 w-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-400 mb-4">No SixMorph Keys</h3>
            <p className="text-gray-500 mb-6">Generate your first secure SixMorph key to access the API</p>
            <Button
              onClick={generateNewKey}
              disabled={isGenerating}
              className="bg-green-600 hover:bg-green-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Generate Your First Key
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default SixMorphKeyGenerator;

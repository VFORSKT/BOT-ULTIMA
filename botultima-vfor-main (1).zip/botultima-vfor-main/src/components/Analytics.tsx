
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  Bot, 
  MessageSquare, 
  Zap,
  Clock,
  Target
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

const Analytics = () => {
  const [analyticsData, setAnalyticsData] = useState({
    totalBots: 12,
    activeUsers: 248,
    totalInteractions: 15420,
    tokenUsage: 85600,
    successRate: 98.2,
    averageResponseTime: 1.4
  });

  const interactionData = [
    { name: 'Mon', interactions: 2400, users: 45 },
    { name: 'Tue', interactions: 1398, users: 38 },
    { name: 'Wed', interactions: 9800, users: 52 },
    { name: 'Thu', interactions: 3908, users: 41 },
    { name: 'Fri', interactions: 4800, users: 48 },
    { name: 'Sat', interactions: 3800, users: 35 },
    { name: 'Sun', interactions: 4300, users: 42 }
  ];

  const botPerformanceData = [
    { name: 'Customer Support', success: 98, errors: 2, total: 5420 },
    { name: 'Lead Generator', success: 95, errors: 5, total: 3210 },
    { name: 'FAQ Helper', success: 99, errors: 1, total: 4580 },
    { name: 'Sales Assistant', success: 92, errors: 8, total: 2190 }
  ];

  const stats = [
    {
      title: "Total Bots",
      value: analyticsData.totalBots.toString(),
      change: "+2 this week",
      icon: <Bot className="h-5 w-5" />,
      color: "text-green-400"
    },
    {
      title: "Active Users",
      value: analyticsData.activeUsers.toString(),
      change: "+12% this month",
      icon: <Users className="h-5 w-5" />,
      color: "text-blue-400"
    },
    {
      title: "Interactions",
      value: `${(analyticsData.totalInteractions / 1000).toFixed(1)}K`,
      change: "+18% this week",
      icon: <MessageSquare className="h-5 w-5" />,
      color: "text-purple-400"
    },
    {
      title: "Token Usage",
      value: `${(analyticsData.tokenUsage / 1000).toFixed(0)}K`,
      change: "of 100K limit",
      icon: <Zap className="h-5 w-5" />,
      color: "text-yellow-400"
    },
    {
      title: "Success Rate",
      value: `${analyticsData.successRate}%`,
      change: "+0.3% this week",
      icon: <Target className="h-5 w-5" />,
      color: "text-emerald-400"
    },
    {
      title: "Avg Response",
      value: `${analyticsData.averageResponseTime}s`,
      change: "-0.2s improvement",
      icon: <Clock className="h-5 w-5" />,
      color: "text-orange-400"
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">Analytics Dashboard</h2>
          <p className="text-gray-400">Monitor your bot performance and usage statistics</p>
        </div>
        <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
          <BarChart3 className="h-4 w-4 mr-2" />
          Live Data
        </Badge>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {stats.map((stat, index) => (
          <Card key={index} className="bg-gray-900/50 border-gray-800/50 hover:border-green-500/30 transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm font-medium">{stat.title}</p>
                  <p className="text-2xl font-bold text-white mt-2">{stat.value}</p>
                  <p className="text-sm text-gray-500 mt-1">{stat.change}</p>
                </div>
                <div className={`${stat.color}`}>
                  {stat.icon}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Interactions Chart */}
        <Card className="bg-gray-900/50 border-gray-800/50">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <TrendingUp className="h-5 w-5 mr-2 text-green-400" />
              Daily Interactions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={interactionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="name" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937', 
                    border: '1px solid #374151',
                    borderRadius: '8px',
                    color: '#F9FAFB'
                  }} 
                />
                <Line 
                  type="monotone" 
                  dataKey="interactions" 
                  stroke="#10B981" 
                  strokeWidth={2}
                  dot={{ fill: '#10B981', strokeWidth: 2, r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Bot Performance Chart */}
        <Card className="bg-gray-900/50 border-gray-800/50">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Bot className="h-5 w-5 mr-2 text-blue-400" />
              Bot Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={botPerformanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="name" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937', 
                    border: '1px solid #374151',
                    borderRadius: '8px',
                    color: '#F9FAFB'
                  }} 
                />
                <Bar dataKey="success" fill="#10B981" />
                <Bar dataKey="errors" fill="#EF4444" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Bot Performance Table */}
      <Card className="bg-gray-900/50 border-gray-800/50">
        <CardHeader>
          <CardTitle className="text-white">Bot Performance Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {botPerformanceData.map((bot, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-800/30 rounded-lg border border-gray-700/30">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-600 rounded-lg flex items-center justify-center">
                    <Bot className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white">{bot.name}</h3>
                    <p className="text-sm text-gray-400">{bot.total.toLocaleString()} total interactions</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <p className="text-green-400 font-semibold">{bot.success}% Success</p>
                    <p className="text-red-400 text-sm">{bot.errors}% Errors</p>
                  </div>
                  
                  <div className="w-16 h-2 bg-gray-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-green-500 rounded-full"
                      style={{ width: `${bot.success}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Analytics;


import { useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { 
  Play, 
  Pause, 
  Square, 
  SkipForward, 
  Clock,
  CheckCircle, 
  AlertTriangle, 
  Info,
  Settings,
  Zap
} from 'lucide-react';
import { WorkflowNode, WorkflowEdge, SimulationState } from '@/types/WorkflowTypes';

interface WorkflowSimulatorProps {
  nodes: WorkflowNode[];
  edges: WorkflowEdge[];
  onUpdateNode: (nodeId: string, updates: any) => void;
}

const WorkflowSimulator = ({ nodes, edges, onUpdateNode }: WorkflowSimulatorProps) => {
  const [simulation, setSimulation] = useState<SimulationState>({
    isRunning: false,
    executionLog: []
  });
  const [speed, setSpeed] = useState<'slow' | 'normal' | 'fast'>('normal');
  const [stepMode, setStepMode] = useState(false);

  const getSpeedDelay = () => {
    switch (speed) {
      case 'slow': return 3000;
      case 'fast': return 500;
      default: return 1500;
    }
  };

  const simulateNodeExecution = async (node: WorkflowNode): Promise<{ success: boolean; output?: string; error?: string }> => {
    await new Promise(resolve => setTimeout(resolve, getSpeedDelay()));
    
    const { type, config, category } = node.data;
    
    // Simulate different outcomes based on node configuration
    switch (category) {
      case 'ai':
        if (!config?.prompt && type !== 'trigger') {
          return { success: false, error: 'No prompt provided for AI node' };
        }
        return { success: true, output: `AI ${type} completed: Generated response based on prompt` };
      
      case 'database':
        if (!config?.connectionString && !config?.host) {
          return { success: false, error: 'Database connection not configured' };
        }
        if (!config?.query) {
          return { success: false, error: 'No SQL query provided' };
        }
        return { success: true, output: `Database query executed: ${Math.floor(Math.random() * 100)} rows affected` };
      
      case 'communication':
        if (type === 'email-sender') {
          if (!config?.fromEmail || !config?.toEmail) {
            return { success: false, error: 'Email addresses not configured' };
          }
          return { success: true, output: `Email sent to ${config.toEmail}` };
        }
        if (!config?.apiKey && type !== 'discord-webhook') {
          return { success: false, error: 'API key required for communication service' };
        }
        return { success: true, output: `Message sent via ${type}` };
      
      case 'action':
        if (!config?.apiKey) {
          return { success: false, error: 'API key required for app integration' };
        }
        return { success: true, output: `${type} action completed successfully` };
      
      case 'transformation':
        if (type === 'custom-code-runner' && !config?.jsCode) {
          return { success: false, error: 'No JavaScript code provided' };
        }
        return { success: true, output: `Data transformation (${type}) completed` };
      
      case 'flow-control':
        if (type === 'condition' && !config?.conditions) {
          return { success: false, error: 'No condition logic provided' };
        }
        return { success: true, output: `Flow control (${type}) executed` };
      
      default:
        return { success: true, output: 'Step completed' };
    }
  };

  const addLogEntry = useCallback((nodeId: string, status: 'success' | 'error' | 'running' | 'info', message: string, data?: any) => {
    setSimulation(prev => ({
      ...prev,
      executionLog: [...prev.executionLog, {
        nodeId,
        timestamp: new Date(),
        status,
        message,
        data
      }]
    }));
  }, []);

  const runSimulation = useCallback(async () => {
    setSimulation(prev => ({ ...prev, isRunning: true, executionLog: [] }));

    // Clear previous execution results
    nodes.forEach(node => {
      onUpdateNode(node.id, {
        isExecuting: false,
        executionResult: undefined
      });
    });

    // Find trigger nodes
    const triggerNodes = nodes.filter(node => 
      node.data.type === 'trigger' || node.data.type === 'webhook'
    );

    if (triggerNodes.length === 0) {
      addLogEntry('system', 'error', 'No trigger node found');
      setSimulation(prev => ({ ...prev, isRunning: false }));
      return;
    }

    // Build execution order
    const executionOrder: WorkflowNode[] = [];
    const visited = new Set<string>();
    
    const traverse = (nodeId: string) => {
      if (visited.has(nodeId)) return;
      visited.add(nodeId);
      
      const node = nodes.find(n => n.id === nodeId);
      if (node) {
        executionOrder.push(node);
        
        const outgoingEdges = edges.filter(edge => edge.source === nodeId);
        outgoingEdges.forEach(edge => traverse(edge.target));
      }
    };

    triggerNodes.forEach(trigger => traverse(trigger.id));

    addLogEntry('system', 'running', `Starting simulation with ${executionOrder.length} nodes`);

    // Execute nodes in order
    for (const node of executionOrder) {
      if (!simulation.isRunning) break; // Check if simulation was stopped

      setSimulation(prev => ({ ...prev, currentNodeId: node.id }));
      
      onUpdateNode(node.id, { isExecuting: true });
      addLogEntry(node.id, 'running', `Executing ${node.data.label}`);

      const result = await simulateNodeExecution(node);
      
      onUpdateNode(node.id, {
        isExecuting: false,
        executionResult: result
      });

      if (result.success) {
        addLogEntry(node.id, 'success', result.output || 'Node executed successfully', result);
      } else {
        addLogEntry(node.id, 'error', result.error || 'Node execution failed', result);
        
        // Stop simulation on error unless it's a warning
        if (node.data.type !== 'condition') {
          break;
        }
      }

      // Pause for step mode
      if (stepMode) {
        setSimulation(prev => ({ ...prev, isRunning: false }));
        break;
      }
    }

    if (!stepMode) {
      addLogEntry('system', 'info', 'Simulation completed');
      setSimulation(prev => ({ ...prev, isRunning: false, currentNodeId: undefined }));
    }
  }, [nodes, edges, onUpdateNode, addLogEntry, simulation.isRunning, stepMode]);

  const stopSimulation = useCallback(() => {
    setSimulation(prev => ({ 
      ...prev, 
      isRunning: false, 
      currentNodeId: undefined 
    }));
    
    // Clear all execution states
    nodes.forEach(node => {
      onUpdateNode(node.id, {
        isExecuting: false
      });
    });

    addLogEntry('system', 'info', 'Simulation stopped by user');
  }, [nodes, onUpdateNode, addLogEntry]);

  const getLogIcon = (status: string) => {
    switch (status) {
      case 'success': return <CheckCircle className="h-4 w-4 text-green-400" />;
      case 'error': return <AlertTriangle className="h-4 w-4 text-red-400" />;
      case 'running': return <Clock className="h-4 w-4 text-yellow-400" />;
      default: return <Info className="h-4 w-4 text-blue-400" />;
    }
  };

  const getLogColor = (status: string) => {
    switch (status) {
      case 'success': return 'text-green-300';
      case 'error': return 'text-red-300';
      case 'running': return 'text-yellow-300';
      default: return 'text-blue-300';
    }
  };

  return (
    <Card className="h-full bg-gray-900/95 border-gray-700">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium text-white flex items-center">
            <Zap className="h-4 w-4 mr-2" />
            Workflow Simulator
            {simulation.isRunning && (
              <Badge className="ml-2 bg-green-500/20 text-green-400 border-green-500/30">
                Running
              </Badge>
            )}
          </CardTitle>
          
          <div className="flex items-center space-x-2">
            <select
              value={speed}
              onChange={(e) => setSpeed(e.target.value as any)}
              className="bg-gray-700 border border-gray-600 rounded px-2 py-1 text-xs text-white"
            >
              <option value="slow">Slow</option>
              <option value="normal">Normal</option>
              <option value="fast">Fast</option>
            </select>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setStepMode(!stepMode)}
              className={`text-xs ${stepMode ? 'text-blue-400' : 'text-gray-400'}`}
            >
              <SkipForward className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="flex space-x-2 mt-3">
          <Button
            size="sm"
            onClick={simulation.isRunning ? stopSimulation : runSimulation}
            className={simulation.isRunning ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}
          >
            {simulation.isRunning ? (
              <>
                <Square className="h-4 w-4 mr-1" />
                Stop
              </>
            ) : (
              <>
                <Play className="h-4 w-4 mr-1" />
                Start
              </>
            )}
          </Button>
          
          {stepMode && (
            <Button
              size="sm"
              onClick={runSimulation}
              disabled={simulation.isRunning}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <SkipForward className="h-4 w-4 mr-1" />
              Step
            </Button>
          )}
        </div>
      </CardHeader>

      <CardContent className="h-full p-0">
        <ScrollArea className="h-96">
          <div className="p-4 space-y-2">
            {simulation.executionLog.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                <Zap className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No simulation logs yet</p>
                <p className="text-sm">Click Start to begin simulation</p>
              </div>
            ) : (
              simulation.executionLog.map((log, index) => (
                <div
                  key={index}
                  className="flex items-start space-x-3 p-2 rounded-lg bg-gray-800/50 border border-gray-700/50"
                >
                  <div className="flex-shrink-0 mt-0.5">
                    {getLogIcon(log.status)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="text-xs text-gray-400">
                        {log.timestamp.toLocaleTimeString()}
                      </span>
                      {log.nodeId !== 'system' && (
                        <Badge variant="outline" className="text-xs">
                          {nodes.find(n => n.id === log.nodeId)?.data.label || log.nodeId}
                        </Badge>
                      )}
                    </div>
                    <p className={`text-sm ${getLogColor(log.status)}`}>
                      {log.message}
                    </p>
                    {log.data && (
                      <details className="mt-2">
                        <summary className="text-xs text-gray-400 cursor-pointer">
                          Show data
                        </summary>
                        <pre className="text-xs text-gray-300 mt-1 p-2 bg-gray-900/50 rounded overflow-x-auto">
                          {JSON.stringify(log.data, null, 2)}
                        </pre>
                      </details>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

export default WorkflowSimulator;

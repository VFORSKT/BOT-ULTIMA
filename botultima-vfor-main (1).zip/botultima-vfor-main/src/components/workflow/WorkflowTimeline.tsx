
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Clock, CheckCircle, AlertCircle, Play } from 'lucide-react';

interface TimelineItem {
  nodeId: string;
  nodeName: string;
  timestamp: Date;
  duration: number;
  status: 'running' | 'success' | 'error';
}

interface WorkflowTimelineProps {
  timeline: TimelineItem[];
  isRunning: boolean;
}

const WorkflowTimeline = ({ timeline, isRunning }: WorkflowTimelineProps) => {
  if (timeline.length === 0 && !isRunning) return null;

  const getStatusIcon = (status: TimelineItem['status']) => {
    switch (status) {
      case 'running': return <Play className="h-3 w-3 text-yellow-400 animate-spin" />;
      case 'success': return <CheckCircle className="h-3 w-3 text-green-400" />;
      case 'error': return <AlertCircle className="h-3 w-3 text-red-400" />;
    }
  };

  const getStatusColor = (status: TimelineItem['status']) => {
    switch (status) {
      case 'running': return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      case 'success': return 'bg-green-500/20 text-green-300 border-green-500/30';
      case 'error': return 'bg-red-500/20 text-red-300 border-red-500/30';
    }
  };

  return (
    <div className="h-24 bg-gray-900/95 border-t border-gray-700/50 backdrop-blur-sm">
      <div className="flex items-center justify-between px-6 py-2 border-b border-gray-700/30">
        <div className="flex items-center space-x-2">
          <Clock className="h-4 w-4 text-blue-400" />
          <span className="text-sm font-medium text-white">Execution Timeline</span>
          {isRunning && (
            <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
              Running
            </Badge>
          )}
        </div>
        <div className="text-xs text-gray-400">
          Total: {timeline.reduce((acc, item) => acc + item.duration, 0)}ms
        </div>
      </div>
      
      <ScrollArea className="h-16">
        <div className="flex items-center space-x-4 px-6 py-2">
          {timeline.map((item, index) => (
            <div 
              key={`${item.nodeId}-${index}`}
              className="flex items-center space-x-2 min-w-fit"
            >
              <div className="flex items-center space-x-2 bg-gray-800/50 rounded-lg px-3 py-1 border border-gray-600/30">
                {getStatusIcon(item.status)}
                <span className="text-sm text-gray-300">{item.nodeName}</span>
                <Badge className={`text-xs ${getStatusColor(item.status)}`}>
                  {item.duration > 0 ? `${item.duration}ms` : 'Running...'}
                </Badge>
              </div>
              
              {index < timeline.length - 1 && (
                <div className="w-8 h-px bg-gradient-to-r from-blue-400 to-purple-400 animate-pulse"></div>
              )}
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};

export default WorkflowTimeline;

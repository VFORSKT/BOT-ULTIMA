
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Bot, 
  Zap, 
  Database, 
  MessageSquare, 
  Globe, 
  Code, 
  Settings,
  Search,
  Grip,
  X,
  Minimize2,
  Maximize2
} from 'lucide-react';

interface WorkflowNode {
  id: string;
  type: string;
  label: string;
  category: string;
  description: string;
  icon: React.ComponentType<any>;
  color: string;
}

const nodeCategories = [
  { id: 'ai', label: 'AI & ML', color: 'purple' },
  { id: 'action', label: 'Actions', color: 'blue' },
  { id: 'transformation', label: 'Transform', color: 'orange' },
  { id: 'flow-control', label: 'Flow Control', color: 'cyan' },
  { id: 'communication', label: 'Communication', color: 'teal' },
  { id: 'database', label: 'Database', color: 'green' },
  { id: 'core', label: 'Core', color: 'gray' }
];

const availableNodes: WorkflowNode[] = [
  // AI & ML
  { id: 'ai-chat', type: 'ai-chat', label: 'AI Chat', category: 'ai', description: 'OpenAI GPT conversation', icon: Bot, color: 'purple' },
  { id: 'ai-image', type: 'ai-image', label: 'AI Image', category: 'ai', description: 'Generate images with AI', icon: Bot, color: 'purple' },
  
  // Actions
  { id: 'http-request', type: 'http-request', label: 'HTTP Request', category: 'action', description: 'Make API calls', icon: Globe, color: 'blue' },
  { id: 'webhook', type: 'webhook', label: 'Webhook', category: 'action', description: 'Receive webhooks', icon: Zap, color: 'blue' },
  
  // Database
  { id: 'supabase-insert', type: 'supabase-insert', label: 'Insert Data', category: 'database', description: 'Insert into database', icon: Database, color: 'green' },
  { id: 'supabase-select', type: 'supabase-select', label: 'Get Data', category: 'database', description: 'Query database', icon: Database, color: 'green' },
  
  // Communication
  { id: 'send-email', type: 'send-email', label: 'Send Email', category: 'communication', description: 'Send email messages', icon: MessageSquare, color: 'teal' },
  { id: 'slack-message', type: 'slack-message', label: 'Slack Message', category: 'communication', description: 'Send to Slack', icon: MessageSquare, color: 'teal' },
  
  // Core
  { id: 'trigger', type: 'trigger', label: 'Manual Trigger', category: 'core', description: 'Start workflow manually', icon: Zap, color: 'gray' },
  { id: 'code', type: 'code', label: 'Code', category: 'core', description: 'Execute custom code', icon: Code, color: 'gray' },
];

interface WorkflowToolsPanelProps {
  onClose?: () => void;
  isMinimized?: boolean;
  onToggleMinimize?: () => void;
}

const WorkflowToolsPanel = ({ onClose, isMinimized, onToggleMinimize }: WorkflowToolsPanelProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const filteredNodes = availableNodes.filter(node => {
    const matchesSearch = node.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         node.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || node.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const onDragStart = (event: React.DragEvent, nodeType: string, category: string) => {
    event.dataTransfer.setData('application/reactflow', nodeType);
    event.dataTransfer.setData('node-category', category);
    event.dataTransfer.effectAllowed = 'move';
    setIsDragging(true);
  };

  const onDragEnd = () => {
    setIsDragging(false);
  };

  const getCategoryColor = (category: string) => {
    const cat = nodeCategories.find(c => c.id === category);
    return cat?.color || 'gray';
  };

  if (isMinimized) {
    return (
      <div className="fixed top-20 left-4 z-50">
        <Button
          onClick={onToggleMinimize}
          className="bg-gray-800/95 hover:bg-gray-700 border border-gray-600 text-white shadow-xl"
        >
          <Maximize2 className="h-4 w-4 mr-2" />
          Tools
        </Button>
      </div>
    );
  }

  return (
    <Card className="fixed top-20 left-4 w-80 max-h-[calc(100vh-6rem)] bg-gray-900/95 border-gray-600 backdrop-blur-sm shadow-2xl z-50 overflow-hidden">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Grip className="h-4 w-4 text-gray-400 cursor-move" />
            <CardTitle className="text-white text-lg">Workflow Tools</CardTitle>
          </div>
          <div className="flex items-center space-x-1">
            {onToggleMinimize && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onToggleMinimize}
                className="text-gray-400 hover:text-white h-8 w-8 p-0"
              >
                <Minimize2 className="h-4 w-4" />
              </Button>
            )}
            {onClose && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                className="text-gray-400 hover:text-white h-8 w-8 p-0"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
        
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search tools..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-gray-800 border-gray-600 text-white placeholder-gray-400"
          />
        </div>

        {/* Categories */}
        <div className="flex flex-wrap gap-2">
          <Button
            variant={selectedCategory === null ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedCategory(null)}
            className={selectedCategory === null ? "bg-green-600 hover:bg-green-700" : "border-gray-600 text-gray-300 hover:bg-gray-700"}
          >
            All
          </Button>
          {nodeCategories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category.id)}
              className={
                selectedCategory === category.id 
                  ? "bg-green-600 hover:bg-green-700" 
                  : "border-gray-600 text-gray-300 hover:bg-gray-700"
              }
            >
              {category.label}
            </Button>
          ))}
        </div>
      </CardHeader>

      <CardContent className="p-0 overflow-y-auto max-h-96">
        <div className="space-y-2 p-4">
          {filteredNodes.map((node) => {
            const IconComponent = node.icon;
            return (
              <div
                key={node.id}
                draggable
                onDragStart={(event) => onDragStart(event, node.type, node.category)}
                onDragEnd={onDragEnd}
                className={`
                  flex items-center space-x-3 p-3 rounded-lg border cursor-grab transition-all
                  ${isDragging ? 'opacity-50' : 'opacity-100'}
                  bg-gray-800/50 border-gray-600 hover:bg-gray-700/50 hover:border-gray-500
                  active:cursor-grabbing
                `}
              >
                <div className={`
                  p-2 rounded-lg
                  ${node.color === 'purple' && 'bg-purple-500/20 text-purple-400'}
                  ${node.color === 'blue' && 'bg-blue-500/20 text-blue-400'}
                  ${node.color === 'green' && 'bg-green-500/20 text-green-400'}
                  ${node.color === 'orange' && 'bg-orange-500/20 text-orange-400'}
                  ${node.color === 'cyan' && 'bg-cyan-500/20 text-cyan-400'}
                  ${node.color === 'teal' && 'bg-teal-500/20 text-teal-400'}
                  ${node.color === 'gray' && 'bg-gray-500/20 text-gray-400'}
                `}>
                  <IconComponent className="h-4 w-4" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-white font-medium text-sm">{node.label}</span>
                    <Badge 
                      variant="outline" 
                      className="text-xs border-gray-600 text-gray-400"
                    >
                      {nodeCategories.find(c => c.id === node.category)?.label}
                    </Badge>
                  </div>
                  <p className="text-gray-400 text-xs mt-1">{node.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default WorkflowToolsPanel;


import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Save, 
  Play, 
  Download, 
  Upload,
  Undo, 
  Redo,
  ZoomIn,
  ZoomOut,
  Maximize,
  Settings,
  Share,
  Users,
  Activity,
  Clock,
  CheckCircle,
  AlertTriangle,
  Eye,
  Grid,
  Layers,
  Search,
  Filter
} from 'lucide-react';

interface CanvasToolbarProps {
  workflowName: string;
  onWorkflowNameChange: (name: string) => void;
  onSave: () => void;
  onTest: () => void;
  onExport: () => void;
  onImport: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onFitView: () => void;
  onSettings: () => void;
  onShare: () => void;
  canUndo: boolean;
  canRedo: boolean;
  zoom: number;
  isRunning: boolean;
  nodeCount: number;
  connectionCount: number;
  workflowStatus: 'draft' | 'saved' | 'deployed' | 'error';
}

const CanvasToolbar = ({
  workflowName,
  onWorkflowNameChange,
  onSave,
  onTest,
  onExport,
  onImport,
  onUndo,
  onRedo,
  onZoomIn,
  onZoomOut,
  onFitView,
  onSettings,
  onShare,
  canUndo,
  canRedo,
  zoom,
  isRunning,
  nodeCount,
  connectionCount,
  workflowStatus
}: CanvasToolbarProps) => {
  const getStatusColor = () => {
    switch (workflowStatus) {
      case 'draft': return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      case 'saved': return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
      case 'deployed': return 'bg-green-500/20 text-green-300 border-green-500/30';
      case 'error': return 'bg-red-500/20 text-red-300 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  const getStatusIcon = () => {
    switch (workflowStatus) {
      case 'draft': return <Clock className="h-3 w-3" />;
      case 'saved': return <CheckCircle className="h-3 w-3" />;
      case 'deployed': return <Activity className="h-3 w-3" />;
      case 'error': return <AlertTriangle className="h-3 w-3" />;
      default: return <Clock className="h-3 w-3" />;
    }
  };

  return (
    <div className="bg-gray-900/95 border-b border-gray-700/50 backdrop-blur-sm">
      {/* Main Toolbar */}
      <div className="flex items-center justify-between px-6 py-3">
        <div className="flex items-center space-x-4">
          {/* Logo and Workflow Name */}
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
              <Layers className="h-4 w-4 text-white" />
            </div>
            <Input
              value={workflowName}
              onChange={(e) => onWorkflowNameChange(e.target.value)}
              className="bg-transparent border-none text-white font-semibold text-lg focus:bg-gray-800/50 min-w-[200px]"
              placeholder="Untitled Workflow"
            />
          </div>

          {/* Status Badge */}
          <Badge className={`${getStatusColor()} flex items-center space-x-1`}>
            {getStatusIcon()}
            <span className="capitalize">{workflowStatus}</span>
          </Badge>

          {/* Workflow Stats */}
          <div className="flex items-center space-x-4 text-sm text-gray-400">
            <span>{nodeCount} nodes</span>
            <span>•</span>
            <span>{connectionCount} connections</span>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {/* History Controls */}
          <Button
            variant="ghost"
            size="sm"
            onClick={onUndo}
            disabled={!canUndo}
            className="text-gray-400 hover:text-white disabled:opacity-50"
          >
            <Undo className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onRedo}
            disabled={!canRedo}
            className="text-gray-400 hover:text-white disabled:opacity-50"
          >
            <Redo className="h-4 w-4" />
          </Button>

          <div className="w-px h-6 bg-gray-600 mx-2" />

          {/* Zoom Controls */}
          <div className="flex items-center space-x-1 bg-gray-800/50 rounded-lg px-2 py-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={onZoomOut}
              className="text-gray-400 hover:text-white p-1 h-auto"
            >
              <ZoomOut className="h-3 w-3" />
            </Button>
            <span className="text-sm text-gray-300 min-w-[3rem] text-center">
              {Math.round(zoom * 100)}%
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={onZoomIn}
              className="text-gray-400 hover:text-white p-1 h-auto"
            >
              <ZoomIn className="h-3 w-3" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onFitView}
              className="text-gray-400 hover:text-white p-1 h-auto"
            >
              <Maximize className="h-3 w-3" />
            </Button>
          </div>

          <div className="w-px h-6 bg-gray-600 mx-2" />

          {/* File Operations */}
          <Button
            variant="ghost"
            size="sm"
            onClick={onImport}
            className="text-gray-400 hover:text-white"
          >
            <Upload className="h-4 w-4 mr-1" />
            Import
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onExport}
            className="text-gray-400 hover:text-white"
          >
            <Download className="h-4 w-4 mr-1" />
            Export
          </Button>

          <div className="w-px h-6 bg-gray-600 mx-2" />

          {/* Action Buttons */}
          <Button
            variant="outline"
            size="sm"
            onClick={onTest}
            disabled={isRunning}
            className="bg-blue-600/20 border-blue-500/30 text-blue-300 hover:bg-blue-600/30"
          >
            <Play className="h-4 w-4 mr-1" />
            {isRunning ? 'Running...' : 'Test'}
          </Button>

          <Button
            size="sm"
            onClick={onSave}
            className="bg-green-600 hover:bg-green-700 shadow-lg"
          >
            <Save className="h-4 w-4 mr-1" />
            Save
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={onShare}
            className="text-gray-400 hover:text-white"
          >
            <Share className="h-4 w-4" />
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={onSettings}
            className="text-gray-400 hover:text-white"
          >
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Secondary Toolbar - Breadcrumb and Actions */}
      <div className="flex items-center justify-between px-6 py-2 bg-gray-800/30">
        <div className="flex items-center space-x-2 text-sm text-gray-400">
          <span>Home</span>
          <span>/</span>
          <span>Workflows</span>
          <span>/</span>
          <span className="text-white">{workflowName || 'Untitled Workflow'}</span>
        </div>

        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <Search className="h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search nodes..."
              className="bg-gray-800/50 border-gray-600 text-white text-sm w-48"
            />
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            className="text-gray-400 hover:text-white"
          >
            <Filter className="h-4 w-4 mr-1" />
            Filter
          </Button>

          <Button
            variant="ghost"
            size="sm"
            className="text-gray-400 hover:text-white"
          >
            <Grid className="h-4 w-4 mr-1" />
            Grid
          </Button>

          <Button
            variant="ghost"
            size="sm"
            className="text-gray-400 hover:text-white"
          >
            <Users className="h-4 w-4 mr-1" />
            Collaborate
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CanvasToolbar;

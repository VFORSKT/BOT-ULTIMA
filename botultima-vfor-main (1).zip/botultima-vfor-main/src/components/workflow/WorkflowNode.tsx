import { memo } from 'react';
import { Handle, Position, NodeProps } from '@xyflow/react';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Zap, 
  Brain, 
  GitBranch, 
  Globe, 
  MessageSquare, 
  Square,
  Settings,
  Upload,
  Download,
  Mail,
  FileText,
  Database,
  Send,
  Code,
  Filter,
  Split,
  Merge,
  Users,
  Webhook,
  Play,
  Timer,
  CheckCircle,
  AlertTriangle,
  Pause,
  UserCheck,
  RotateCcw,
  Calendar,
  Trash2,
  Copy,
  Edit,
  List,
  Hash,
  Type,
  Clock,
  Tag,
  Layers,
  Link,
  Slack
} from 'lucide-react';
import { WorkflowNodeData } from '@/types/WorkflowTypes';

const nodeIcons = {
  // AI Category
  trigger: Zap,
  gpt: Brain,
  qwen: Brain,
  deepseek: Brain,
  mixtral: Brain,
  'text-classifier': Tag,
  'sentiment-analysis': Hash,
  'information-extractor': List,
  'summarization': Type,
  'ai-transform': RotateCcw,
  
  // Action in App Category
  gmail: Mail,
  telegram: Send,
  notion: Database,
  discord: MessageSquare,
  slack: MessageSquare,
  airtable: Database,
  'google-sheets': FileText,
  whatsapp: MessageSquare,
  
  // Data Transformation Category
  'ai-data-transform': RotateCcw,
  code: Code,
  'edit-fields': Edit,
  'date-time': Calendar,
  'filter-data': Filter,
  'split-join': Split,
  'remove-duplicates': Copy,
  
  // Flow Control Category
  condition: GitBranch,
  merge: Merge,
  loop: RotateCcw,
  compare: GitBranch,
  'throw-error': AlertTriangle,
  'sub-workflow': Layers,
  
  // Core Category
  webhook: Webhook,
  'execute-code': Code,
  'http-request': Globe,
  'store-db': Database,
  'log-supabase': FileText,
  variables: Settings,
  
  // Human in Loop Category
  'wait-approval': UserCheck,
  'decision-email': Mail,
  'pause-user': Pause,
  
  // Basic Category
  api: Globe,
  reply: MessageSquare,
  end: Square,
  upload: Upload,
  download: Download,
  docs: FileText,
  agent: Brain,
  
  // New custom node types
  'google-sheets-reader': FileText,
  'discord-webhook': MessageSquare,
  'custom-code-runner': Code,
};

const nodeColors = {
  // AI Category - Purple shades
  trigger: 'from-green-500 to-green-600',
  gpt: 'from-purple-500 to-purple-600',
  qwen: 'from-purple-400 to-purple-500',
  deepseek: 'from-purple-600 to-purple-700',
  mixtral: 'from-purple-500 to-purple-700',
  'text-classifier': 'from-purple-400 to-purple-600',
  'sentiment-analysis': 'from-purple-500 to-purple-700',
  'information-extractor': 'from-purple-600 to-purple-800',
  'summarization': 'from-purple-400 to-purple-600',
  'ai-transform': 'from-purple-500 to-purple-700',
  
  // Action in App Category - Blue shades
  gmail: 'from-red-400 to-red-500',
  telegram: 'from-blue-500 to-blue-600',
  notion: 'from-gray-600 to-gray-700',
  discord: 'from-indigo-500 to-indigo-600',
  slack: 'from-green-500 to-green-600',
  airtable: 'from-yellow-500 to-yellow-600',
  'google-sheets': 'from-green-400 to-green-500',
  whatsapp: 'from-green-600 to-green-700',
  
  // Data Transformation Category - Orange shades
  'ai-data-transform': 'from-orange-400 to-orange-500',
  code: 'from-orange-500 to-orange-600',
  'edit-fields': 'from-orange-400 to-orange-600',
  'date-time': 'from-orange-500 to-orange-700',
  'filter-data': 'from-orange-400 to-orange-500',
  'split-join': 'from-orange-500 to-orange-600',
  'remove-duplicates': 'from-orange-600 to-orange-700',
  
  // Flow Control Category - Cyan shades
  condition: 'from-cyan-500 to-cyan-600',
  merge: 'from-cyan-400 to-cyan-500',
  loop: 'from-cyan-500 to-cyan-700',
  compare: 'from-cyan-400 to-cyan-600',
  'throw-error': 'from-red-500 to-red-600',
  'sub-workflow': 'from-cyan-600 to-cyan-700',
  
  // Core Category - Gray shades
  webhook: 'from-gray-500 to-gray-600',
  'execute-code': 'from-gray-600 to-gray-700',
  'http-request': 'from-blue-500 to-blue-600',
  'store-db': 'from-gray-500 to-gray-700',
  'log-supabase': 'from-gray-400 to-gray-600',
  variables: 'from-gray-500 to-gray-600',
  
  // Human in Loop Category - Pink shades
  'wait-approval': 'from-pink-500 to-pink-600',
  'decision-email': 'from-pink-400 to-pink-500',
  'pause-user': 'from-pink-500 to-pink-700',
  
  // Basic Category
  api: 'from-blue-500 to-blue-600',
  reply: 'from-emerald-500 to-emerald-600',
  end: 'from-red-500 to-red-600',
  upload: 'from-indigo-500 to-indigo-600',
  download: 'from-cyan-500 to-cyan-600',
  docs: 'from-blue-400 to-blue-500',
  agent: 'from-purple-600 to-purple-800',
  
  // New custom node types  
  'google-sheets-reader': 'from-green-500 to-green-600',
  'discord-webhook': 'from-indigo-500 to-purple-600',
  'custom-code-runner': 'from-orange-500 to-red-600',
};

const categoryColors = {
  'ai': 'border-purple-500/30',
  'action': 'border-blue-500/30',
  'transformation': 'border-orange-500/30',
  'flow-control': 'border-cyan-500/30',
  'core': 'border-gray-500/30',
  'human-loop': 'border-pink-500/30',
  'basic': 'border-green-500/30',
};

interface WorkflowNodeProps extends NodeProps {
  data: WorkflowNodeData;
}

function WorkflowNode({ data, selected, id }: WorkflowNodeProps) {
  const Icon = nodeIcons[data.type as keyof typeof nodeIcons];
  const colorClass = nodeColors[data.type as keyof typeof nodeColors];
  const categoryBorder = categoryColors[data.category as keyof typeof categoryColors];

  const handleTestNode = (e: React.MouseEvent) => {
    e.stopPropagation();
    console.log(`Testing node: ${id}`);
    // This would trigger individual node testing
  };

  return (
    <Card className={`min-w-48 bg-gray-900/95 border-2 transition-all duration-300 relative backdrop-blur-sm ${
      selected ? `border-green-400 shadow-lg shadow-green-400/50 scale-105` : `border-gray-600 hover:border-gray-400 hover:shadow-lg hover:shadow-blue-400/25 ${categoryBorder}`
    } ${data.isExecuting ? 'ring-2 ring-yellow-400 animate-pulse' : ''}`}>
      <div className="p-4">
        <div className="flex items-center space-x-3 mb-2">
          <div className={`w-10 h-10 bg-gradient-to-r ${colorClass} rounded-xl flex items-center justify-center shadow-lg`}>
            <Icon className="h-5 w-5 text-white" />
          </div>
          <div className="flex-1">
            <span className="font-semibold text-white text-sm">{data.label}</span>
            <div className="flex items-center space-x-1 mt-1">
              <span className="text-xs text-gray-400 capitalize">{data.category?.replace('-', ' ')}</span>
              <span className="text-xs text-gray-500">•</span>
              <span className="text-xs text-gray-400 capitalize">{data.type?.replace('-', ' ')}</span>
            </div>
          </div>
          <div className="flex items-center space-x-1">
            <Button
              size="sm"
              variant="ghost"
              onClick={handleTestNode}
              className="h-6 w-6 p-0 text-gray-400 hover:text-green-400"
              title="Test this node"
            >
              <Play className="h-3 w-3" />
            </Button>
            <Settings className="h-4 w-4 text-gray-400 ml-auto cursor-pointer hover:text-white transition-colors" />
          </div>
        </div>
        
        {data.executionResult && (
          <div className={`mt-3 p-2 rounded-lg text-xs border ${
            data.executionResult.success 
              ? 'bg-green-900/30 text-green-300 border-green-500/30' 
              : 'bg-red-900/30 text-red-300 border-red-500/30'
          }`}>
            <div className="font-medium flex items-center space-x-1">
              {data.executionResult.success ? (
                <CheckCircle className="h-3 w-3" />
              ) : (
                <AlertTriangle className="h-3 w-3" />
              )}
              <span>{data.executionResult.success ? 'Success' : 'Error'}</span>
            </div>
            {data.executionResult.output && (
              <div className="mt-1 text-gray-300 font-mono text-xs truncate">{data.executionResult.output}</div>
            )}
            {data.executionResult.error && (
              <div className="mt-1 text-red-400 font-mono text-xs truncate">{data.executionResult.error}</div>
            )}
          </div>
        )}

        {/* Custom configuration displays for new node types */}
        {data.type === 'google-sheets-reader' && data.config?.spreadsheetId && (
          <div className="mt-3 p-2 bg-green-900/20 rounded text-xs">
            <div className="flex items-center space-x-1 text-green-300">
              <Link className="h-3 w-3" />
              <span>Sheet Connected</span>
            </div>
            {data.config.range && (
              <div className="text-green-400 mt-1">Range: {data.config.range}</div>
            )}
          </div>
        )}

        {data.type === 'discord-webhook' && data.config?.webhookUrl && (
          <div className="mt-3 p-2 bg-indigo-900/20 rounded text-xs">
            <div className="flex items-center space-x-1 text-indigo-300">
              <Link className="h-3 w-3" />
              <span>Webhook Ready</span>
            </div>
          </div>
        )}

        {data.type === 'custom-code-runner' && data.config?.jsCode && (
          <div className="mt-3 p-2 bg-orange-900/20 rounded text-xs">
            <div className="flex items-center space-x-1 text-orange-300">
              <Code className="h-3 w-3" />
              <span>Code Ready</span>
            </div>
          </div>
        )}

        {data.category === 'ai' && data.config && (
          <div className="mt-3 space-y-1">
            <div className="text-xs text-gray-400 font-medium">AI Configuration:</div>
            <div className="flex flex-wrap gap-1">
              {data.config.model && (
                <span className="px-2 py-1 bg-purple-600/20 text-purple-300 rounded text-xs">{data.config.model}</span>
              )}
              {data.config.memory && (
                <span className="px-2 py-1 bg-blue-600/20 text-blue-300 rounded text-xs">{data.config.memory}</span>
              )}
              {data.config.tools && data.config.tools.length > 0 && (
                <span className="px-2 py-1 bg-green-600/20 text-green-300 rounded text-xs">{data.config.tools.length} tools</span>
              )}
            </div>
          </div>
        )}

        {data.category === 'action' && data.config?.apiKey && (
          <div className="mt-3 p-2 bg-blue-900/20 rounded text-xs">
            <div className="flex items-center space-x-1 text-blue-300">
              <Link className="h-3 w-3" />
              <span>Connected</span>
            </div>
          </div>
        )}
      </div>
      
      {data.type !== 'trigger' && data.type !== 'webhook' && (
        <Handle
          type="target"
          position={Position.Top}
          className="w-4 h-4 bg-gray-700 border-2 border-blue-400 rounded-full shadow-lg shadow-blue-400/50 hover:bg-blue-400 hover:shadow-blue-400/75 transition-all"
        />
      )}
      
      {data.type !== 'end' && data.type !== 'pause-user' && (
        <Handle
          type="source"
          position={Position.Bottom}
          className="w-4 h-4 bg-gray-700 border-2 border-green-400 rounded-full shadow-lg shadow-green-400/50 hover:bg-green-400 hover:shadow-green-400/75 transition-all"
        />
      )}
    </Card>
  );
}

export default memo(WorkflowNode);

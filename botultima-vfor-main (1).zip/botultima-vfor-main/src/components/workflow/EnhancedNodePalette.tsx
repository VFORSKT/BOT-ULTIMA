
import { useState, useMemo } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Search, 
  Zap, 
  Brain, 
  Settings, 
  Database, 
  MessageSquare,
  Cloud,
  Shield,
  Code,
  Workflow,
  Bot,
  Mail,
  Phone,
  FileText,
  Calendar,
  Calculator,
  Image,
  Video,
  Music,
  Globe,
  Lock,
  Key,
  Filter,
  Shuffle,
  Copy,
  Clock
} from 'lucide-react';

interface NodeCategory {
  id: string;
  name: string;
  icon: React.ReactNode;
  color: string;
  nodes: NodeType[];
}

interface NodeType {
  type: string;
  label: string;
  description: string;
  icon: React.ReactNode;
  category: string;
  isNew?: boolean;
  isPro?: boolean;
}

interface EnhancedNodePaletteProps {
  onDragStart: (event: React.DragEvent, nodeType: string, category: string) => void;
}

const EnhancedNodePalette = ({ onDragStart }: EnhancedNodePaletteProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const nodeCategories: NodeCategory[] = useMemo(() => [
    {
      id: 'ai',
      name: 'AI & ML',
      icon: <Brain className="h-4 w-4" />,
      color: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
      nodes: [
        { type: 'gpt', label: 'OpenAI GPT', description: 'Generate text with GPT models', icon: <Brain className="h-4 w-4" />, category: 'ai', isNew: true },
        { type: 'qwen', label: 'Qwen', description: 'Alibaba AI model', icon: <Bot className="h-4 w-4" />, category: 'ai' },
        { type: 'deepseek', label: 'DeepSeek', description: 'DeepSeek AI model', icon: <Brain className="h-4 w-4" />, category: 'ai' },
        { type: 'mixtral', label: 'Mixtral', description: 'Mistral AI model', icon: <Zap className="h-4 w-4" />, category: 'ai' },
        { type: 'text-classifier', label: 'Text Classifier', description: 'Classify text content', icon: <Filter className="h-4 w-4" />, category: 'ai' },
        { type: 'sentiment-analysis', label: 'Sentiment Analysis', description: 'Analyze text sentiment', icon: <MessageSquare className="h-4 w-4" />, category: 'ai' },
        { type: 'information-extractor', label: 'Info Extractor', description: 'Extract structured data', icon: <Copy className="h-4 w-4" />, category: 'ai' },
        { type: 'summarization', label: 'Summarization', description: 'Summarize long text', icon: <FileText className="h-4 w-4" />, category: 'ai' },
        { type: 'ai-transform', label: 'AI Transform', description: 'Transform data with AI', icon: <Shuffle className="h-4 w-4" />, category: 'ai' },
      ]
    },
    {
      id: 'trigger',
      name: 'Triggers',
      icon: <Zap className="h-4 w-4" />,
      color: 'bg-green-500/20 text-green-300 border-green-500/30',
      nodes: [
        { type: 'trigger', label: 'Manual Trigger', description: 'Start workflow manually', icon: <Zap className="h-4 w-4" />, category: 'core' },
        { type: 'webhook', label: 'Webhook', description: 'Trigger via HTTP request', icon: <Globe className="h-4 w-4" />, category: 'core' },
        { type: 'scheduler', label: 'Schedule', description: 'Time-based trigger', icon: <Calendar className="h-4 w-4" />, category: 'core' },
        { type: 'timer', label: 'Timer', description: 'Delay execution', icon: <Clock className="h-4 w-4" />, category: 'core' },
      ]
    },
    {
      id: 'communication',
      name: 'Communication',
      icon: <MessageSquare className="h-4 w-4" />,
      color: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
      nodes: [
        { type: 'gmail', label: 'Gmail', description: 'Send and receive emails', icon: <Mail className="h-4 w-4" />, category: 'communication' },
        { type: 'telegram', label: 'Telegram', description: 'Telegram bot integration', icon: <MessageSquare className="h-4 w-4" />, category: 'communication' },
        { type: 'discord', label: 'Discord', description: 'Discord bot integration', icon: <MessageSquare className="h-4 w-4" />, category: 'communication' },
        { type: 'slack', label: 'Slack', description: 'Slack workspace integration', icon: <MessageSquare className="h-4 w-4" />, category: 'communication' },
        { type: 'whatsapp', label: 'WhatsApp', description: 'WhatsApp Business API', icon: <Phone className="h-4 w-4" />, category: 'communication', isPro: true },
        { type: 'email-sender', label: 'Email Sender', description: 'Send custom emails', icon: <Mail className="h-4 w-4" />, category: 'communication' },
        { type: 'sms-sender', label: 'SMS Sender', description: 'Send SMS messages', icon: <Phone className="h-4 w-4" />, category: 'communication' },
      ]
    },
    {
      id: 'database',
      name: 'Databases',
      icon: <Database className="h-4 w-4" />,
      color: 'bg-orange-500/20 text-orange-300 border-orange-500/30',
      nodes: [
        { type: 'mysql-db', label: 'MySQL', description: 'MySQL database operations', icon: <Database className="h-4 w-4" />, category: 'database' },
        { type: 'postgresql-db', label: 'PostgreSQL', description: 'PostgreSQL operations', icon: <Database className="h-4 w-4" />, category: 'database' },
        { type: 'mongodb', label: 'MongoDB', description: 'MongoDB operations', icon: <Database className="h-4 w-4" />, category: 'database' },
        { type: 'store-db', label: 'Store Data', description: 'Store data in database', icon: <Database className="h-4 w-4" />, category: 'database' },
        { type: 'log-supabase', label: 'Supabase Log', description: 'Log to Supabase', icon: <Database className="h-4 w-4" />, category: 'database' },
      ]
    },
    {
      id: 'integration',
      name: 'Integrations',
      icon: <Cloud className="h-4 w-4" />,
      color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
      nodes: [
        { type: 'notion', label: 'Notion', description: 'Notion workspace integration', icon: <FileText className="h-4 w-4" />, category: 'action' },
        { type: 'airtable', label: 'Airtable', description: 'Airtable database', icon: <Database className="h-4 w-4" />, category: 'action' },
        { type: 'google-sheets', label: 'Google Sheets', description: 'Google Sheets integration', icon: <FileText className="h-4 w-4" />, category: 'action' },
        { type: 'google-sheets-reader', label: 'Sheets Reader', description: 'Read Google Sheets data', icon: <FileText className="h-4 w-4" />, category: 'action' },
        { type: 'discord-webhook', label: 'Discord Webhook', description: 'Send Discord messages', icon: <MessageSquare className="h-4 w-4" />, category: 'action' },
      ]
    },
    {
      id: 'transformation',
      name: 'Data Transform',
      icon: <Settings className="h-4 w-4" />,
      color: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
      nodes: [
        { type: 'ai-data-transform', label: 'AI Transform', description: 'Transform data with AI', icon: <Brain className="h-4 w-4" />, category: 'transformation' },
        { type: 'code', label: 'Code Block', description: 'Execute custom code', icon: <Code className="h-4 w-4" />, category: 'transformation' },
        { type: 'edit-fields', label: 'Edit Fields', description: 'Modify data fields', icon: <Settings className="h-4 w-4" />, category: 'transformation' },
        { type: 'date-time', label: 'Date/Time', description: 'Format date and time', icon: <Calendar className="h-4 w-4" />, category: 'transformation' },
        { type: 'filter-data', label: 'Filter Data', description: 'Filter data based on conditions', icon: <Filter className="h-4 w-4" />, category: 'transformation' },
        { type: 'split-join', label: 'Split/Join', description: 'Split or join data', icon: <Shuffle className="h-4 w-4" />, category: 'transformation' },
        { type: 'remove-duplicates', label: 'Remove Duplicates', description: 'Remove duplicate entries', icon: <Copy className="h-4 w-4" />, category: 'transformation' },
      ]
    },
    {
      id: 'flow-control',
      name: 'Flow Control',
      icon: <Workflow className="h-4 w-4" />,
      color: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
      nodes: [
        { type: 'condition', label: 'Condition', description: 'Branch based on conditions', icon: <Filter className="h-4 w-4" />, category: 'flow-control' },
        { type: 'merge', label: 'Merge', description: 'Merge multiple inputs', icon: <Shuffle className="h-4 w-4" />, category: 'flow-control' },
        { type: 'loop', label: 'Loop', description: 'Repeat operations', icon: <Workflow className="h-4 w-4" />, category: 'flow-control' },
        { type: 'compare', label: 'Compare', description: 'Compare data values', icon: <Calculator className="h-4 w-4" />, category: 'flow-control' },
        { type: 'throw-error', label: 'Error Handler', description: 'Handle errors', icon: <Shield className="h-4 w-4" />, category: 'flow-control' },
        { type: 'sub-workflow', label: 'Sub Workflow', description: 'Execute sub-workflow', icon: <Workflow className="h-4 w-4" />, category: 'flow-control' },
      ]
    }
  ], []);

  const allNodes = useMemo(() => 
    nodeCategories.flatMap(category => category.nodes),
    [nodeCategories]
  );

  const filteredNodes = useMemo(() => {
    let nodes = selectedCategory === 'all' 
      ? allNodes 
      : nodeCategories.find(cat => cat.id === selectedCategory)?.nodes || [];

    if (searchTerm) {
      nodes = nodes.filter(node => 
        node.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
        node.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return nodes;
  }, [selectedCategory, searchTerm, allNodes, nodeCategories]);

  const handleDragStart = (event: React.DragEvent, nodeType: string, category: string) => {
    onDragStart(event, nodeType, category);
  };

  return (
    <div className="h-full flex flex-col bg-gray-900/50 backdrop-blur-sm">
      {/* Search */}
      <div className="p-4 border-b border-gray-700/50">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search nodes..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-gray-800/50 border-gray-600 text-white placeholder-gray-400"
          />
        </div>
      </div>

      {/* Categories */}
      <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="flex-1 flex flex-col">
        <TabsList className="grid grid-cols-4 gap-1 bg-gray-800/50 m-4">
          <TabsTrigger value="all" className="text-xs">All</TabsTrigger>
          <TabsTrigger value="ai" className="text-xs">AI</TabsTrigger>
          <TabsTrigger value="trigger" className="text-xs">Triggers</TabsTrigger>
          <TabsTrigger value="communication" className="text-xs">Comm</TabsTrigger>
        </TabsList>

        <ScrollArea className="flex-1 px-4">
          <TabsContent value="all" className="mt-0 space-y-2">
            {nodeCategories.map(category => (
              <div key={category.id} className="space-y-2">
                <div className="flex items-center space-x-2 mb-3">
                  {category.icon}
                  <h3 className="text-sm font-semibold text-gray-300">{category.name}</h3>
                </div>
                <div className="grid gap-2 mb-4">
                  {category.nodes.slice(0, 3).map(node => (
                    <NodeCard 
                      key={node.type} 
                      node={node} 
                      onDragStart={handleDragStart}
                      categoryColor={category.color}
                    />
                  ))}
                </div>
              </div>
            ))}
          </TabsContent>

          {nodeCategories.map(category => (
            <TabsContent key={category.id} value={category.id} className="mt-0">
              <div className="grid gap-2">
                {category.nodes.map(node => (
                  <NodeCard 
                    key={node.type} 
                    node={node} 
                    onDragStart={handleDragStart}
                    categoryColor={category.color}
                  />
                ))}
              </div>
            </TabsContent>
          ))}
        </ScrollArea>
      </Tabs>
    </div>
  );
};

const NodeCard = ({ 
  node, 
  onDragStart, 
  categoryColor 
}: { 
  node: NodeType; 
  onDragStart: (event: React.DragEvent, nodeType: string, category: string) => void;
  categoryColor: string;
}) => {
  return (
    <div
      draggable
      onDragStart={(e) => onDragStart(e, node.type, node.category)}
      className="group cursor-grab active:cursor-grabbing p-3 bg-gray-800/60 hover:bg-gray-700/60 border border-gray-600/50 hover:border-gray-500/50 rounded-lg transition-all duration-200 hover:shadow-lg"
    >
      <div className="flex items-start space-x-3">
        <div className={`p-2 rounded-lg ${categoryColor} group-hover:scale-110 transition-transform`}>
          {node.icon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center space-x-2 mb-1">
            <h4 className="text-sm font-medium text-white truncate">{node.label}</h4>
            {node.isNew && (
              <Badge className="bg-green-500/20 text-green-300 border-green-500/30 text-xs px-1 py-0">
                NEW
              </Badge>
            )}
            {node.isPro && (
              <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30 text-xs px-1 py-0">
                PRO
              </Badge>
            )}
          </div>
          <p className="text-xs text-gray-400 line-clamp-2">{node.description}</p>
        </div>
      </div>
    </div>
  );
};

export default EnhancedNodePalette;


import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Save, 
  Play, 
  Rocket,
  Activity,
  Clock,
  CheckCircle,
  AlertTriangle,
  Zap,
  Brain,
  Settings
} from 'lucide-react';

interface FuturisticToolbarProps {
  workflowName: string;
  onWorkflowNameChange: (name: string) => void;
  onSave: () => void;
  onTest: () => void;
  isRunning: boolean;
  workflowStatus: 'draft' | 'saved' | 'deployed' | 'error';
  nodeCount: number;
  connectionCount: number;
}

const FuturisticToolbar = ({
  workflowName,
  onWorkflowNameChange,
  onSave,
  onTest,
  isRunning,
  workflowStatus,
  nodeCount,
  connectionCount
}: FuturisticToolbarProps) => {
  const getStatusConfig = () => {
    switch (workflowStatus) {
      case 'draft': 
        return { 
          color: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
          icon: <Clock className="h-3 w-3" />,
          text: 'Draft'
        };
      case 'saved': 
        return { 
          color: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
          icon: <CheckCircle className="h-3 w-3" />,
          text: 'Saved'
        };
      case 'deployed': 
        return { 
          color: 'bg-green-500/20 text-green-300 border-green-500/30',
          icon: <Rocket className="h-3 w-3" />,
          text: 'Deployed'
        };
      case 'error': 
        return { 
          color: 'bg-red-500/20 text-red-300 border-red-500/30',
          icon: <AlertTriangle className="h-3 w-3" />,
          text: 'Error'
        };
      default: 
        return { 
          color: 'bg-gray-500/20 text-gray-300 border-gray-500/30',
          icon: <Clock className="h-3 w-3" />,
          text: 'Unknown'
        };
    }
  };

  const statusConfig = getStatusConfig();

  return (
    <div className="bg-gray-900/95 border-b border-gray-700/50 backdrop-blur-sm shadow-2xl">
      <div className="flex items-center justify-between px-6 py-4">
        {/* Left Section */}
        <div className="flex items-center space-x-6">
          {/* Logo & Title */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 via-purple-500 to-green-500 rounded-xl flex items-center justify-center shadow-lg relative">
              <Brain className="h-5 w-5 text-white" />
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-green-500 rounded-xl opacity-50 animate-pulse"></div>
            </div>
            <Input
              value={workflowName}
              onChange={(e) => onWorkflowNameChange(e.target.value)}
              className="bg-transparent border-none text-white font-semibold text-xl focus:bg-gray-800/30 min-w-[280px] px-2 py-1 rounded-lg transition-all duration-200"
              placeholder="Untitled Workflow"
            />
          </div>

          {/* Status & Stats */}
          <div className="flex items-center space-x-4">
            <Badge className={`${statusConfig.color} flex items-center space-x-1 shadow-lg`}>
              {statusConfig.icon}
              <span>{statusConfig.text}</span>
            </Badge>

            <div className="flex items-center space-x-6 text-sm text-gray-400">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                <span>{nodeCount} nodes</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                <span>{connectionCount} connections</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Section */}
        <div className="flex items-center space-x-3">
          {/* Test Button */}
          <Button
            onClick={onTest}
            disabled={isRunning}
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg border-0 px-6 py-2 rounded-xl transition-all duration-200 hover:shadow-xl hover:scale-105 disabled:opacity-50 disabled:scale-100"
          >
            {isRunning ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                Running...
              </>
            ) : (
              <>
                <Play className="h-4 w-4 mr-2" />
                Test Run
              </>
            )}
          </Button>

          {/* Save Button */}
          <Button
            onClick={onSave}
            className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white shadow-lg border-0 px-6 py-2 rounded-xl transition-all duration-200 hover:shadow-xl hover:scale-105"
          >
            <Save className="h-4 w-4 mr-2" />
            Save
          </Button>

          {/* Settings */}
          <Button
            variant="ghost"
            size="sm"
            className="text-gray-400 hover:text-white hover:bg-gray-800/50 rounded-xl"
          >
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Glowing bottom border */}
      <div className="h-px bg-gradient-to-r from-transparent via-blue-500/50 to-transparent"></div>
    </div>
  );
};

export default FuturisticToolbar;

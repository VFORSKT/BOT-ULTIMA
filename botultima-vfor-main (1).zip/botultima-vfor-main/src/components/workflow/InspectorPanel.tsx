import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { WorkflowNode, WorkflowNodeData } from '@/types/WorkflowTypes';
import { Brain, Key, TestTube, Settings, Zap, Database } from 'lucide-react';

interface InspectorPanelProps {
  selectedNode: WorkflowNode | null;
  onUpdateNode: (nodeId: string, updates: Partial<WorkflowNodeData>) => void;
}

const InspectorPanel = ({ selectedNode, onUpdateNode }: InspectorPanelProps) => {
  if (!selectedNode) {
    return (
      <Card className="bg-gray-800/50 border-gray-700 h-full backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-sm text-gray-300">Inspector Panel</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-400 text-sm">Select a node to view its properties</p>
        </CardContent>
      </Card>
    );
  }

  const handleConfigUpdate = (key: string, value: any) => {
    onUpdateNode(selectedNode.id, {
      config: {
        ...selectedNode.data.config,
        [key]: value
      }
    });
  };

  const renderNodeConfig = () => {
    const { type, category } = selectedNode.data;
    
    switch (category) {
      case 'database':
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-gray-300">Connection Type</Label>
              <select 
                className="w-full mt-1 bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
                value={selectedNode.data.config?.connectionType || 'host'}
                onChange={(e) => handleConfigUpdate('connectionType', e.target.value)}
              >
                <option value="host">Host/Port</option>
                <option value="string">Connection String</option>
              </select>
            </div>

            {selectedNode.data.config?.connectionType === 'string' ? (
              <div>
                <Label className="text-gray-300">Connection String</Label>
                <Input
                  type="password"
                  value={selectedNode.data.config?.connectionString || ''}
                  onChange={(e) => handleConfigUpdate('connectionString', e.target.value)}
                  placeholder="mysql://user:password@host:port/database"
                  className="bg-gray-700 border-gray-600 text-white mt-1"
                />
              </div>
            ) : (
              <>
                <div>
                  <Label className="text-gray-300">Host</Label>
                  <Input
                    value={selectedNode.data.config?.host || ''}
                    onChange={(e) => handleConfigUpdate('host', e.target.value)}
                    placeholder="localhost"
                    className="bg-gray-700 border-gray-600 text-white mt-1"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Port</Label>
                  <Input
                    type="number"
                    value={selectedNode.data.config?.port || ''}
                    onChange={(e) => handleConfigUpdate('port', parseInt(e.target.value))}
                    placeholder="3306"
                    className="bg-gray-700 border-gray-600 text-white mt-1"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Database</Label>
                  <Input
                    value={selectedNode.data.config?.database || ''}
                    onChange={(e) => handleConfigUpdate('database', e.target.value)}
                    placeholder="my_database"
                    className="bg-gray-700 border-gray-600 text-white mt-1"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Username</Label>
                  <Input
                    value={selectedNode.data.config?.username || ''}
                    onChange={(e) => handleConfigUpdate('username', e.target.value)}
                    placeholder="db_user"
                    className="bg-gray-700 border-gray-600 text-white mt-1"
                  />
                </div>
                <div>
                  <Label className="text-gray-300">Password</Label>
                  <Input
                    type="password"
                    value={selectedNode.data.config?.password || ''}
                    onChange={(e) => handleConfigUpdate('password', e.target.value)}
                    placeholder="password"
                    className="bg-gray-700 border-gray-600 text-white mt-1"
                  />
                </div>
              </>
            )}

            <div>
              <Label className="text-gray-300">SQL Query</Label>
              <Textarea
                value={selectedNode.data.config?.query || ''}
                onChange={(e) => handleConfigUpdate('query', e.target.value)}
                placeholder="SELECT * FROM users WHERE active = 1"
                className="bg-gray-700 border-gray-600 text-white mt-1"
                rows={4}
              />
            </div>
          </div>
        );

      case 'communication':
        if (type === 'email-sender') {
          return (
            <div className="space-y-4">
              <div>
                <Label className="text-gray-300">SMTP Host</Label>
                <Input
                  value={selectedNode.data.config?.smtpHost || ''}
                  onChange={(e) => handleConfigUpdate('smtpHost', e.target.value)}
                  placeholder="smtp.gmail.com"
                  className="bg-gray-700 border-gray-600 text-white mt-1"
                />
              </div>
              <div>
                <Label className="text-gray-300">SMTP Port</Label>
                <Input
                  type="number"
                  value={selectedNode.data.config?.smtpPort || ''}
                  onChange={(e) => handleConfigUpdate('smtpPort', parseInt(e.target.value))}
                  placeholder="587"
                  className="bg-gray-700 border-gray-600 text-white mt-1"
                />
              </div>
              <div>
                <Label className="text-gray-300">From Email</Label>
                <Input
                  type="email"
                  value={selectedNode.data.config?.fromEmail || ''}
                  onChange={(e) => handleConfigUpdate('fromEmail', e.target.value)}
                  placeholder="sender@example.com"
                  className="bg-gray-700 border-gray-600 text-white mt-1"
                />
              </div>
              <div>
                <Label className="text-gray-300">To Email</Label>
                <Input
                  type="email"
                  value={selectedNode.data.config?.toEmail || ''}
                  onChange={(e) => handleConfigUpdate('toEmail', e.target.value)}
                  placeholder="recipient@example.com"
                  className="bg-gray-700 border-gray-600 text-white mt-1"
                />
              </div>
              <div>
                <Label className="text-gray-300">Subject</Label>
                <Input
                  value={selectedNode.data.config?.subject || ''}
                  onChange={(e) => handleConfigUpdate('subject', e.target.value)}
                  placeholder="Email subject"
                  className="bg-gray-700 border-gray-600 text-white mt-1"
                />
              </div>
              <div>
                <Label className="text-gray-300">Email Body</Label>
                <Textarea
                  value={selectedNode.data.config?.emailBody || ''}
                  onChange={(e) => handleConfigUpdate('emailBody', e.target.value)}
                  placeholder="Email content..."
                  className="bg-gray-700 border-gray-600 text-white mt-1"
                  rows={4}
                />
              </div>
            </div>
          );
        }
        // Fall through to existing communication config
        break;

      case 'transformation':
        if (type === 'file-processor') {
          return (
            <div className="space-y-4">
              <div>
                <Label className="text-gray-300">Input Format</Label>
                <select 
                  className="w-full mt-1 bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
                  value={selectedNode.data.config?.fileFormat || 'auto'}
                  onChange={(e) => handleConfigUpdate('fileFormat', e.target.value)}
                >
                  <option value="auto">Auto-detect</option>
                  <option value="csv">CSV</option>
                  <option value="json">JSON</option>
                  <option value="xml">XML</option>
                  <option value="pdf">PDF</option>
                  <option value="docx">DOCX</option>
                </select>
              </div>
              <div>
                <Label className="text-gray-300">Output Format</Label>
                <select 
                  className="w-full mt-1 bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
                  value={selectedNode.data.config?.outputFormat || 'json'}
                  onChange={(e) => handleConfigUpdate('outputFormat', e.target.value)}
                >
                  <option value="json">JSON</option>
                  <option value="csv">CSV</option>
                  <option value="xml">XML</option>
                  <option value="text">Plain Text</option>
                </select>
              </div>
              <div>
                <Label className="text-gray-300">Processing Options</Label>
                <Textarea
                  value={JSON.stringify(selectedNode.data.config?.processingOptions || {}, null, 2)}
                  onChange={(e) => {
                    try {
                      const options = JSON.parse(e.target.value);
                      handleConfigUpdate('processingOptions', options);
                    } catch (error) {
                      // Invalid JSON, ignore
                    }
                  }}
                  placeholder='{"encoding": "utf-8", "delimiter": ","}'
                  className="bg-gray-700 border-gray-600 text-white mt-1 font-mono"
                  rows={3}
                />
              </div>
            </div>
          );
        }
        break;
    }

    switch (type) {
      case 'agent':
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-gray-300">System Prompt</Label>
              <Textarea
                value={selectedNode.data.config?.prompt || ''}
                onChange={(e) => handleConfigUpdate('prompt', e.target.value)}
                placeholder="You are a helpful AI agent. Your role is to..."
                className="bg-gray-700 border-gray-600 text-white mt-1"
                rows={4}
              />
            </div>
            
            <div>
              <Label className="text-gray-300">Model</Label>
              <select 
                className="w-full mt-1 bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
                value={selectedNode.data.config?.model || 'gpt-4o-mini'}
                onChange={(e) => handleConfigUpdate('model', e.target.value)}
              >
                <option value="gpt-4o-mini">GPT-4O Mini (Free)</option>
                <option value="gpt-4o">GPT-4O (Pro)</option>
                <option value="deepseek">DeepSeek (Free)</option>
              </select>
            </div>

            <div>
              <Label className="text-gray-300">Memory Type</Label>
              <select 
                className="w-full mt-1 bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
                value={selectedNode.data.config?.memory || 'short-term'}
                onChange={(e) => handleConfigUpdate('memory', e.target.value)}
              >
                <option value="short-term">Short-term (Session)</option>
                <option value="long-term">Long-term (Persistent)</option>
                <option value="vector">Vector Memory</option>
              </select>
            </div>

            <div>
              <Label className="text-gray-300">Available Tools</Label>
              <div className="mt-2 space-y-2">
                {['web-search', 'calculator', 'file-reader', 'email-sender'].map(tool => (
                  <label key={tool} className="flex items-center space-x-2">
                    <input 
                      type="checkbox" 
                      className="rounded bg-gray-700 border-gray-600"
                      checked={selectedNode.data.config?.tools?.includes(tool) || false}
                      onChange={(e) => {
                        const currentTools = selectedNode.data.config?.tools || [];
                        const newTools = e.target.checked 
                          ? [...currentTools, tool]
                          : currentTools.filter(t => t !== tool);
                        handleConfigUpdate('tools', newTools);
                      }}
                    />
                    <span className="text-white text-sm capitalize">{tool.replace('-', ' ')}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="border-t border-gray-600 pt-3">
              <h4 className="text-gray-300 font-medium mb-2">Agent Components</h4>
              <div className="grid grid-cols-3 gap-2">
                <div className="bg-purple-600/20 p-2 rounded text-center">
                  <Brain className="h-4 w-4 mx-auto mb-1 text-purple-400" />
                  <span className="text-xs text-purple-300">Model</span>
                </div>
                <div className="bg-blue-600/20 p-2 rounded text-center">
                  <Database className="h-4 w-4 mx-auto mb-1 text-blue-400" />
                  <span className="text-xs text-blue-300">Memory</span>
                </div>
                <div className="bg-green-600/20 p-2 rounded text-center">
                  <Settings className="h-4 w-4 mx-auto mb-1 text-green-400" />
                  <span className="text-xs text-green-300">Tools</span>
                </div>
              </div>
            </div>
          </div>
        );

      case 'gpt':
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-gray-300">Prompt</Label>
              <Textarea
                value={selectedNode.data.config?.prompt || ''}
                onChange={(e) => handleConfigUpdate('prompt', e.target.value)}
                placeholder="Enter your AI prompt..."
                className="bg-gray-700 border-gray-600 text-white mt-1"
                rows={4}
              />
            </div>
            <div>
              <Label className="text-gray-300">Model</Label>
              <select 
                className="w-full mt-1 bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
                value={selectedNode.data.config?.model || 'gpt-4o-mini'}
                onChange={(e) => handleConfigUpdate('model', e.target.value)}
              >
                <option value="gpt-4o-mini">GPT-4O Mini</option>
                <option value="gpt-4o">GPT-4O</option>
              </select>
            </div>
          </div>
        );
      
      case 'api':
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-gray-300">API URL</Label>
              <Input
                value={selectedNode.data.config?.apiUrl || ''}
                onChange={(e) => handleConfigUpdate('apiUrl', e.target.value)}
                placeholder="https://api.example.com/endpoint"
                className="bg-gray-700 border-gray-600 text-white mt-1"
              />
            </div>
            <div>
              <Label className="text-gray-300">Method</Label>
              <select 
                className="w-full mt-1 bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
                value={selectedNode.data.config?.method || 'GET'}
                onChange={(e) => handleConfigUpdate('method', e.target.value)}
              >
                <option value="GET">GET</option>
                <option value="POST">POST</option>
                <option value="PUT">PUT</option>
                <option value="DELETE">DELETE</option>
              </select>
            </div>
            <div>
              <Label className="text-gray-300">Headers</Label>
              <Textarea
                value={selectedNode.data.config?.headers || ''}
                onChange={(e) => handleConfigUpdate('headers', e.target.value)}
                placeholder='{"Content-Type": "application/json"}'
                className="bg-gray-700 border-gray-600 text-white mt-1"
                rows={3}
              />
            </div>
          </div>
        );
      
      case 'gmail':
      case 'docs':
      case 'notion':
      case 'airtable':
      case 'telegram':
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-gray-300">API Key</Label>
              <Input
                type="password"
                value={selectedNode.data.config?.apiKey || ''}
                onChange={(e) => handleConfigUpdate('apiKey', e.target.value)}
                placeholder="Enter API key..."
                className="bg-gray-700 border-gray-600 text-white mt-1"
              />
            </div>
            <Button className="w-full bg-blue-600 hover:bg-blue-700">
              <TestTube className="h-4 w-4 mr-2" />
              Test Connection
            </Button>
          </div>
        );
      
      case 'condition':
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-gray-300">Condition</Label>
              <Textarea
                value={selectedNode.data.config?.condition || ''}
                onChange={(e) => handleConfigUpdate('condition', e.target.value)}
                placeholder="if (input.contains('urgent')) { return 'high_priority'; }"
                className="bg-gray-700 border-gray-600 text-white mt-1"
                rows={4}
              />
            </div>
          </div>
        );
      
      default:
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-gray-300">Content</Label>
              <Textarea
                value={selectedNode.data.config?.content || ''}
                onChange={(e) => handleConfigUpdate('content', e.target.value)}
                placeholder="Enter content..."
                className="bg-gray-700 border-gray-600 text-white mt-1"
                rows={3}
              />
            </div>
          </div>
        );
    }
  };

  return (
    <Card className="bg-gray-800/50 border-gray-700 h-full backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-sm text-gray-300 flex items-center justify-between">
          Inspector Panel
          <div className="flex items-center space-x-2">
            <Badge variant="secondary" className="bg-gray-700 text-gray-300">
              {selectedNode.data.type}
            </Badge>
            {selectedNode.data.validationErrors && selectedNode.data.validationErrors.length > 0 && (
              <Badge variant="destructive" className="bg-red-500/20 text-red-400 border-red-500/30">
                {selectedNode.data.validationErrors.length} errors
              </Badge>
            )}
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label className="text-gray-300">Node Label</Label>
          <Input
            value={selectedNode.data.label}
            onChange={(e) => onUpdateNode(selectedNode.id, { label: e.target.value })}
            className="bg-gray-700 border-gray-600 text-white mt-1"
          />
        </div>
        
        {/* Validation Errors */}
        {selectedNode.data.validationErrors && selectedNode.data.validationErrors.length > 0 && (
          <div className="p-3 bg-red-900/20 border border-red-500/30 rounded">
            <h4 className="text-red-300 font-medium mb-2">Validation Errors:</h4>
            {selectedNode.data.validationErrors.map((error, index) => (
              <div key={index} className="text-red-400 text-sm">• {error}</div>
            ))}
          </div>
        )}
        
        {renderNodeConfig()}
        
        <div className="border-t border-gray-600 pt-4">
          <Button className="w-full bg-purple-600 hover:bg-purple-700 mb-2">
            <Brain className="h-4 w-4 mr-2" />
            AI Improve This Step
          </Button>
          
          <div className="text-xs text-gray-400 space-y-2">
            <div>
              <strong>Expected Input:</strong> Previous node output
            </div>
            <div>
              <strong>Expected Output:</strong> Processed data for next node
            </div>
            {selectedNode.data.type === 'agent' && (
              <div className="mt-2 p-2 bg-purple-900/20 rounded">
                <strong className="text-purple-300">AI Agent:</strong> This node can use multiple models, maintain memory, and access tools for complex reasoning.
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default InspectorPanel;

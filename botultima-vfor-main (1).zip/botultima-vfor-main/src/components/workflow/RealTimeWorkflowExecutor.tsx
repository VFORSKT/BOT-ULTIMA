import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { Play, Square, RotateCcw, Zap, Clock, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { WorkflowExecutionEngine, ExecutionResult } from '@/services/WorkflowExecutionEngine';
import { SerializedFlowData } from '@/types/WorkflowTypes';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface RealTimeWorkflowExecutorProps {
  workflow: SerializedFlowData;
  workflowId: string;
  userId: string;
  onExecutionUpdate?: (nodeId: string, result: ExecutionResult) => void;
}

interface ExecutionLog {
  id: string;
  nodeId: string;
  nodeName: string;
  status: 'running' | 'completed' | 'failed';
  timestamp: Date;
  duration?: number;
  result?: ExecutionResult;
  message: string;
}

const RealTimeWorkflowExecutor = ({ 
  workflow, 
  workflowId, 
  userId, 
  onExecutionUpdate 
}: RealTimeWorkflowExecutorProps) => {
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionLogs, setExecutionLogs] = useState<ExecutionLog[]>([]);
  const [currentNodeId, setCurrentNodeId] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [executionStats, setExecutionStats] = useState({
    totalNodes: 0,
    executedNodes: 0,
    successfulNodes: 0,
    failedNodes: 0
  });
  const { toast } = useToast();

  useEffect(() => {
    // Set up real-time subscription for execution updates
    const channel = supabase
      .channel('workflow-executions')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'workflow_executions',
          filter: `user_id=eq.${userId}`
        },
        (payload) => {
          console.log('Real-time execution update:', payload);
          handleExecutionUpdate(payload.new);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId]);

  const handleExecutionUpdate = (executionData: any) => {
    if (executionData.execution_data?.currentNode) {
      setCurrentNodeId(executionData.execution_data.currentNode);
    }
    
    const progressPercentage = (executionData.nodes_executed / executionData.total_nodes) * 100;
    setProgress(progressPercentage);
  };

  const startExecution = async () => {
    setIsExecuting(true);
    setExecutionLogs([]);
    setProgress(0);
    setCurrentNodeId(null);
    
    const totalNodes = workflow.nodes.length;
    setExecutionStats({
      totalNodes,
      executedNodes: 0,
      successfulNodes: 0,
      failedNodes: 0
    });

    try {
      const engine = new WorkflowExecutionEngine(
        workflow,
        {
          userId,
          workflowId,
          data: { trigger: 'manual', timestamp: new Date().toISOString() }
        },
        {
          onNodeExecuted: (nodeId: string, result: ExecutionResult) => {
            handleNodeExecuted(nodeId, result);
            onExecutionUpdate?.(nodeId, result);
          },
          onExecutionUpdate: (update: any) => {
            console.log('Execution update:', update);
          }
        }
      );

      const result = await engine.execute();
      
      if (result.success) {
        toast({
          title: "Workflow Completed",
          description: "All nodes executed successfully",
        });
      } else {
        toast({
          title: "Workflow Failed",
          description: result.error || "Execution failed",
          variant: "destructive",
        });
      }
      
    } catch (error) {
      console.error('Execution error:', error);
      toast({
        title: "Execution Error",
        description: "Failed to execute workflow",
        variant: "destructive",
      });
    } finally {
      setIsExecuting(false);
      setCurrentNodeId(null);
    }
  };

  const handleNodeExecuted = (nodeId: string, result: ExecutionResult) => {
    const node = workflow.nodes.find(n => n.id === nodeId);
    const nodeName = node?.data.label || nodeId;
    
    const logEntry: ExecutionLog = {
      id: crypto.randomUUID(),
      nodeId,
      nodeName,
      status: result.success ? 'completed' : 'failed',
      timestamp: new Date(),
      duration: result.executionTime,
      result,
      message: result.success 
        ? `${nodeName} executed successfully`
        : `${nodeName} failed: ${result.error}`
    };
    
    setExecutionLogs(prev => [...prev, logEntry]);
    
    setExecutionStats(prev => ({
      ...prev,
      executedNodes: prev.executedNodes + 1,
      successfulNodes: result.success ? prev.successfulNodes + 1 : prev.successfulNodes,
      failedNodes: result.success ? prev.failedNodes : prev.failedNodes + 1
    }));
  };

  const stopExecution = () => {
    setIsExecuting(false);
    setCurrentNodeId(null);
    toast({
      title: "Execution Stopped",
      description: "Workflow execution has been stopped",
    });
  };

  const clearLogs = () => {
    setExecutionLogs([]);
    setProgress(0);
    setExecutionStats({
      totalNodes: workflow.nodes.length,
      executedNodes: 0,
      successfulNodes: 0,
      failedNodes: 0
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'running':
        return <Clock className="h-4 w-4 text-yellow-500 animate-pulse" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-4">
      {/* Execution Controls */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-white flex items-center">
              <Zap className="h-5 w-5 mr-2 text-green-400" />
              Workflow Executor
            </CardTitle>
            <div className="flex items-center space-x-2">
              <Button
                onClick={startExecution}
                disabled={isExecuting}
                className="bg-green-600 hover:bg-green-700"
              >
                <Play className="h-4 w-4 mr-2" />
                {isExecuting ? 'Running...' : 'Execute'}
              </Button>
              {isExecuting && (
                <Button
                  onClick={stopExecution}
                  variant="destructive"
                  size="sm"
                >
                  <Square className="h-4 w-4 mr-2" />
                  Stop
                </Button>
              )}
              <Button
                onClick={clearLogs}
                variant="outline"
                size="sm"
                className="border-gray-600"
              >
                <RotateCcw className="h-4 w-4 mr-2" />
                Clear
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-gray-400">
              <span>Progress</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Execution Stats */}
          <div className="grid grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-white">{executionStats.totalNodes}</div>
              <div className="text-xs text-gray-400">Total Nodes</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-400">{executionStats.executedNodes}</div>
              <div className="text-xs text-gray-400">Executed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-400">{executionStats.successfulNodes}</div>
              <div className="text-xs text-gray-400">Successful</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-400">{executionStats.failedNodes}</div>
              <div className="text-xs text-gray-400">Failed</div>
            </div>
          </div>

          {/* Current Executing Node */}
          {currentNodeId && (
            <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3">
              <div className="flex items-center space-x-2">
                <Clock className="h-4 w-4 text-yellow-500 animate-pulse" />
                <span className="text-yellow-400 text-sm">
                  Currently executing: {workflow.nodes.find(n => n.id === currentNodeId)?.data.label || currentNodeId}
                </span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Execution Log */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-white text-lg">Execution Log</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-96">
            {executionLogs.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No execution logs yet. Start a workflow to see real-time updates.
              </div>
            ) : (
              <div className="space-y-2">
                {executionLogs.map((log) => (
                  <div
                    key={log.id}
                    className="flex items-center justify-between p-3 bg-gray-900/50 rounded-lg border border-gray-700"
                  >
                    <div className="flex items-center space-x-3">
                      {getStatusIcon(log.status)}
                      <div>
                        <div className="text-white text-sm font-medium">{log.nodeName}</div>
                        <div className="text-gray-400 text-xs">{log.message}</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge
                        className={
                          log.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                          log.status === 'failed' ? 'bg-red-500/20 text-red-400' :
                          'bg-yellow-500/20 text-yellow-400'
                        }
                      >
                        {log.status}
                      </Badge>
                      {log.duration && (
                        <span className="text-xs text-gray-500">
                          {log.duration}ms
                        </span>
                      )}
                      <span className="text-xs text-gray-500">
                        {log.timestamp.toLocaleTimeString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
};

export default RealTimeWorkflowExecutor;


import { useCallback, useRef, useState, useEffect } from 'react';
import {
  ReactFlow,
  Background,
  Controls,
  useNodesState,
  useEdgesState,
  addEdge,
  Connection,
  Edge,
  Node,
  OnConnect,
  useReactFlow,
  BackgroundVariant,
  Panel,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import WorkflowNode from './WorkflowNode';
import FuturisticMinimap from './FuturisticMinimap';
import WorkflowTimeline from './WorkflowTimeline';
import FuturisticToolbar from './FuturisticToolbar';
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { WorkflowNode as WorkflowNodeType, WorkflowEdge, WorkflowNodeData } from '@/types/WorkflowTypes';

const nodeTypes = {
  workflowNode: WorkflowNode,
};

interface WorkflowCanvasProps {
  onSave: (nodes: WorkflowNodeType[], edges: WorkflowEdge[]) => void;
  initialNodes?: WorkflowNodeType[];
  initialEdges?: WorkflowEdge[];
  onNodeSelect: (node: WorkflowNodeType | null) => void;
  selectedNode: WorkflowNodeType | null;
  onUpdateNode: (nodeId: string, updates: Partial<WorkflowNodeData>) => void;
}

const WorkflowCanvas = ({ 
  onSave, 
  initialNodes = [], 
  initialEdges = [], 
  onNodeSelect, 
  selectedNode,
  onUpdateNode 
}: WorkflowCanvasProps) => {
  const reactFlowWrapper = useRef<HTMLDivElement>(null);
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [isRunning, setIsRunning] = useState(false);
  const [workflowName, setWorkflowName] = useState('Untitled Workflow');
  const [workflowStatus, setWorkflowStatus] = useState<'draft' | 'saved' | 'deployed' | 'error'>('draft');
  const [executionTimeline, setExecutionTimeline] = useState<Array<{
    nodeId: string;
    nodeName: string;
    timestamp: Date;
    duration: number;
    status: 'running' | 'success' | 'error';
  }>>([]);
  const [zoom, setZoom] = useState(1);
  const { screenToFlowPosition, getZoom, fitView } = useReactFlow();

  // Track zoom changes
  useEffect(() => {
    const interval = setInterval(() => {
      setZoom(getZoom());
    }, 100);
    return () => clearInterval(interval);
  }, [getZoom]);

  const onConnect: OnConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge({
      ...params,
      style: { 
        stroke: 'url(#glowing-gradient)',
        strokeWidth: 3,
        filter: 'drop-shadow(0 0 8px rgba(96, 165, 250, 0.8))',
      },
      animated: true,
    }, eds)),
    [setEdges]
  );

  const onDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (event: React.DragEvent) => {
      event.preventDefault();

      const reactFlowBounds = reactFlowWrapper.current?.getBoundingClientRect();
      const type = event.dataTransfer.getData('application/reactflow');
      const category = event.dataTransfer.getData('node-category') || 'basic';

      if (typeof type === 'undefined' || !type || !reactFlowBounds) {
        return;
      }

      const position = screenToFlowPosition({
        x: event.clientX - reactFlowBounds.left,
        y: event.clientY - reactFlowBounds.top,
      });

      const newNode: WorkflowNodeType = {
        id: `${type}-${Date.now()}`,
        type: 'workflowNode',
        position,
        data: {
          label: type.charAt(0).toUpperCase() + type.slice(1).replace('-', ' '),
          type: type as WorkflowNodeData['type'],
          category: category as WorkflowNodeData['category'],
          config: {},
        },
      };

      setNodes((nds) => nds.concat(newNode));
    },
    [screenToFlowPosition, setNodes]
  );

  const onNodeClick = useCallback((event: React.MouseEvent, node: Node) => {
    onNodeSelect(node as WorkflowNodeType);
  }, [onNodeSelect]);

  const onPaneClick = useCallback(() => {
    onNodeSelect(null);
  }, [onNodeSelect]);

  const simulateNodeExecution = async (node: WorkflowNodeType): Promise<{ success: boolean; output?: string; error?: string }> => {
    const startTime = Date.now();
    
    // Add to timeline
    setExecutionTimeline(prev => [...prev, {
      nodeId: node.id,
      nodeName: node.data.label,
      timestamp: new Date(),
      duration: 0,
      status: 'running'
    }]);

    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
    
    const duration = Date.now() - startTime;
    const success = Math.random() > 0.2; // 80% success rate

    // Update timeline
    setExecutionTimeline(prev => prev.map(item => 
      item.nodeId === node.id && item.status === 'running'
        ? { ...item, duration, status: success ? 'success' : 'error' }
        : item
    ));

    if (success) {
      return { success: true, output: `${node.data.type} completed successfully` };
    } else {
      return { success: false, error: 'Simulated execution failed' };
    }
  };

  const handleTest = useCallback(async () => {
    setIsRunning(true);
    setExecutionTimeline([]);
    
    // Clear previous results
    setNodes((nds) => 
      nds.map((node) => ({
        ...node,
        data: { ...node.data, isExecuting: false, executionResult: undefined }
      }))
    );

    const triggerNodes = nodes.filter(node => node.data.type === 'trigger' || node.data.type === 'webhook');
    if (triggerNodes.length === 0) {
      toast({
        title: "No Trigger Found",
        description: "Add a trigger or webhook node to start the workflow.",
        variant: "destructive",
      });
      setIsRunning(false);
      return;
    }

    // Execute nodes in sequence
    const executionOrder: WorkflowNodeType[] = [];
    const visited = new Set<string>();
    
    const traverse = (nodeId: string) => {
      if (visited.has(nodeId)) return;
      visited.add(nodeId);
      
      const node = nodes.find(n => n.id === nodeId);
      if (node) {
        executionOrder.push(node);
        const outgoingEdges = edges.filter(edge => edge.source === nodeId);
        outgoingEdges.forEach(edge => traverse(edge.target));
      }
    };

    triggerNodes.forEach(trigger => traverse(trigger.id));

    for (const node of executionOrder) {
      // Set node as executing with LED ripple effect
      setNodes((nds) => 
        nds.map((n) => ({
          ...n,
          data: { ...n.data, isExecuting: n.id === node.id }
        }))
      );

      const result = await simulateNodeExecution(node);
      
      // Update node with results
      setNodes((nds) => 
        nds.map((n) => 
          n.id === node.id 
            ? { ...n, data: { ...n.data, isExecuting: false, executionResult: result } }
            : n
        )
      );
    }

    setIsRunning(false);
    
    // Show confetti animation for successful workflow
    const hasErrors = executionTimeline.some(item => item.status === 'error');
    if (!hasErrors) {
      toast({
        title: "🎉 Workflow Complete!",
        description: `Successfully executed ${executionOrder.length} nodes.`,
      });
    }
  }, [nodes, edges, setNodes, executionTimeline]);

  const handleSave = async () => {
    try {
      const user = await supabase.auth.getUser();
      if (!user.data.user) {
        toast({
          title: "Authentication Required",
          description: "Please log in to save your workflow.",
          variant: "destructive",
        });
        return;
      }

      // Helper function to serialize edge labels safely
      const serializeEdgeLabel = (label: any): string | null => {
        if (typeof label === 'string' || typeof label === 'number') {
          return String(label);
        }
        return null; // Remove React elements and complex objects
      };

      // Serialize the workflow data to ensure JSON compatibility
      const flowData = {
        nodes: nodes.map(node => ({
          id: node.id,
          type: node.type || 'workflowNode',
          position: {
            x: node.position.x,
            y: node.position.y
          },
          data: {
            label: node.data.label,
            type: node.data.type,
            category: node.data.category,
            config: node.data.config || {},
            // Only include serializable properties
            ...(node.data.isExecuting !== undefined && { isExecuting: node.data.isExecuting }),
            ...(node.data.executionResult && { 
              executionResult: {
                success: node.data.executionResult.success,
                output: node.data.executionResult.output || null,
                error: node.data.executionResult.error || null
              }
            }),
            ...(node.data.validationErrors && { validationErrors: node.data.validationErrors }),
            ...(node.data.isValid !== undefined && { isValid: node.data.isValid })
          }
        })),
        edges: edges.map(edge => ({
          id: edge.id,
          source: edge.source,
          target: edge.target,
          ...(edge.type && { type: edge.type }),
          ...(edge.label && { label: serializeEdgeLabel(edge.label) }),
          ...(edge.animated !== undefined && { animated: edge.animated })
        })),
        timestamp: new Date().toISOString()
      };

      const { error } = await supabase
        .from('bots')
        .insert({
          name: workflowName,
          description: 'Bot created with SixMorph Visual Builder',
          flow_data: flowData,
          user_id: user.data.user.id,
        });

      if (error) {
        console.error('Error saving workflow:', error);
        setWorkflowStatus('error');
        toast({
          title: "Save Failed",
          description: "Could not save workflow to database.",
          variant: "destructive",
        });
        return;
      }

      onSave(nodes, edges);
      setWorkflowStatus('saved');
      toast({
        title: "✨ Workflow Saved",
        description: "Your workflow has been saved successfully.",
      });
    } catch (error) {
      console.error('Error saving workflow:', error);
      setWorkflowStatus('error');
      toast({
        title: "Save Failed", 
        description: "An error occurred while saving.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="h-full w-full bg-gray-950 flex flex-col relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-purple-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <FuturisticToolbar
        workflowName={workflowName}
        onWorkflowNameChange={setWorkflowName}
        onSave={handleSave}
        onTest={handleTest}
        isRunning={isRunning}
        workflowStatus={workflowStatus}
        nodeCount={nodes.length}
        connectionCount={edges.length}
      />

      <div className="flex-1 relative" ref={reactFlowWrapper}>
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          onDrop={onDrop}
          onDragOver={onDragOver}
          onNodeClick={onNodeClick}
          onPaneClick={onPaneClick}
          nodeTypes={nodeTypes}
          fitView
          className="workflow-canvas"
          defaultEdgeOptions={{
            style: { 
              stroke: 'url(#glowing-gradient)',
              strokeWidth: 3,
              filter: 'drop-shadow(0 0 8px rgba(96, 165, 250, 0.8))'
            },
            animated: true,
          }}
        >
          {/* Glowing gradient definition */}
          <defs>
            <linearGradient id="glowing-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#60a5fa" />
              <stop offset="50%" stopColor="#a855f7" />
              <stop offset="100%" stopColor="#10b981" />
            </linearGradient>
          </defs>

          <Controls 
            className="bg-gray-900/90 border-gray-600 backdrop-blur-sm rounded-xl shadow-2xl" 
            style={{ 
              border: '1px solid rgb(75 85 99)',
              borderRadius: '16px'
            }}
          />
          
          <Background 
            color="#1f2937" 
            gap={24} 
            size={1}
            variant={BackgroundVariant.Dots}
            style={{
              opacity: 0.3
            }}
          />

          <FuturisticMinimap />

          {/* Status Panel */}
          <Panel position="top-right" className="bg-gray-900/95 border border-gray-600 rounded-xl p-4 backdrop-blur-sm shadow-2xl">
            <div className="text-sm text-gray-300 space-y-1">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span>Canvas: {Math.round(zoom * 100)}%</span>
              </div>
              <div>Nodes: <span className="text-blue-400 font-mono">{nodes.length}</span></div>
              <div>Connections: <span className="text-purple-400 font-mono">{edges.length}</span></div>
              {isRunning && (
                <div className="flex items-center space-x-2 text-yellow-400">
                  <div className="w-2 h-2 bg-yellow-400 rounded-full animate-ping"></div>
                  <span>Executing...</span>
                </div>
              )}
            </div>
          </Panel>
        </ReactFlow>
      </div>

      <WorkflowTimeline 
        timeline={executionTimeline}
        isRunning={isRunning}
      />
    </div>
  );
};

export default WorkflowCanvas;

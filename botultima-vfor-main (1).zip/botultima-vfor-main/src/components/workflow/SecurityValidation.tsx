import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Lock, 
  Key, 
  Eye,
  Zap,
  Database,
  Globe
} from 'lucide-react';
import { WorkflowNode, WorkflowEdge } from '@/types/WorkflowTypes';
import { SecurityService } from '@/services/SecurityService';

interface SecurityIssue {
  id: string;
  type: 'critical' | 'high' | 'medium' | 'low' | 'info';
  category: 'data' | 'auth' | 'network' | 'config' | 'permissions';
  title: string;
  description: string;
  nodeId?: string;
  recommendation: string;
}

interface SecurityValidationProps {
  nodes: WorkflowNode[];
  edges: WorkflowEdge[];
  onFixIssue?: (issueId: string) => void;
}

const SecurityValidation = ({ nodes, edges, onFixIssue }: SecurityValidationProps) => {
  const [securityIssues, setSecurityIssues] = useState<SecurityIssue[]>([]);
  const [securityScore, setSecurityScore] = useState(0);
  const [isScanning, setIsScanning] = useState(false);

  useEffect(() => {
    performSecurityScan();
  }, [nodes, edges]);

  const performSecurityScan = async () => {
    setIsScanning(true);
    SecurityService.logSecurityEvent('Security scan initiated', { nodeCount: nodes.length });

    const issues: SecurityIssue[] = [];
    let score = 100;

    // Check for unsecured API connections
    nodes.forEach(node => {
      if (['http-request', 'api', 'webhook'].includes(node.data.type)) {
        const apiUrl = node.data.config?.apiUrl;
        if (apiUrl && !apiUrl.startsWith('https://')) {
          issues.push({
            id: `insecure-${node.id}`,
            type: 'high',
            category: 'network',
            title: 'Insecure HTTP Connection',
            description: `Node "${node.data.label}" uses HTTP instead of HTTPS`,
            nodeId: node.id,
            recommendation: 'Switch to HTTPS to encrypt data in transit'
          });
          score -= 15;
        }
      }

      // Check for missing API keys
      if (['gpt', 'deepseek', 'qwen', 'mixtral'].includes(node.data.type)) {
        if (!node.data.config?.apiKey) {
          issues.push({
            id: `missing-key-${node.id}`,
            type: 'medium',
            category: 'auth',
            title: 'Missing API Key',
            description: `AI node "${node.data.label}" lacks API key configuration`,
            nodeId: node.id,
            recommendation: 'Configure API key for secure authentication'
          });
          score -= 8;
        }
      }

      // Check for exposed sensitive data
      if (node.data.config?.prompt && /password|secret|key|token/i.test(node.data.config.prompt)) {
        issues.push({
          id: `exposed-data-${node.id}`,
          type: 'critical',
          category: 'data',
          title: 'Sensitive Data Exposure',
          description: `Node "${node.data.label}" may contain sensitive information in prompts`,
          nodeId: node.id,
          recommendation: 'Use environment variables or secure storage for sensitive data'
        });
        score -= 25;
      }

      // Check database connections
      if (['mysql-db', 'postgresql-db', 'mongodb'].includes(node.data.type)) {
        if (!node.data.config?.connectionString) {
          issues.push({
            id: `db-config-${node.id}`,
            type: 'high',
            category: 'config',
            title: 'Database Configuration Issue',
            description: `Database node "${node.data.label}" lacks proper connection configuration`,
            nodeId: node.id,
            recommendation: 'Configure secure database connection with proper credentials'
          });
          score -= 12;
        }
      }

      // Check for overprivileged operations
      if (node.data.type === 'custom-code-runner' && node.data.config?.jsCode) {
        const code = node.data.config.jsCode;
        if (/eval|Function|require|import/i.test(code)) {
          issues.push({
            id: `privilege-${node.id}`,
            type: 'critical',
            category: 'permissions',
            title: 'Potentially Dangerous Code',
            description: `Custom code in "${node.data.label}" uses potentially dangerous functions`,
            nodeId: node.id,
            recommendation: 'Review and sanitize custom code to prevent security vulnerabilities'
          });
          score -= 30;
        }
      }
    });

    // Check workflow structure security
    const triggerNodes = nodes.filter(n => n.data.type === 'webhook');
    triggerNodes.forEach(trigger => {
      if (!trigger.data.config?.apiKey && !trigger.data.config?.authentication) {
        issues.push({
          id: `webhook-auth-${trigger.id}`,
          type: 'high',
          category: 'auth',
          title: 'Unprotected Webhook',
          description: `Webhook "${trigger.data.label}" lacks authentication`,
          nodeId: trigger.id,
          recommendation: 'Add authentication to prevent unauthorized access'
        });
        score -= 15;
      }
    });

    // Add positive security features
    const hasValidation = nodes.some(n => n.data.type === 'condition');
    const hasErrorHandling = nodes.some(n => n.data.type === 'throw-error');
    
    if (hasValidation) {
      issues.push({
        id: 'has-validation',
        type: 'info',
        category: 'config',
        title: 'Input Validation Present',
        description: 'Workflow includes data validation nodes',
        recommendation: 'Good practice - continue validating inputs'
      });
      score += 5;
    }

    if (hasErrorHandling) {
      issues.push({
        id: 'has-error-handling',
        type: 'info',
        category: 'config',
        title: 'Error Handling Configured',
        description: 'Workflow includes error handling mechanisms',
        recommendation: 'Good practice - proper error handling improves security'
      });
      score += 5;
    }

    setSecurityIssues(issues);
    setSecurityScore(Math.max(0, Math.min(100, score)));
    setIsScanning(false);

    SecurityService.logSecurityEvent('Security scan completed', { 
      score, 
      issueCount: issues.length,
      criticalIssues: issues.filter(i => i.type === 'critical').length
    });
  };

  const getIssueIcon = (type: string) => {
    switch (type) {
      case 'critical': return <XCircle className="h-4 w-4 text-red-400" />;
      case 'high': return <AlertTriangle className="h-4 w-4 text-orange-400" />;
      case 'medium': return <AlertTriangle className="h-4 w-4 text-yellow-400" />;
      case 'low': return <Eye className="h-4 w-4 text-blue-400" />;
      case 'info': return <CheckCircle className="h-4 w-4 text-green-400" />;
      default: return <Shield className="h-4 w-4 text-gray-400" />;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'data': return <Database className="h-4 w-4" />;
      case 'auth': return <Key className="h-4 w-4" />;
      case 'network': return <Globe className="h-4 w-4" />;
      case 'config': return <Shield className="h-4 w-4" />;
      case 'permissions': return <Lock className="h-4 w-4" />;
      default: return <Shield className="h-4 w-4" />;
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-yellow-400';
    if (score >= 40) return 'text-orange-400';
    return 'text-red-400';
  };

  const criticalIssues = securityIssues.filter(i => i.type === 'critical');
  const highIssues = securityIssues.filter(i => i.type === 'high');
  const otherIssues = securityIssues.filter(i => !['critical', 'high'].includes(i.type));

  return (
    <div className="space-y-4">
      {/* Security Score */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center space-x-2 text-white">
            <Shield className="h-5 w-5" />
            <span>Security Score</span>
            {isScanning && <div className="w-4 h-4 border-2 border-blue-400 border-t-transparent rounded-full animate-spin ml-2" />}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className={`text-2xl font-bold ${getScoreColor(securityScore)}`}>
                {securityScore}/100
              </span>
              <Button
                onClick={performSecurityScan}
                disabled={isScanning}
                size="sm"
                variant="outline"
                className="border-gray-600"
              >
                <Zap className="h-4 w-4 mr-1" />
                {isScanning ? 'Scanning...' : 'Rescan'}
              </Button>
            </div>
            <Progress value={securityScore} className="h-2" />
            <div className="flex space-x-4 text-sm">
              <div className="flex items-center space-x-1">
                <XCircle className="h-3 w-3 text-red-400" />
                <span className="text-gray-300">{criticalIssues.length} Critical</span>
              </div>
              <div className="flex items-center space-x-1">
                <AlertTriangle className="h-3 w-3 text-orange-400" />
                <span className="text-gray-300">{highIssues.length} High</span>
              </div>
              <div className="flex items-center space-x-1">
                <CheckCircle className="h-3 w-3 text-green-400" />
                <span className="text-gray-300">{otherIssues.filter(i => i.type === 'info').length} Good</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Critical Issues */}
      {criticalIssues.length > 0 && (
        <Card className="bg-red-900/20 border-red-500/30">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-red-300">
              <XCircle className="h-5 w-5" />
              <span>Critical Security Issues</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {criticalIssues.map(issue => (
              <SecurityIssueCard key={issue.id} issue={issue} onFix={onFixIssue} />
            ))}
          </CardContent>
        </Card>
      )}

      {/* High Issues */}
      {highIssues.length > 0 && (
        <Card className="bg-orange-900/20 border-orange-500/30">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-orange-300">
              <AlertTriangle className="h-5 w-5" />
              <span>High Priority Issues</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {highIssues.map(issue => (
              <SecurityIssueCard key={issue.id} issue={issue} onFix={onFixIssue} />
            ))}
          </CardContent>
        </Card>
      )}

      {/* Other Issues */}
      {otherIssues.length > 0 && (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-gray-300">
              <Shield className="h-5 w-5" />
              <span>Security Recommendations</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {otherIssues.map(issue => (
              <SecurityIssueCard key={issue.id} issue={issue} onFix={onFixIssue} />
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
};

const SecurityIssueCard = ({ 
  issue, 
  onFix 
}: { 
  issue: SecurityIssue; 
  onFix?: (issueId: string) => void;
}) => {
  const getTypeColor = (type: string) => {
    switch (type) {
      case 'critical': return 'bg-red-500/20 text-red-300 border-red-500/30';
      case 'high': return 'bg-orange-500/20 text-orange-300 border-orange-500/30';
      case 'medium': return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      case 'low': return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
      case 'info': return 'bg-green-500/20 text-green-300 border-green-500/30';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  return (
    <div className="p-3 bg-gray-800/30 rounded-lg border border-gray-600/50">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <Shield className="h-4 w-4 text-gray-400" />
            <span className="font-medium text-white">{issue.title}</span>
            <Badge className={getTypeColor(issue.type)}>
              {issue.type.toUpperCase()}
            </Badge>
          </div>
          <p className="text-sm text-gray-300 mb-2">{issue.description}</p>
          <p className="text-xs text-gray-400">{issue.recommendation}</p>
        </div>
        {onFix && issue.type !== 'info' && (
          <Button
            onClick={() => onFix(issue.id)}
            size="sm"
            variant="outline"
            className="ml-3 border-gray-600"
          >
            Fix
          </Button>
        )}
      </div>
    </div>
  );
};

export default SecurityValidation;


import { useCallback, useState, useEffect, useMemo } from 'react';
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  addEdge,
  Connection,
  Edge,
  Node,
  NodeChange,
  EdgeChange,
  OnConnect,
  Panel,
  useReactFlow,
  SelectionMode,
  ConnectionMode
} from '@xyflow/react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Play, 
  Square, 
  Save, 
  Settings, 
  Zap, 
  Eye, 
  EyeOff,
  Download,
  Upload,
  Share2,
  Grid,
  Move,
  MousePointer,
  Hand
} from 'lucide-react';
import { toast } from 'sonner';
import { WorkflowNode, WorkflowEdge, WorkflowNodeData } from '@/types/WorkflowTypes';
import FuturisticMinimap from './FuturisticMinimap';
import FuturisticToolbar from './FuturisticToolbar';

interface N8nStyleCanvasProps {
  onSave?: (nodes: WorkflowNode[], edges: WorkflowEdge[]) => void;
  initialNodes?: WorkflowNode[];
  initialEdges?: WorkflowEdge[];
  onNodeSelect?: (node: WorkflowNode | null) => void;
  selectedNode?: WorkflowNode | null;
  onUpdateNode?: (nodeId: string, updates: Partial<WorkflowNodeData>) => void;
}

const N8nStyleCanvas = ({
  onSave,
  initialNodes = [],
  initialEdges = [],
  onNodeSelect,
  selectedNode,
  onUpdateNode
}: N8nStyleCanvasProps) => {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [isRunning, setIsRunning] = useState(false);
  const [workflowName, setWorkflowName] = useState('Untitled Workflow');
  const [selectionMode, setSelectionMode] = useState<SelectionMode>(SelectionMode.Partial);
  const [panOnDrag, setPanOnDrag] = useState(true);
  const [showMinimap, setShowMinimap] = useState(true);
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionResults, setExecutionResults] = useState<Record<string, any>>({});

  const { fitView, zoomIn, zoomOut, setCenter } = useReactFlow();

  // Enhanced node colors for n8n-style appearance
  const getNodeColor = useCallback((node: any) => {
    if (node.selected) return '#10b981';
    if (node.data?.isExecuting) return '#f59e0b';
    if (node.data?.executionResult?.success === false) return '#ef4444';
    if (node.data?.executionResult?.success === true) return '#10b981';
    
    switch (node.data?.category) {
      case 'ai': return '#8b5cf6';
      case 'action': return '#3b82f6';
      case 'transformation': return '#f59e0b';
      case 'flow-control': return '#06b6d4';
      case 'core': return '#6b7280';
      case 'human-loop': return '#ec4899';
      case 'basic': return '#10b981';
      case 'database': return '#f97316';
      case 'communication': return '#14b8a6';
      default: return '#6b7280';
    }
  }, []);

  // Enhanced connection handling with validation
  const onConnect: OnConnect = useCallback(
    (connection: Connection) => {
      // Validate connection before adding
      const sourceNode = nodes.find(n => n.id === connection.source);
      const targetNode = nodes.find(n => n.id === connection.target);
      
      if (!sourceNode || !targetNode) return;
      
      // Prevent self-connections
      if (connection.source === connection.target) {
        toast.error('Cannot connect a node to itself');
        return;
      }
      
      // Check for existing connections
      const existingEdge = edges.find(e => 
        e.source === connection.source && e.target === connection.target
      );
      
      if (existingEdge) {
        toast.error('Connection already exists');
        return;
      }
      
      const newEdge: WorkflowEdge = {
        ...connection,
        id: `${connection.source}-${connection.target}`,
        type: 'smoothstep',
        animated: true,
        style: { 
          stroke: getNodeColor(sourceNode),
          strokeWidth: 2
        }
      };
      
      setEdges((eds) => addEdge(newEdge, eds));
      toast.success('Nodes connected successfully');
    },
    [nodes, edges, getNodeColor]
  );

  // Enhanced drag and drop handling
  const onDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (event: React.DragEvent) => {
      event.preventDefault();

      const reactFlowBounds = event.currentTarget.getBoundingClientRect();
      const type = event.dataTransfer.getData('application/reactflow');
      const category = event.dataTransfer.getData('node-category');

      if (!type) return;

      const position = {
        x: event.clientX - reactFlowBounds.left,
        y: event.clientY - reactFlowBounds.top,
      };

      const newNode: WorkflowNode = {
        id: `${type}-${Date.now()}`,
        type: 'workflowNode',
        position,
        data: {
          label: type.charAt(0).toUpperCase() + type.slice(1).replace('-', ' '),
          type: type as any,
          category: category as any,
          config: {},
          isValid: true
        },
      };

      setNodes((nds) => nds.concat(newNode));
      toast.success(`${newNode.data.label} node added`);
    },
    []
  );

  // Workflow execution simulation
  const handleExecuteWorkflow = useCallback(async () => {
    if (nodes.length === 0) {
      toast.error('Add some nodes to execute the workflow');
      return;
    }

    setIsExecuting(true);
    setExecutionResults({});
    
    // Find trigger nodes
    const triggerNodes = nodes.filter(node => 
      node.data.type === 'trigger' || node.data.type === 'webhook'
    );
    
    if (triggerNodes.length === 0) {
      toast.error('Workflow needs at least one trigger node');
      setIsExecuting(false);
      return;
    }

    toast.success('Workflow execution started');

    // Simulate execution with visual feedback
    for (const node of nodes) {
      // Update node to show execution state
      setNodes(prev => prev.map(n => 
        n.id === node.id 
          ? { ...n, data: { ...n.data, isExecuting: true } }
          : n
      ));

      // Simulate processing time
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Simulate result
      const success = Math.random() > 0.1; // 90% success rate
      const result = {
        success,
        output: success ? `Processed ${node.data.label}` : 'Processing failed',
        timestamp: new Date().toISOString()
      };

      setExecutionResults(prev => ({ ...prev, [node.id]: result }));
      
      // Update node with result
      setNodes(prev => prev.map(n => 
        n.id === node.id 
          ? { 
              ...n, 
              data: { 
                ...n.data, 
                isExecuting: false,
                executionResult: result
              }
            }
          : n
      ));
    }

    setIsExecuting(false);
    toast.success('Workflow execution completed');
  }, [nodes]);

  const handleSaveWorkflow = useCallback(() => {
    onSave?.(nodes, edges);
    toast.success('Workflow saved successfully');
  }, [nodes, edges, onSave]);

  const handleNodeClick = useCallback((event: React.MouseEvent, node: WorkflowNode) => {
    onNodeSelect?.(node);
  }, [onNodeSelect]);

  // Enhanced keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.ctrlKey || event.metaKey) {
        switch (event.key) {
          case 's':
            event.preventDefault();
            handleSaveWorkflow();
            break;
          case 'Enter':
            event.preventDefault();
            handleExecuteWorkflow();
            break;
          case '=':
            event.preventDefault();
            zoomIn();
            break;
          case '-':
            event.preventDefault();
            zoomOut();
            break;
          case '0':
            event.preventDefault();
            fitView();
            break;
        }
      }
      
      if (event.key === 'Delete' && selectedNode) {
        setNodes(prev => prev.filter(n => n.id !== selectedNode.id));
        setEdges(prev => prev.filter(e => 
          e.source !== selectedNode.id && e.target !== selectedNode.id
        ));
        onNodeSelect?.(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleSaveWorkflow, handleExecuteWorkflow, selectedNode, onNodeSelect, fitView, zoomIn, zoomOut]);

  const nodeCount = nodes.length;
  const connectionCount = edges.length;
  const workflowStatus = isExecuting ? 'running' : nodes.length === 0 ? 'draft' : 'saved';

  return (
    <div className="h-full w-full relative bg-gray-950">
      <FuturisticToolbar
        workflowName={workflowName}
        onWorkflowNameChange={setWorkflowName}
        onSave={handleSaveWorkflow}
        onTest={handleExecuteWorkflow}
        isRunning={isExecuting}
        workflowStatus={workflowStatus as any}
        nodeCount={nodeCount}
        connectionCount={connectionCount}
      />

      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onDrop={onDrop}
        onDragOver={onDragOver}
        onNodeClick={handleNodeClick}
        connectionMode={ConnectionMode.Loose}
        fitView
        fitViewOptions={{ padding: 0.2 }}
        selectionMode={selectionMode}
        panOnDrag={panOnDrag}
        selectNodesOnDrag={!panOnDrag}
        className="workflow-canvas"
        style={{ 
          background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%)'
        }}
      >
        <Background 
          color="#334155" 
          gap={20} 
          size={1}
          style={{ opacity: 0.3 }}
        />
        
        <Controls 
          className="bg-gray-800/90 border border-gray-600/50 rounded-lg"
          showInteractive={false}
        />
        
        {showMinimap && (
          <FuturisticMinimap />
        )}

        {/* Enhanced Control Panel */}
        <Panel position="top-right" className="flex items-center space-x-2 bg-gray-900/90 p-3 rounded-lg border border-gray-600/50 backdrop-blur-sm">
          <Button
            variant={panOnDrag ? "default" : "outline"}
            size="sm"
            onClick={() => setPanOnDrag(!panOnDrag)}
            className="bg-gray-800 hover:bg-gray-700"
          >
            {panOnDrag ? <Hand className="h-4 w-4" /> : <MousePointer className="h-4 w-4" />}
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowMinimap(!showMinimap)}
            className="bg-gray-800 hover:bg-gray-700"
          >
            {showMinimap ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => fitView()}
            className="bg-gray-800 hover:bg-gray-700"
          >
            <Grid className="h-4 w-4" />
          </Button>
        </Panel>

        {/* Execution Status Panel */}
        {isExecuting && (
          <Panel position="bottom-center" className="bg-gray-900/95 p-4 rounded-lg border border-green-500/30 backdrop-blur-sm">
            <div className="flex items-center space-x-3">
              <div className="w-4 h-4 border-2 border-green-400 border-t-transparent rounded-full animate-spin"></div>
              <span className="text-green-300 font-medium">Executing workflow...</span>
              <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                {Object.keys(executionResults).length} / {nodeCount} completed
              </Badge>
            </div>
          </Panel>
        )}

        {/* Workflow Stats Panel */}
        <Panel position="bottom-left" className="bg-gray-900/90 p-3 rounded-lg border border-gray-600/50 backdrop-blur-sm">
          <div className="flex items-center space-x-4 text-sm text-gray-300">
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
              <span>{nodeCount} nodes</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
              <span>{connectionCount} connections</span>
            </div>
            {Object.keys(executionResults).length > 0 && (
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span>{Object.values(executionResults).filter(r => r.success).length} successful</span>
              </div>
            )}
          </div>
        </Panel>
      </ReactFlow>
    </div>
  );
};

export default N8nStyleCanvas;

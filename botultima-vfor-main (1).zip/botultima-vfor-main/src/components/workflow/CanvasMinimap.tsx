
import { MiniMap } from '@xyflow/react';
import { Button } from "@/components/ui/button";
import { Maximize, Minimize } from 'lucide-react';
import { useState } from 'react';

interface CanvasMinimapProps {
  nodeColor?: (node: any) => string;
}

const CanvasMinimap = ({ nodeColor }: CanvasMinimapProps) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const defaultNodeColor = (node: any) => {
    if (node.selected) return '#10b981';
    switch (node.data?.category) {
      case 'ai': return '#8b5cf6';
      case 'action': return '#3b82f6';
      case 'transformation': return '#f59e0b';
      case 'flow-control': return '#06b6d4';
      case 'core': return '#6b7280';
      case 'human-loop': return '#ec4899';
      case 'basic': return '#10b981';
      default: return '#6b7280';
    }
  };

  return (
    <div className={`absolute bottom-4 right-4 z-20 bg-gray-900/95 border border-gray-700 rounded-lg overflow-hidden backdrop-blur-sm transition-all duration-300 ${
      isExpanded ? 'w-80 h-60' : 'w-48 h-36'
    }`}>
      <div className="absolute top-2 right-2 z-30">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsExpanded(!isExpanded)}
          className="h-6 w-6 p-0 text-gray-400 hover:text-white bg-gray-800/80 hover:bg-gray-700"
        >
          {isExpanded ? (
            <Minimize className="h-3 w-3" />
          ) : (
            <Maximize className="h-3 w-3" />
          )}
        </Button>
      </div>
      
      <div className="absolute top-2 left-2 z-30">
        <span className="text-xs text-gray-400 font-medium">Minimap</span>
      </div>

      <MiniMap
        nodeColor={nodeColor || defaultNodeColor}
        className="w-full h-full rounded-lg"
        style={{
          backgroundColor: 'transparent',
        }}
        maskColor="rgba(0, 0, 0, 0.2)"
        pannable
        zoomable
      />
    </div>
  );
};

export default CanvasMinimap;

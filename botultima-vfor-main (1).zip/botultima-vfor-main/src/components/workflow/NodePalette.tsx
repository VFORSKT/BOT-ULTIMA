
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Zap, 
  Brain, 
  GitBranch, 
  Globe, 
  MessageSquare, 
  Square,
  Mail,
  FileText,
  Database,
  Send,
  Upload,
  Download,
  Code,
  Filter,
  Split,
  Merge,
  Users,
  Webhook,
  Play,
  Timer,
  CheckCircle,
  AlertTriangle,
  Pause,
  UserCheck,
  RotateCcw,
  Calendar,
  Trash2,
  Copy,
  Edit,
  List,
  Hash,
  Type,
  Clock,
  Tag,
  Layers,
  Link,
  Settings
} from 'lucide-react';

const nodeCategories = {
  ai: {
    title: 'AI',
    color: 'border-purple-500/30 bg-purple-500/10',
    nodes: [
      { id: 'trigger', name: 'Trigger', icon: Zap, color: 'bg-green-500', description: 'Start the workflow' },
      { id: 'gpt', name: 'GPT (OpenAI)', icon: Brain, color: 'bg-purple-500', description: 'OpenAI GPT models' },
      { id: 'qwen', name: 'Qwen', icon: Brain, color: 'bg-purple-400', description: 'Qwen via OpenRouter' },
      { id: 'deepseek', name: 'DeepSeek', icon: Brain, color: 'bg-purple-600', description: 'DeepSeek models' },
      { id: 'mixtral', name: 'Mixtral', icon: Brain, color: 'bg-purple-500', description: 'Mixtral models' },
      { id: 'text-classifier', name: 'Text Classifier', icon: Tag, color: 'bg-purple-400', description: 'Classify text content' },
      { id: 'sentiment-analysis', name: 'Sentiment Analysis', icon: Hash, color: 'bg-purple-500', description: 'Analyze sentiment' },
      { id: 'information-extractor', name: 'Info Extractor', icon: List, color: 'bg-purple-600', description: 'Extract information' },
      { id: 'summarization', name: 'Summarization', icon: Type, color: 'bg-purple-400', description: 'Summarize content' },
      { id: 'ai-transform', name: 'AI Transform', icon: RotateCcw, color: 'bg-purple-500', description: 'Natural language to logic' }
    ]
  },
  database: {
    title: 'Database',
    color: 'border-blue-500/30 bg-blue-500/10',
    nodes: [
      { id: 'mysql-db', name: 'MySQL', icon: Database, color: 'bg-blue-500', description: 'MySQL database operations' },
      { id: 'postgresql-db', name: 'PostgreSQL', icon: Database, color: 'bg-blue-600', description: 'PostgreSQL database operations' },
      { id: 'mongodb', name: 'MongoDB', icon: Database, color: 'bg-green-600', description: 'MongoDB operations' },
      { id: 'store-db', name: 'Store to DB', icon: Database, color: 'bg-gray-500', description: 'Save to database' },
      { id: 'log-supabase', name: 'Log to Supabase', icon: FileText, color: 'bg-gray-400', description: 'Log to Supabase' }
    ]
  },
  communication: {
    title: 'Communication',
    color: 'border-green-500/30 bg-green-500/10',
    nodes: [
      { id: 'email-sender', name: 'Email Sender', icon: Mail, color: 'bg-red-500', description: 'Send emails via SMTP' },
      { id: 'sms-sender', name: 'SMS Sender', icon: MessageSquare, color: 'bg-green-500', description: 'Send SMS messages' },
      { id: 'gmail', name: 'Gmail', icon: Mail, color: 'bg-red-400', description: 'Send/read emails' },
      { id: 'telegram', name: 'Telegram', icon: Send, color: 'bg-blue-500', description: 'Send messages' },
      { id: 'discord', name: 'Discord', icon: MessageSquare, color: 'bg-indigo-500', description: 'Send messages' },
      { id: 'slack', name: 'Slack', icon: MessageSquare, color: 'bg-green-500', description: 'Send messages' },
      { id: 'whatsapp', name: 'WhatsApp Business', icon: MessageSquare, color: 'bg-green-600', description: 'Send messages' }
    ]
  },
  action: {
    title: 'Action in App',
    color: 'border-blue-500/30 bg-blue-500/10',
    nodes: [
      { id: 'notion', name: 'Notion', icon: Database, color: 'bg-gray-600', description: 'Database operations' },
      { id: 'airtable', name: 'Airtable', icon: Database, color: 'bg-yellow-500', description: 'Database operations' },
      { id: 'google-sheets', name: 'Google Sheets', icon: FileText, color: 'bg-green-400', description: 'Spreadsheet operations' },
      { id: 'google-sheets-reader', name: 'Sheets Reader', icon: FileText, color: 'bg-green-500', description: 'Read Google Sheets' }
    ]
  },
  transformation: {
    title: 'Data Transformation',
    color: 'border-orange-500/30 bg-orange-500/10',
    nodes: [
      { id: 'file-processor', name: 'File Processor', icon: FileText, color: 'bg-orange-500', description: 'Process various file types' },
      { id: 'image-processor', name: 'Image Processor', icon: FileText, color: 'bg-purple-500', description: 'Process and transform images' },
      { id: 'csv-parser', name: 'CSV Parser', icon: FileText, color: 'bg-blue-500', description: 'Parse CSV files' },
      { id: 'json-validator', name: 'JSON Validator', icon: Code, color: 'bg-green-500', description: 'Validate JSON data' },
      { id: 'xml-parser', name: 'XML Parser', icon: Code, color: 'bg-red-500', description: 'Parse XML data' },
      { id: 'pdf-generator', name: 'PDF Generator', icon: FileText, color: 'bg-red-600', description: 'Generate PDF documents' },
      { id: 'ai-data-transform', name: 'AI Transform', icon: RotateCcw, color: 'bg-orange-400', description: 'AI-powered data transformation' },
      { id: 'code', name: 'Code', icon: Code, color: 'bg-orange-500', description: 'Custom JS/Python code' },
      { id: 'custom-code-runner', name: 'Custom Code', icon: Code, color: 'bg-orange-600', description: 'Run custom JavaScript' },
      { id: 'edit-fields', name: 'Edit Fields', icon: Edit, color: 'bg-orange-400', description: 'Rename, remove, reformat' },
      { id: 'date-time', name: 'Date/Time', icon: Calendar, color: 'bg-orange-500', description: 'Format dates' },
      { id: 'filter-data', name: 'Filter', icon: Filter, color: 'bg-orange-400', description: 'Condition-based filtering' },
      { id: 'split-join', name: 'Split/Join', icon: Split, color: 'bg-orange-500', description: 'Split or join data' },
      { id: 'remove-duplicates', name: 'Remove Duplicates', icon: Copy, color: 'bg-orange-600', description: 'Remove duplicate items' }
    ]
  },
  'flow-control': {
    title: 'Flow Control',
    color: 'border-cyan-500/30 bg-cyan-500/10',
    nodes: [
      { id: 'condition', name: 'If Condition', icon: GitBranch, color: 'bg-cyan-500', description: 'Branch on true/false' },
      { id: 'merge', name: 'Merge', icon: Merge, color: 'bg-cyan-400', description: 'Merge two sources' },
      { id: 'loop', name: 'Loop', icon: RotateCcw, color: 'bg-cyan-500', description: 'Split in batches' },
      { id: 'compare', name: 'Compare', icon: GitBranch, color: 'bg-cyan-400', description: 'Compare datasets' },
      { id: 'throw-error', name: 'Throw Error', icon: AlertTriangle, color: 'bg-red-500', description: 'Stop with alert' },
      { id: 'sub-workflow', name: 'Sub-workflow', icon: Layers, color: 'bg-cyan-600', description: 'Call another bot' },
      { id: 'scheduler', name: 'Scheduler', icon: Clock, color: 'bg-cyan-500', description: 'Schedule workflow execution' },
      { id: 'timer', name: 'Timer', icon: Timer, color: 'bg-cyan-400', description: 'Add delays to workflow' }
    ]
  },
  core: {
    title: 'Core',
    color: 'border-gray-500/30 bg-gray-500/10',
    nodes: [
      { id: 'webhook', name: 'Webhook', icon: Webhook, color: 'bg-gray-500', description: 'Listen for webhooks' },
      { id: 'execute-code', name: 'Execute Code', icon: Code, color: 'bg-gray-600', description: 'Run custom code' },
      { id: 'http-request', name: 'HTTP Request', icon: Globe, color: 'bg-blue-500', description: 'Make API calls' },
      { id: 'variables', name: 'Variables', icon: Settings, color: 'bg-gray-500', description: 'Get/Set variables' }
    ]
  },
  'human-loop': {
    title: 'Human in Loop',
    color: 'border-pink-500/30 bg-pink-500/10',
    nodes: [
      { id: 'wait-approval', name: 'Wait for Approval', icon: UserCheck, color: 'bg-pink-500', description: 'Wait for user approval' },
      { id: 'decision-email', name: 'Decision Email', icon: Mail, color: 'bg-pink-400', description: 'Send decision email' },
      { id: 'pause-user', name: 'Pause for User', icon: Pause, color: 'bg-pink-500', description: 'Pause until user acts' }
    ]
  },
  basic: {
    title: 'Basic',
    color: 'border-green-500/30 bg-green-500/10',
    nodes: [
      { id: 'reply', name: 'Reply', icon: MessageSquare, color: 'bg-emerald-500', description: 'Send response' },
      { id: 'upload', name: 'File Upload', icon: Upload, color: 'bg-indigo-500', description: 'Upload files' },
      { id: 'download', name: 'File Download', icon: Download, color: 'bg-cyan-500', description: 'Download files' },
      { id: 'end', name: 'End', icon: Square, color: 'bg-red-500', description: 'End workflow' }
    ]
  }
};

interface NodePaletteProps {
  onDragStart: (event: React.DragEvent, nodeType: string, category: string) => void;
}

const NodePalette = ({ onDragStart }: NodePaletteProps) => {
  return (
    <Card className="bg-gray-800/50 border-gray-700 h-full">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm text-gray-300 flex items-center space-x-2">
          <Layers className="h-4 w-4" />
          <span>Workflow Blocks</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <Tabs defaultValue="ai" className="h-full">
          <TabsList className="grid grid-cols-4 gap-1 p-1 m-3 bg-gray-700/50">
            <TabsTrigger value="ai" className="text-xs">AI</TabsTrigger>
            <TabsTrigger value="database" className="text-xs">DB</TabsTrigger>
            <TabsTrigger value="communication" className="text-xs">Comm</TabsTrigger>
            <TabsTrigger value="action" className="text-xs">Apps</TabsTrigger>
          </TabsList>
          
          <TabsList className="grid grid-cols-4 gap-1 p-1 mx-3 mb-3 bg-gray-700/50">
            <TabsTrigger value="transformation" className="text-xs">Transform</TabsTrigger>
            <TabsTrigger value="flow-control" className="text-xs">Flow</TabsTrigger>
            <TabsTrigger value="core" className="text-xs">Core</TabsTrigger>
            <TabsTrigger value="human-loop" className="text-xs">Human</TabsTrigger>
          </TabsList>

          {Object.entries(nodeCategories).map(([categoryKey, category]) => (
            <TabsContent key={categoryKey} value={categoryKey} className="space-y-2 px-3 max-h-80 overflow-y-auto">
              <div className={`border rounded-lg p-2 ${category.color}`}>
                <Badge variant="secondary" className="text-xs mb-2 bg-gray-700 text-gray-300">
                  {category.title}
                </Badge>
                <div className="space-y-2">
                  {category.nodes.map((node) => {
                    const Icon = node.icon;
                    return (
                      <div
                        key={node.id}
                        className="p-3 bg-gray-700/50 rounded-lg border border-gray-600 hover:border-gray-500 cursor-grab active:cursor-grabbing transition-colors"
                        draggable
                        onDragStart={(event) => onDragStart(event, node.id, categoryKey)}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`w-8 h-8 ${node.color} rounded-lg flex items-center justify-center`}>
                            <Icon className="h-4 w-4 text-white" />
                          </div>
                          <div className="flex-1">
                            <span className="text-sm font-medium text-white">{node.name}</span>
                            <p className="text-xs text-gray-400">{node.description}</p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default NodePalette;

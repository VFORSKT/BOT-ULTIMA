
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { 
  Brain, 
  MessageSquare, 
  Database, 
  Settings, 
  Play, 
  Save,
  Zap,
  Code,
  Eye,
  Globe,
  Mail,
  FileText
} from 'lucide-react';
import { toast } from "@/hooks/use-toast";

interface AgentConfig {
  name: string;
  description: string;
  systemPrompt: string;
  model: string;
  temperature: number;
  maxTokens: number;
  memory: string;
  tools: string[];
  triggers: string[];
  integrations: string[];
}

const AIAgentBuilder = () => {
  const [config, setConfig] = useState<AgentConfig>({
    name: 'My AI Agent',
    description: 'A helpful AI assistant',
    systemPrompt: 'You are a helpful AI assistant. Respond professionally and helpfully to user queries.',
    model: 'gpt-4o-mini',
    temperature: 0.7,
    maxTokens: 1000,
    memory: 'short-term',
    tools: [],
    triggers: ['message'],
    integrations: []
  });

  const [activeTab, setActiveTab] = useState('basic');

  const availableTools = [
    { id: 'web-search', name: 'Web Search', icon: Globe },
    { id: 'calculator', name: 'Calculator', icon: Code },
    { id: 'email-sender', name: 'Email Sender', icon: Mail },
    { id: 'file-reader', name: 'File Reader', icon: FileText },
    { id: 'image-analyzer', name: 'Image Analyzer', icon: Eye },
  ];

  const availableModels = [
    { id: 'gpt-4o-mini', name: 'GPT-4O Mini (Free)', description: 'Fast and efficient for most tasks' },
    { id: 'gpt-4o', name: 'GPT-4O (Pro)', description: 'Most capable model for complex tasks' },
    { id: 'deepseek', name: 'DeepSeek (Free)', description: 'Open source alternative' },
    { id: 'mixtral', name: 'Mixtral (Free)', description: 'Fast multilingual model' },
  ];

  const availableIntegrations = [
    { id: 'telegram', name: 'Telegram', icon: MessageSquare },
    { id: 'gmail', name: 'Gmail', icon: Mail },
    { id: 'notion', name: 'Notion', icon: Database },
    { id: 'airtable', name: 'Airtable', icon: Database },
  ];

  const handleToolToggle = (toolId: string) => {
    setConfig(prev => ({
      ...prev,
      tools: prev.tools.includes(toolId)
        ? prev.tools.filter(t => t !== toolId)
        : [...prev.tools, toolId]
    }));
  };

  const handleIntegrationToggle = (integrationId: string) => {
    setConfig(prev => ({
      ...prev,
      integrations: prev.integrations.includes(integrationId)
        ? prev.integrations.filter(i => i !== integrationId)
        : [...prev.integrations, integrationId]
    }));
  };

  const handleSave = () => {
    toast({
      title: "Agent Saved",
      description: "Your AI agent configuration has been saved successfully.",
    });
  };

  const handleTest = () => {
    toast({
      title: "Testing Agent",
      description: "Starting test conversation with your AI agent...",
    });
  };

  const handleDeploy = () => {
    toast({
      title: "Deploying Agent",
      description: "Your AI agent is being deployed and will be live shortly.",
    });
  };

  return (
    <div className="h-full bg-gray-950 text-white overflow-y-auto">
      <div className="p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-2">AI Agent Builder</h1>
          <p className="text-gray-400">Create intelligent agents with custom personalities, tools, and integrations</p>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-1 mb-6 bg-gray-800/50 p-1 rounded-lg">
          {[
            { id: 'basic', label: 'Basic Settings', icon: Settings },
            { id: 'model', label: 'AI Model', icon: Brain },
            { id: 'tools', label: 'Tools & Capabilities', icon: Zap },
            { id: 'integrations', label: 'Integrations', icon: Globe },
            { id: 'test', label: 'Test & Deploy', icon: Play },
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-all ${
                  activeTab === tab.id
                    ? 'bg-green-600 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-gray-700'
                }`}
              >
                <Icon className="h-4 w-4 mr-2" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Tab Content */}
        <div className="space-y-6">
          {activeTab === 'basic' && (
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Settings className="h-5 w-5 mr-2" />
                  Basic Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-gray-300">Agent Name</Label>
                  <Input
                    value={config.name}
                    onChange={(e) => setConfig(prev => ({ ...prev, name: e.target.value }))}
                    className="bg-gray-700 border-gray-600 text-white mt-1"
                    placeholder="Enter agent name..."
                  />
                </div>
                
                <div>
                  <Label className="text-gray-300">Description</Label>
                  <Input
                    value={config.description}
                    onChange={(e) => setConfig(prev => ({ ...prev, description: e.target.value }))}
                    className="bg-gray-700 border-gray-600 text-white mt-1"
                    placeholder="Brief description of your agent..."
                  />
                </div>

                <div>
                  <Label className="text-gray-300">System Prompt</Label>
                  <Textarea
                    value={config.systemPrompt}
                    onChange={(e) => setConfig(prev => ({ ...prev, systemPrompt: e.target.value }))}
                    className="bg-gray-700 border-gray-600 text-white mt-1"
                    rows={6}
                    placeholder="Define your agent's personality, role, and behavior..."
                  />
                  <p className="text-xs text-gray-400 mt-1">
                    This prompt defines how your agent behaves and responds to users.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-300">Memory Type</Label>
                    <select 
                      className="w-full mt-1 bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
                      value={config.memory}
                      onChange={(e) => setConfig(prev => ({ ...prev, memory: e.target.value }))}
                    >
                      <option value="short-term">Short-term (Session only)</option>
                      <option value="long-term">Long-term (Persistent)</option>
                      <option value="vector">Vector Memory (Advanced)</option>
                    </select>
                  </div>
                  
                  <div>
                    <Label className="text-gray-300">Max Response Length</Label>
                    <Input
                      type="number"
                      value={config.maxTokens}
                      onChange={(e) => setConfig(prev => ({ ...prev, maxTokens: parseInt(e.target.value) }))}
                      className="bg-gray-700 border-gray-600 text-white mt-1"
                      min="100"
                      max="4000"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === 'model' && (
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Brain className="h-5 w-5 mr-2" />
                  AI Model Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-gray-300 mb-3 block">Select AI Model</Label>
                  <div className="grid gap-3">
                    {availableModels.map(model => (
                      <div
                        key={model.id}
                        className={`p-4 border rounded-lg cursor-pointer transition-all ${
                          config.model === model.id
                            ? 'border-green-500 bg-green-500/10'
                            : 'border-gray-600 hover:border-gray-500'
                        }`}
                        onClick={() => setConfig(prev => ({ ...prev, model: model.id }))}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="font-medium text-white">{model.name}</h3>
                            <p className="text-sm text-gray-400">{model.description}</p>
                          </div>
                          {config.model === model.id && (
                            <Badge className="bg-green-500 text-white">Selected</Badge>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="text-gray-300">Temperature (Creativity)</Label>
                  <div className="mt-2">
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.1"
                      value={config.temperature}
                      onChange={(e) => setConfig(prev => ({ ...prev, temperature: parseFloat(e.target.value) }))}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-gray-400 mt-1">
                      <span>Precise (0.0)</span>
                      <span className="text-white">{config.temperature}</span>
                      <span>Creative (1.0)</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === 'tools' && (
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Zap className="h-5 w-5 mr-2" />
                  Tools & Capabilities
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {availableTools.map(tool => {
                    const Icon = tool.icon;
                    const isSelected = config.tools.includes(tool.id);
                    
                    return (
                      <div
                        key={tool.id}
                        className={`p-4 border rounded-lg cursor-pointer transition-all ${
                          isSelected
                            ? 'border-green-500 bg-green-500/10'
                            : 'border-gray-600 hover:border-gray-500'
                        }`}
                        onClick={() => handleToolToggle(tool.id)}
                      >
                        <div className="flex items-center space-x-3">
                          <Icon className={`h-6 w-6 ${isSelected ? 'text-green-400' : 'text-gray-400'}`} />
                          <div>
                            <h3 className="font-medium text-white">{tool.name}</h3>
                            {isSelected && (
                              <Badge className="bg-green-500 text-white text-xs mt-1">Enabled</Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === 'integrations' && (
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Globe className="h-5 w-5 mr-2" />
                  Platform Integrations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {availableIntegrations.map(integration => {
                    const Icon = integration.icon;
                    const isSelected = config.integrations.includes(integration.id);
                    
                    return (
                      <div
                        key={integration.id}
                        className={`p-4 border rounded-lg cursor-pointer transition-all ${
                          isSelected
                            ? 'border-green-500 bg-green-500/10'
                            : 'border-gray-600 hover:border-gray-500'
                        }`}
                        onClick={() => handleIntegrationToggle(integration.id)}
                      >
                        <div className="flex items-center space-x-3">
                          <Icon className={`h-6 w-6 ${isSelected ? 'text-green-400' : 'text-gray-400'}`} />
                          <div>
                            <h3 className="font-medium text-white">{integration.name}</h3>
                            {isSelected && (
                              <Badge className="bg-green-500 text-white text-xs mt-1">Connected</Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === 'test' && (
            <div className="space-y-6">
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Play className="h-5 w-5 mr-2" />
                    Test Your Agent
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-900/50 rounded-lg p-4 mb-4">
                    <div className="flex items-center space-x-3 mb-3">
                      <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                        <Brain className="h-4 w-4 text-white" />
                      </div>
                      <div>
                        <h3 className="font-medium text-white">{config.name}</h3>
                        <p className="text-sm text-gray-400">{config.description}</p>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div className="bg-gray-700/50 p-3 rounded">
                        <div className="text-xs text-gray-400 mb-1">System Prompt Preview:</div>
                        <div className="text-sm text-gray-300">{config.systemPrompt.substring(0, 150)}...</div>
                      </div>
                      
                      <div className="flex flex-wrap gap-2">
                        <Badge className="bg-blue-600 text-white">Model: {config.model}</Badge>
                        <Badge className="bg-purple-600 text-white">Memory: {config.memory}</Badge>
                        <Badge className="bg-orange-600 text-white">Tools: {config.tools.length}</Badge>
                        <Badge className="bg-cyan-600 text-white">Integrations: {config.integrations.length}</Badge>
                      </div>
                    </div>
                  </div>

                  <div className="flex space-x-3">
                    <Button onClick={handleTest} className="bg-blue-600 hover:bg-blue-700">
                      <Play className="h-4 w-4 mr-2" />
                      Test Agent
                    </Button>
                    <Button onClick={handleSave} variant="outline" className="border-gray-600 text-white hover:bg-gray-700">
                      <Save className="h-4 w-4 mr-2" />
                      Save Configuration
                    </Button>
                    <Button onClick={handleDeploy} className="bg-green-600 hover:bg-green-700">
                      <Zap className="h-4 w-4 mr-2" />
                      Deploy Agent
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white text-sm">API Keys Required</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-yellow-900/20 border border-yellow-500/30 rounded">
                      <p className="text-yellow-300 text-sm">
                        <strong>OpenAI API Key:</strong> Required for GPT models
                      </p>
                    </div>
                    <div className="p-3 bg-yellow-900/20 border border-yellow-500/30 rounded">
                      <p className="text-yellow-300 text-sm">
                        <strong>DeepSeek API Key:</strong> Required for DeepSeek model
                      </p>
                    </div>
                    <div className="p-3 bg-yellow-900/20 border border-yellow-500/30 rounded">
                      <p className="text-yellow-300 text-sm">
                        <strong>Mixtral API Key:</strong> Required for Mixtral model
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AIAgentBuilder;

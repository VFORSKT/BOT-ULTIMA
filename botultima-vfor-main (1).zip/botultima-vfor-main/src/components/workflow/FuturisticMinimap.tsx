
import { MiniMap } from '@xyflow/react';
import { Button } from "@/components/ui/button";
import { Maximize, Minimize, Map } from 'lucide-react';
import { useState } from 'react';

const FuturisticMinimap = () => {
  const [isExpanded, setIsExpanded] = useState(false);

  const getNodeColor = (node: any) => {
    if (node.selected) return '#10b981';
    if (node.data?.isExecuting) return '#fbbf24';
    if (node.data?.executionResult?.success === false) return '#ef4444';
    if (node.data?.executionResult?.success === true) return '#10b981';
    
    switch (node.data?.category) {
      case 'ai': return '#8b5cf6';
      case 'action': return '#3b82f6';
      case 'transformation': return '#f59e0b';
      case 'flow-control': return '#06b6d4';
      case 'core': return '#6b7280';
      case 'human-loop': return '#ec4899';
      case 'basic': return '#10b981';
      default: return '#6b7280';
    }
  };

  return (
    <div className={`absolute top-4 left-4 z-20 bg-gray-900/95 border border-gray-600/50 rounded-xl overflow-hidden backdrop-blur-sm transition-all duration-300 shadow-2xl ${
      isExpanded ? 'w-80 h-60' : 'w-56 h-40'
    }`} style={{
      boxShadow: '0 0 20px rgba(59, 130, 246, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)'
    }}>
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 h-8 bg-gradient-to-r from-blue-600/20 to-purple-600/20 backdrop-blur-sm border-b border-gray-600/30 flex items-center justify-between px-3 z-30">
        <div className="flex items-center space-x-2">
          <Map className="h-3 w-3 text-blue-400" />
          <span className="text-xs text-gray-300 font-medium">Navigation</span>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsExpanded(!isExpanded)}
          className="h-5 w-5 p-0 text-gray-400 hover:text-white bg-transparent hover:bg-gray-700/50"
        >
          {isExpanded ? (
            <Minimize className="h-3 w-3" />
          ) : (
            <Maximize className="h-3 w-3" />
          )}
        </Button>
      </div>

      {/* Minimap */}
      <div className="pt-8 h-full relative overflow-hidden">
        <MiniMap
          nodeColor={getNodeColor}
          className="w-full h-full rounded-none"
          style={{
            backgroundColor: 'transparent',
          }}
          maskColor="rgba(0, 0, 0, 0.1)"
          pannable
          zoomable
        />
        
        {/* Glowing border effect */}
        <div className="absolute inset-0 border border-blue-400/30 rounded-lg pointer-events-none animate-pulse"></div>
      </div>
    </div>
  );
};

export default FuturisticMinimap;

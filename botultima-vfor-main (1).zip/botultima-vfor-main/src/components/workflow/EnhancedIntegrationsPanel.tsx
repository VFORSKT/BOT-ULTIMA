
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Mail, 
  FileText, 
  Database, 
  Send, 
  Key, 
  CheckCircle, 
  XCircle,
  Plus,
  Trash2,
  Search,
  Grid,
  List,
  MessageSquare,
  Slack,
  Github
} from 'lucide-react';

interface Integration {
  id: string;
  name: string;
  icon: any;
  connected: boolean;
  requiresOAuth: boolean;
  category: 'communication' | 'productivity' | 'storage' | 'development';
  description: string;
  apiKey?: string;
}

const EnhancedIntegrationsPanel = () => {
  const [integrations, setIntegrations] = useState<Integration[]>([
    { 
      id: 'gmail', 
      name: 'Gmail', 
      icon: Mail, 
      connected: false, 
      requiresOAuth: true,
      category: 'communication',
      description: 'Send and receive emails'
    },
    { 
      id: 'google-sheets', 
      name: 'Google Sheets', 
      icon: FileText, 
      connected: false, 
      requiresOAuth: true,
      category: 'productivity',
      description: 'Read and write spreadsheet data'
    },
    { 
      id: 'notion', 
      name: 'Notion', 
      icon: Database, 
      connected: false, 
      requiresOAuth: false,
      category: 'productivity',
      description: 'Manage databases and pages'
    },
    { 
      id: 'airtable', 
      name: 'Airtable', 
      icon: Database, 
      connected: false, 
      requiresOAuth: false,
      category: 'storage',
      description: 'Organize data in flexible tables'
    },
    { 
      id: 'telegram', 
      name: 'Telegram', 
      icon: Send, 
      connected: false, 
      requiresOAuth: false,
      category: 'communication',
      description: 'Send messages and notifications'
    },
    { 
      id: 'slack', 
      name: 'Slack', 
      icon: Slack, 
      connected: false, 
      requiresOAuth: true,
      category: 'communication',
      description: 'Team communication and automation'
    },
    { 
      id: 'discord', 
      name: 'Discord', 
      icon: MessageSquare, 
      connected: false, 
      requiresOAuth: false,
      category: 'communication',
      description: 'Send webhooks and manage servers'
    },
    { 
      id: 'github', 
      name: 'GitHub', 
      icon: Github, 
      connected: false, 
      requiresOAuth: true,
      category: 'development',
      description: 'Repository and issue management'
    },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showApiKeyInput, setShowApiKeyInput] = useState<string | null>(null);
  const [apiKeyInput, setApiKeyInput] = useState('');

  const categories = [
    { id: 'all', name: 'All', count: integrations.length },
    { id: 'communication', name: 'Communication', count: integrations.filter(i => i.category === 'communication').length },
    { id: 'productivity', name: 'Productivity', count: integrations.filter(i => i.category === 'productivity').length },
    { id: 'storage', name: 'Storage', count: integrations.filter(i => i.category === 'storage').length },
    { id: 'development', name: 'Development', count: integrations.filter(i => i.category === 'development').length },
  ];

  const filteredIntegrations = integrations.filter(integration => {
    const matchesSearch = integration.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         integration.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || integration.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleOAuthConnect = (integrationId: string) => {
    setIntegrations(prev => prev.map(integration => 
      integration.id === integrationId 
        ? { ...integration, connected: true }
        : integration
    ));
  };

  const handleApiKeySubmit = (integrationId: string) => {
    if (!apiKeyInput.trim()) return;
    
    setIntegrations(prev => prev.map(integration => 
      integration.id === integrationId 
        ? { ...integration, connected: true, apiKey: apiKeyInput }
        : integration
    ));
    
    setShowApiKeyInput(null);
    setApiKeyInput('');
  };

  const handleDisconnect = (integrationId: string) => {
    setIntegrations(prev => prev.map(integration => 
      integration.id === integrationId 
        ? { ...integration, connected: false, apiKey: undefined }
        : integration
    ));
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'communication': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'productivity': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'storage': return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      case 'development': return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  return (
    <div className="h-full bg-gray-800/50 border-gray-700 flex flex-col">
      <div className="p-4 border-b border-gray-700/50">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-white">Integrations</h2>
          <div className="flex items-center space-x-2">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('grid')}
            >
              <Grid className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('list')}
            >
              <List className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search integrations..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-gray-700 border-gray-600 text-white"
          />
        </div>

        <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
          <TabsList className="grid grid-cols-5 bg-gray-700/50 w-full">
            {categories.map(category => (
              <TabsTrigger 
                key={category.id} 
                value={category.id}
                className="text-xs data-[state=active]:bg-gray-600"
              >
                {category.name}
                <Badge variant="secondary" className="ml-1 text-xs">
                  {category.count}
                </Badge>
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      </div>

      <div className="flex-1 overflow-auto p-4">
        <div className={viewMode === 'grid' ? 'grid grid-cols-1 gap-4' : 'space-y-3'}>
          {filteredIntegrations.map((integration) => {
            const Icon = integration.icon;
            
            return (
              <Card 
                key={integration.id}
                className={`bg-gray-700/50 border-gray-600 transition-all duration-200 hover:bg-gray-700/70 ${
                  viewMode === 'grid' ? '' : 'flex items-center'
                }`}
              >
                <CardContent className={`${viewMode === 'grid' ? 'p-4' : 'p-3 flex items-center flex-1'}`}>
                  <div className={`flex items-center ${viewMode === 'grid' ? 'flex-col text-center' : 'space-x-3'}`}>
                    <div className={`${viewMode === 'grid' ? 'mb-3' : ''}`}>
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                    </div>
                    
                    <div className={`${viewMode === 'grid' ? 'text-center' : 'flex-1'}`}>
                      <div className="flex items-center justify-center space-x-2 mb-2">
                        <h3 className="font-medium text-white">{integration.name}</h3>
                        <Badge className={getCategoryColor(integration.category)}>
                          {integration.category}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-400 mb-3">{integration.description}</p>
                      
                      {integration.connected ? (
                        <div className="flex items-center justify-center space-x-2">
                          <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Connected
                          </Badge>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleDisconnect(integration.id)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      ) : (
                        <>
                          <Badge className="bg-red-500/20 text-red-400 border-red-500/30 mb-3">
                            <XCircle className="h-3 w-3 mr-1" />
                            Disconnected
                          </Badge>
                          
                          {integration.requiresOAuth ? (
                            <Button
                              size="sm"
                              className="w-full bg-blue-600 hover:bg-blue-700"
                              onClick={() => handleOAuthConnect(integration.id)}
                            >
                              <Plus className="h-3 w-3 mr-1" />
                              Connect with OAuth
                            </Button>
                          ) : (
                            <>
                              {showApiKeyInput === integration.id ? (
                                <div className="space-y-2 w-full">
                                  <Label className="text-xs text-gray-400">API Key</Label>
                                  <div className="flex space-x-2">
                                    <Input
                                      type="password"
                                      value={apiKeyInput}
                                      onChange={(e) => setApiKeyInput(e.target.value)}
                                      placeholder="Enter API key..."
                                      className="bg-gray-600 border-gray-500 text-white text-xs"
                                    />
                                    <Button
                                      size="sm"
                                      onClick={() => handleApiKeySubmit(integration.id)}
                                    >
                                      Save
                                    </Button>
                                  </div>
                                </div>
                              ) : (
                                <Button
                                  size="sm"
                                  className="w-full bg-gray-600 hover:bg-gray-700"
                                  onClick={() => setShowApiKeyInput(integration.id)}
                                >
                                  <Key className="h-3 w-3 mr-1" />
                                  Add API Key
                                </Button>
                              )}
                            </>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {filteredIntegrations.length === 0 && (
          <div className="text-center py-8">
            <p className="text-gray-400">No integrations found matching your criteria.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default EnhancedIntegrationsPanel;

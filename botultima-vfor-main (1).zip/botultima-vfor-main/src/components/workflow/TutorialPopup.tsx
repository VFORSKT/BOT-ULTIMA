
import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { X, Play } from 'lucide-react';

interface TutorialPopupProps {
  isOpen: boolean;
  onClose: () => void;
  onTryFlow: () => void;
}

const TutorialPopup = ({ isOpen, onClose, onTryFlow }: TutorialPopupProps) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl bg-gray-900 border-gray-700 text-white">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-green-400 flex items-center justify-between">
            Welcome to BOTultima Visual Builder!
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="text-center">
            <h3 className="text-xl font-semibold mb-4">Create AI Workflows with Drag & Drop</h3>
            
            {/* Animated Flowchart SVG */}
            <div className="bg-gray-800 rounded-lg p-6 mb-6">
              <svg width="600" height="400" viewBox="0 0 600 400" className="mx-auto">
                <defs>
                  <style>
                    {`
                      .flow-box { 
                        fill: #374151; 
                        stroke: #6B7280; 
                        stroke-width: 2; 
                        rx: 8; 
                      }
                      .flow-text { 
                        fill: white; 
                        font-family: Arial, sans-serif; 
                        font-size: 14px; 
                        text-anchor: middle; 
                        dominant-baseline: middle; 
                      }
                      .flow-arrow { 
                        stroke: #10B981; 
                        stroke-width: 2; 
                        marker-end: url(#arrowhead); 
                      }
                      .trigger-box { fill: #059669; }
                      .gpt-box { fill: #7C3AED; }
                      .condition-box { fill: #EA580C; }
                      .api-box { fill: #2563EB; }
                      .reply-box { fill: #10B981; }
                      .end-box { fill: #DC2626; }
                      
                      @keyframes flow-pulse {
                        0%, 100% { opacity: 1; }
                        50% { opacity: 0.6; }
                      }
                      .animated { animation: flow-pulse 2s infinite; }
                    `}
                  </style>
                  <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                    <polygon points="0 0, 10 3.5, 0 7" fill="#10B981" />
                  </marker>
                </defs>
                
                {/* Trigger Node */}
                <rect x="250" y="20" width="100" height="40" className="flow-box trigger-box animated" />
                <text x="300" y="40" className="flow-text">Trigger</text>
                
                {/* Arrow to GPT */}
                <line x1="300" y1="60" x2="300" y2="90" className="flow-arrow" />
                
                {/* GPT Node */}
                <rect x="225" y="100" width="150" height="40" className="flow-box gpt-box animated" />
                <text x="300" y="120" className="flow-text">GPT Prompt</text>
                
                {/* Arrow to Condition */}
                <line x1="300" y1="140" x2="300" y2="170" className="flow-arrow" />
                
                {/* Condition Node */}
                <rect x="240" y="180" width="120" height="40" className="flow-box condition-box animated" />
                <text x="300" y="200" className="flow-text">Condition</text>
                
                {/* Left branch - API Call */}
                <line x1="270" y1="220" x2="180" y2="270" className="flow-arrow" />
                <text x="200" y="240" className="flow-text" fontSize="12">if yes</text>
                <rect x="120" y="280" width="120" height="40" className="flow-box api-box animated" />
                <text x="180" y="300" className="flow-text">API Call</text>
                
                {/* Right branch - Reply */}
                <line x1="330" y1="220" x2="420" y2="270" className="flow-arrow" />
                <text x="400" y="240" className="flow-text" fontSize="12">else</text>
                <rect x="350" y="280" width="150" height="40" className="flow-box reply-box animated" />
                <text x="425" y="300" className="flow-text">Reply: "Sorry"</text>
                
                {/* Arrows to End */}
                <line x1="180" y1="320" x2="280" y2="360" className="flow-arrow" />
                <line x1="425" y1="320" x2="320" y2="360" className="flow-arrow" />
                
                {/* End Node */}
                <rect x="260" y="370" width="80" height="40" className="flow-box end-box animated" />
                <text x="300" y="390" className="flow-text">End</text>
              </svg>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
              <h4 className="font-semibold text-green-400 mb-2">🎯 Step 1: Drag Blocks</h4>
              <p className="text-gray-300">Drag workflow blocks from the left panel onto the canvas to build your bot's logic.</p>
            </div>
            
            <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
              <h4 className="font-semibold text-purple-400 mb-2">⚙️ Step 2: Configure</h4>
              <p className="text-gray-300">Click on any block to configure its settings in the right inspector panel.</p>
            </div>
            
            <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
              <h4 className="font-semibold text-blue-400 mb-2">🔗 Step 3: Connect</h4>
              <p className="text-gray-300">Draw arrows between blocks to create the conversation flow for your bot.</p>
            </div>
          </div>
          
          <div className="flex justify-center space-x-4">
            <Button onClick={onTryFlow} className="bg-green-600 hover:bg-green-700">
              <Play className="h-4 w-4 mr-2" />
              Try This Flow
            </Button>
            <Button variant="outline" onClick={onClose} className="border-gray-600 text-gray-300">
              Start Building
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TutorialPopup;

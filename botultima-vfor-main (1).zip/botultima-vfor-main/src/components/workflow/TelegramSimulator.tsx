
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Send, Bot, User } from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
  tokens?: number;
}

const TelegramSimulator = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: 'Hello! I\'m your workflow bot. Send me a message to test the flow.',
      timestamp: new Date(),
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [totalTokens, setTotalTokens] = useState(0);

  const simulateBotResponse = async (userMessage: string): Promise<string> => {
    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
    
    // Simulate different responses based on keywords
    if (userMessage.toLowerCase().includes('hello')) {
      return 'Hi there! How can I help you today?';
    } else if (userMessage.toLowerCase().includes('help')) {
      return 'I can help you with various tasks. Just tell me what you need!';
    } else if (userMessage.toLowerCase().includes('email')) {
      return 'I can help you manage your emails. Would you like me to check your inbox or send an email?';
    } else {
      return 'I understand you said: "' + userMessage + '". Let me process that for you...';
    }
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputMessage,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    const currentMessage = inputMessage;
    setInputMessage('');

    // Simulate bot processing
    const botResponse = await simulateBotResponse(currentMessage);
    const tokens = Math.floor(Math.random() * 100) + 20; // Simulate token usage

    const botMessage: Message = {
      id: (Date.now() + 1).toString(),
      type: 'bot',
      content: botResponse,
      timestamp: new Date(),
      tokens,
    };

    setMessages(prev => [...prev, botMessage]);
    setTotalTokens(prev => prev + tokens);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  return (
    <Card className="bg-gray-800/50 border-gray-700 h-full flex flex-col">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm text-gray-300 flex items-center justify-between">
          <span className="flex items-center">
            <Bot className="h-4 w-4 mr-2" />
            Bot Simulator
          </span>
          <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">
            {totalTokens} tokens used
          </Badge>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto space-y-3 mb-4 max-h-96">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] p-3 rounded-lg ${
                  message.type === 'user'
                    ? 'bg-blue-600 text-white ml-4'
                    : 'bg-gray-700 text-gray-100 mr-4'
                }`}
              >
                <div className="flex items-center space-x-2 mb-1">
                  {message.type === 'user' ? (
                    <User className="h-3 w-3" />
                  ) : (
                    <Bot className="h-3 w-3" />
                  )}
                  <span className="text-xs opacity-75">
                    {message.timestamp.toLocaleTimeString()}
                  </span>
                  {message.tokens && (
                    <Badge className="text-xs bg-gray-600 text-gray-300">
                      {message.tokens} tokens
                    </Badge>
                  )}
                </div>
                <p className="text-sm">{message.content}</p>
              </div>
            </div>
          ))}
        </div>
        
        {/* Input */}
        <div className="flex space-x-2">
          <Input
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type a message to test your bot..."
            className="flex-1 bg-gray-700 border-gray-600 text-white"
          />
          <Button 
            onClick={handleSendMessage}
            className="bg-blue-600 hover:bg-blue-700"
            disabled={!inputMessage.trim()}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default TelegramSimulator;

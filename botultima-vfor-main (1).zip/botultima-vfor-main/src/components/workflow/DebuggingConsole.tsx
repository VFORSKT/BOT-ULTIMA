
import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Play, 
  Pause, 
  Trash2, 
  Download, 
  CheckCircle, 
  AlertTriangle, 
  Info, 
  Clock,
  Bug
} from 'lucide-react';

interface LogEntry {
  id: string;
  timestamp: Date;
  level: 'info' | 'success' | 'warning' | 'error';
  nodeId?: string;
  nodeName?: string;
  message: string;
  duration?: number;
  data?: any;
}

interface DebuggingConsoleProps {
  isRunning?: boolean;
  onToggleLogging?: () => void;
}

const DebuggingConsole = ({ isRunning = false, onToggleLogging }: DebuggingConsoleProps) => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [isPaused, setIsPaused] = useState(false);
  const [autoScroll, setAutoScroll] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (autoScroll && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs, autoScroll]);

  const addLog = (entry: Omit<LogEntry, 'id' | 'timestamp'>) => {
    if (!isPaused) {
      const newLog: LogEntry = {
        ...entry,
        id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        timestamp: new Date(),
      };
      setLogs(prev => [...prev, newLog]);
    }
  };

  const clearLogs = () => {
    setLogs([]);
  };

  const exportLogs = () => {
    const logData = logs.map(log => ({
      timestamp: log.timestamp.toISOString(),
      level: log.level,
      nodeId: log.nodeId,
      nodeName: log.nodeName,
      message: log.message,
      duration: log.duration,
      data: log.data
    }));

    const blob = new Blob([JSON.stringify(logData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `workflow-logs-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getLogIcon = (level: LogEntry['level']) => {
    switch (level) {
      case 'success': return <CheckCircle className="h-4 w-4 text-green-400" />;
      case 'warning': return <AlertTriangle className="h-4 w-4 text-yellow-400" />;
      case 'error': return <AlertTriangle className="h-4 w-4 text-red-400" />;
      default: return <Info className="h-4 w-4 text-blue-400" />;
    }
  };

  const getLogColor = (level: LogEntry['level']) => {
    switch (level) {
      case 'success': return 'text-green-300';
      case 'warning': return 'text-yellow-300';
      case 'error': return 'text-red-300';
      default: return 'text-blue-300';
    }
  };

  // Simulate log entries for demonstration
  useEffect(() => {
    if (isRunning) {
      const interval = setInterval(() => {
        const sampleLogs = [
          { level: 'info' as const, message: 'Workflow execution started', nodeId: 'trigger-1', nodeName: 'HTTP Trigger' },
          { level: 'success' as const, message: 'Data processed successfully', nodeId: 'transform-1', nodeName: 'Data Transform', duration: 150 },
          { level: 'warning' as const, message: 'Rate limit approaching', nodeId: 'api-1', nodeName: 'API Call' },
          { level: 'error' as const, message: 'Connection timeout', nodeId: 'database-1', nodeName: 'Database Query' },
        ];
        
        const randomLog = sampleLogs[Math.floor(Math.random() * sampleLogs.length)];
        addLog(randomLog);
      }, 2000);

      return () => clearInterval(interval);
    }
  }, [isRunning, isPaused]);

  return (
    <Card className="h-full bg-gray-900/95 border-gray-700">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium text-white flex items-center">
            <Bug className="h-4 w-4 mr-2" />
            Debug Console
            {isRunning && (
              <Badge className="ml-2 bg-green-500/20 text-green-400 border-green-500/30">
                Running
              </Badge>
            )}
          </CardTitle>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsPaused(!isPaused)}
              className="text-gray-400 hover:text-white"
            >
              {isPaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={clearLogs}
              className="text-gray-400 hover:text-white"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={exportLogs}
              className="text-gray-400 hover:text-white"
            >
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="h-full p-0">
        <ScrollArea className="h-96" ref={scrollRef}>
          <div className="p-4 space-y-2">
            {logs.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                <Bug className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No debug logs yet</p>
                <p className="text-sm">Start a workflow to see execution logs</p>
              </div>
            ) : (
              logs.map(log => (
                <div
                  key={log.id}
                  className="flex items-start space-x-3 p-2 rounded-lg bg-gray-800/50 border border-gray-700/50"
                >
                  <div className="flex-shrink-0 mt-0.5">
                    {getLogIcon(log.level)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="text-xs text-gray-400">
                        {log.timestamp.toLocaleTimeString()}
                      </span>
                      {log.nodeId && (
                        <Badge variant="outline" className="text-xs">
                          {log.nodeName || log.nodeId}
                        </Badge>
                      )}
                      {log.duration && (
                        <div className="flex items-center text-xs text-gray-400">
                          <Clock className="h-3 w-3 mr-1" />
                          {log.duration}ms
                        </div>
                      )}
                    </div>
                    <p className={`text-sm ${getLogColor(log.level)}`}>
                      {log.message}
                    </p>
                    {log.data && (
                      <details className="mt-2">
                        <summary className="text-xs text-gray-400 cursor-pointer">
                          Show data
                        </summary>
                        <pre className="text-xs text-gray-300 mt-1 p-2 bg-gray-900/50 rounded overflow-x-auto">
                          {JSON.stringify(log.data, null, 2)}
                        </pre>
                      </details>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

export default DebuggingConsole;

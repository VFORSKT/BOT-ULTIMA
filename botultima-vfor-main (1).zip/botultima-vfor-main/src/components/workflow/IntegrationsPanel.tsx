
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { 
  Mail, 
  FileText, 
  Database, 
  Send, 
  Key, 
  CheckCircle, 
  XCircle,
  Plus,
  Trash2
} from 'lucide-react';

interface Integration {
  id: string;
  name: string;
  icon: any;
  connected: boolean;
  requiresOAuth: boolean;
  apiKey?: string;
}

const IntegrationsPanel = () => {
  const [integrations, setIntegrations] = useState<Integration[]>([
    { id: 'gmail', name: 'Gmail', icon: Mail, connected: false, requiresOAuth: true },
    { id: 'docs', name: 'Google Docs', icon: FileText, connected: false, requiresOAuth: true },
    { id: 'notion', name: 'Notion', icon: Database, connected: false, requiresOAuth: false },
    { id: 'airtable', name: 'Airtable', icon: Database, connected: false, requiresOAuth: false },
    { id: 'telegram', name: 'Telegram', icon: Send, connected: false, requiresOAuth: false },
  ]);

  const [showApiKeyInput, setShowApiKeyInput] = useState<string | null>(null);
  const [apiKeyInput, setApiKeyInput] = useState('');

  const handleOAuthConnect = (integrationId: string) => {
    // Simulate OAuth flow
    setIntegrations(prev => prev.map(integration => 
      integration.id === integrationId 
        ? { ...integration, connected: true }
        : integration
    ));
  };

  const handleApiKeySubmit = (integrationId: string) => {
    if (!apiKeyInput.trim()) return;
    
    setIntegrations(prev => prev.map(integration => 
      integration.id === integrationId 
        ? { ...integration, connected: true, apiKey: apiKeyInput }
        : integration
    ));
    
    setShowApiKeyInput(null);
    setApiKeyInput('');
  };

  const handleDisconnect = (integrationId: string) => {
    setIntegrations(prev => prev.map(integration => 
      integration.id === integrationId 
        ? { ...integration, connected: false, apiKey: undefined }
        : integration
    ));
  };

  return (
    <Card className="bg-gray-800/50 border-gray-700 h-full">
      <CardHeader>
        <CardTitle className="text-sm text-gray-300">Integrations</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {integrations.map((integration) => {
          const Icon = integration.icon;
          
          return (
            <div 
              key={integration.id}
              className="p-3 bg-gray-700/50 rounded-lg border border-gray-600"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-3">
                  <Icon className="h-5 w-5 text-gray-300" />
                  <span className="text-white font-medium">{integration.name}</span>
                </div>
                
                {integration.connected ? (
                  <div className="flex items-center space-x-2">
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Connected
                    </Badge>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDisconnect(integration.id)}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                ) : (
                  <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
                    <XCircle className="h-3 w-3 mr-1" />
                    Disconnected
                  </Badge>
                )}
              </div>
              
              {!integration.connected && (
                <div className="mt-2">
                  {integration.requiresOAuth ? (
                    <Button
                      size="sm"
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      onClick={() => handleOAuthConnect(integration.id)}
                    >
                      <Plus className="h-3 w-3 mr-1" />
                      Connect with OAuth
                    </Button>
                  ) : (
                    <>
                      {showApiKeyInput === integration.id ? (
                        <div className="space-y-2">
                          <Label className="text-xs text-gray-400">API Key</Label>
                          <div className="flex space-x-2">
                            <Input
                              type="password"
                              value={apiKeyInput}
                              onChange={(e) => setApiKeyInput(e.target.value)}
                              placeholder="Enter API key..."
                              className="bg-gray-600 border-gray-500 text-white text-xs"
                            />
                            <Button
                              size="sm"
                              onClick={() => handleApiKeySubmit(integration.id)}
                            >
                              Save
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <Button
                          size="sm"
                          className="w-full bg-gray-600 hover:bg-gray-700"
                          onClick={() => setShowApiKeyInput(integration.id)}
                        >
                          <Key className="h-3 w-3 mr-1" />
                          Add API Key
                        </Button>
                      )}
                    </>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
};

export default IntegrationsPanel;


import { memo } from 'react';
import { Handle, Position, NodeProps } from '@xyflow/react';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, 
  MessageSquare, 
  Code, 
  Settings,
  Play,
  CheckCircle,
  AlertTriangle,
  Link
} from 'lucide-react';
import { WorkflowNodeData } from '@/types/WorkflowTypes';

// Google Sheets Reader Node
export const GoogleSheetsNode = memo(({ data, selected }: NodeProps) => {
  const nodeData = data as WorkflowNodeData;
  
  return (
    <Card className={`min-w-48 bg-gray-900/95 border-2 transition-all duration-300 relative backdrop-blur-sm ${
      selected ? 'border-green-400 shadow-lg shadow-green-400/50 scale-105' : 'border-green-500/30 hover:border-green-400/50'
    } ${nodeData.isExecuting ? 'ring-2 ring-yellow-400 animate-pulse' : ''}`}>
      <div className="p-4">
        <div className="flex items-center space-x-3 mb-2">
          <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg">
            <FileText className="h-5 w-5 text-white" />
          </div>
          <div className="flex-1">
            <span className="font-semibold text-white text-sm">Google Sheets Reader</span>
            <div className="flex items-center space-x-1 mt-1">
              <span className="text-xs text-gray-400">Productivity</span>
              <span className="text-xs text-gray-500">•</span>
              <span className="text-xs text-gray-400">Read Data</span>
            </div>
          </div>
          <Settings className="h-4 w-4 text-gray-400 cursor-pointer hover:text-white transition-colors" />
        </div>

        {nodeData.config?.spreadsheetId && (
          <div className="mt-3 p-2 bg-green-900/20 rounded text-xs">
            <div className="flex items-center space-x-1 text-green-300">
              <Link className="h-3 w-3" />
              <span>Sheet: {nodeData.config.spreadsheetId.substring(0, 20)}...</span>
            </div>
            {nodeData.config.range && (
              <div className="text-green-400 mt-1">Range: {nodeData.config.range}</div>
            )}
          </div>
        )}

        {nodeData.executionResult && (
          <div className={`mt-3 p-2 rounded-lg text-xs border ${
            nodeData.executionResult.success 
              ? 'bg-green-900/30 text-green-300 border-green-500/30' 
              : 'bg-red-900/30 text-red-300 border-red-500/30'
          }`}>
            <div className="font-medium flex items-center space-x-1">
              {nodeData.executionResult.success ? (
                <CheckCircle className="h-3 w-3" />
              ) : (
                <AlertTriangle className="h-3 w-3" />
              )}
              <span>{nodeData.executionResult.success ? 'Data Retrieved' : 'Read Failed'}</span>
            </div>
            {nodeData.executionResult.output && (
              <div className="mt-1 text-gray-300 font-mono text-xs">{nodeData.executionResult.output}</div>
            )}
          </div>
        )}
      </div>
      
      <Handle
        type="target"
        position={Position.Top}
        className="w-4 h-4 bg-gray-700 border-2 border-blue-400 rounded-full"
      />
      <Handle
        type="source"
        position={Position.Bottom}
        className="w-4 h-4 bg-gray-700 border-2 border-green-400 rounded-full"
      />
    </Card>
  );
});

// Discord Webhook Sender Node
export const DiscordWebhookNode = memo(({ data, selected }: NodeProps) => {
  const nodeData = data as WorkflowNodeData;
  
  return (
    <Card className={`min-w-48 bg-gray-900/95 border-2 transition-all duration-300 relative backdrop-blur-sm ${
      selected ? 'border-green-400 shadow-lg shadow-green-400/50 scale-105' : 'border-indigo-500/30 hover:border-indigo-400/50'
    } ${nodeData.isExecuting ? 'ring-2 ring-yellow-400 animate-pulse' : ''}`}>
      <div className="p-4">
        <div className="flex items-center space-x-3 mb-2">
          <div className="w-10 h-10 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
            <MessageSquare className="h-5 w-5 text-white" />
          </div>
          <div className="flex-1">
            <span className="font-semibold text-white text-sm">Discord Webhook</span>
            <div className="flex items-center space-x-1 mt-1">
              <span className="text-xs text-gray-400">Communication</span>
              <span className="text-xs text-gray-500">•</span>
              <span className="text-xs text-gray-400">Send Message</span>
            </div>
          </div>
          <Settings className="h-4 w-4 text-gray-400 cursor-pointer hover:text-white transition-colors" />
        </div>

        {nodeData.config?.webhookUrl && (
          <div className="mt-3 p-2 bg-indigo-900/20 rounded text-xs">
            <div className="flex items-center space-x-1 text-indigo-300">
              <Link className="h-3 w-3" />
              <span>Webhook Connected</span>
            </div>
            {nodeData.config.botUsername && (
              <div className="text-indigo-400 mt-1">Bot: {nodeData.config.botUsername}</div>
            )}
          </div>
        )}

        {nodeData.executionResult && (
          <div className={`mt-3 p-2 rounded-lg text-xs border ${
            nodeData.executionResult.success 
              ? 'bg-green-900/30 text-green-300 border-green-500/30' 
              : 'bg-red-900/30 text-red-300 border-red-500/30'
          }`}>
            <div className="font-medium flex items-center space-x-1">
              {nodeData.executionResult.success ? (
                <CheckCircle className="h-3 w-3" />
              ) : (
                <AlertTriangle className="h-3 w-3" />
              )}
              <span>{nodeData.executionResult.success ? 'Message Sent' : 'Send Failed'}</span>
            </div>
            {nodeData.executionResult.error && (
              <div className="mt-1 text-red-400 font-mono text-xs">{nodeData.executionResult.error}</div>
            )}
          </div>
        )}
      </div>
      
      <Handle
        type="target"
        position={Position.Top}
        className="w-4 h-4 bg-gray-700 border-2 border-blue-400 rounded-full"
      />
      <Handle
        type="source"
        position={Position.Bottom}
        className="w-4 h-4 bg-gray-700 border-2 border-green-400 rounded-full"
      />
    </Card>
  );
});

// Custom JavaScript Code Runner Node
export const CustomCodeNode = memo(({ data, selected }: NodeProps) => {
  const nodeData = data as WorkflowNodeData;
  
  return (
    <Card className={`min-w-48 bg-gray-900/95 border-2 transition-all duration-300 relative backdrop-blur-sm ${
      selected ? 'border-green-400 shadow-lg shadow-green-400/50 scale-105' : 'border-orange-500/30 hover:border-orange-400/50'
    } ${nodeData.isExecuting ? 'ring-2 ring-yellow-400 animate-pulse' : ''}`}>
      <div className="p-4">
        <div className="flex items-center space-x-3 mb-2">
          <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-red-600 rounded-xl flex items-center justify-center shadow-lg">
            <Code className="h-5 w-5 text-white" />
          </div>
          <div className="flex-1">
            <span className="font-semibold text-white text-sm">Custom Code</span>
            <div className="flex items-center space-x-1 mt-1">
              <span className="text-xs text-gray-400">Transformation</span>
              <span className="text-xs text-gray-500">•</span>
              <span className="text-xs text-gray-400">JavaScript</span>
            </div>
          </div>
          <Settings className="h-4 w-4 text-gray-400 cursor-pointer hover:text-white transition-colors" />
        </div>

        {nodeData.config?.jsCode && (
          <div className="mt-3 p-2 bg-orange-900/20 rounded text-xs">
            <div className="flex items-center space-x-1 text-orange-300 mb-1">
              <Code className="h-3 w-3" />
              <span>Code Ready</span>
            </div>
            <div className="text-orange-400 font-mono text-xs bg-gray-900/50 p-1 rounded max-h-16 overflow-hidden">
              {nodeData.config.jsCode.substring(0, 100)}
              {nodeData.config.jsCode.length > 100 && '...'}
            </div>
          </div>
        )}

        <div className="mt-3 flex space-x-2">
          <Button size="sm" className="bg-orange-600 hover:bg-orange-700 text-xs">
            <Play className="h-3 w-3 mr-1" />
            Test
          </Button>
        </div>

        {nodeData.executionResult && (
          <div className={`mt-3 p-2 rounded-lg text-xs border ${
            nodeData.executionResult.success 
              ? 'bg-green-900/30 text-green-300 border-green-500/30' 
              : 'bg-red-900/30 text-red-300 border-red-500/30'
          }`}>
            <div className="font-medium flex items-center space-x-1">
              {nodeData.executionResult.success ? (
                <CheckCircle className="h-3 w-3" />
              ) : (
                <AlertTriangle className="h-3 w-3" />
              )}
              <span>{nodeData.executionResult.success ? 'Code Executed' : 'Execution Failed'}</span>
            </div>
            {nodeData.executionResult.output && (
              <div className="mt-1 text-gray-300 font-mono text-xs">{nodeData.executionResult.output}</div>
            )}
            {nodeData.executionResult.error && (
              <div className="mt-1 text-red-400 font-mono text-xs">{nodeData.executionResult.error}</div>
            )}
          </div>
        )}
      </div>
      
      <Handle
        type="target"
        position={Position.Top}
        className="w-4 h-4 bg-gray-700 border-2 border-blue-400 rounded-full"
      />
      <Handle
        type="source"
        position={Position.Bottom}
        className="w-4 h-4 bg-gray-700 border-2 border-green-400 rounded-full"
      />
    </Card>
  );
});

GoogleSheetsNode.displayName = 'GoogleSheetsNode';
DiscordWebhookNode.displayName = 'DiscordWebhookNode';  
CustomCodeNode.displayName = 'CustomCodeNode';

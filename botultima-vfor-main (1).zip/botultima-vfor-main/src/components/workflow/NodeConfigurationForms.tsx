
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  FileText, 
  MessageSquare, 
  Code, 
  Play,
  Save,
  AlertTriangle,
  CheckCircle,
  Eye,
  EyeOff
} from 'lucide-react';
import { WorkflowNodeData } from '@/types/WorkflowTypes';

interface NodeConfigFormProps {
  nodeData: WorkflowNodeData;
  onUpdate: (updates: Partial<WorkflowNodeData>) => void;
}

export const GoogleSheetsConfigForm = ({ nodeData, onUpdate }: NodeConfigFormProps) => {
  const [spreadsheetId, setSpreadsheetId] = useState(nodeData.config?.spreadsheetId || '');
  const [range, setRange] = useState(nodeData.config?.range || 'A:Z');
  const [headers, setHeaders] = useState(nodeData.config?.headers || true);
  const [isValidating, setIsValidating] = useState(false);

  const handleSave = () => {
    onUpdate({
      config: {
        ...nodeData.config,
        spreadsheetId,
        range,
        headers,
      }
    });
  };

  const validateConnection = async () => {
    setIsValidating(true);
    // Simulate validation
    setTimeout(() => {
      setIsValidating(false);
    }, 2000);
  };

  return (
    <Card className="bg-gray-800/50 border-gray-700">
      <CardHeader>
        <CardTitle className="text-sm text-white flex items-center">
          <FileText className="h-4 w-4 mr-2" />
          Google Sheets Configuration
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label className="text-gray-300">Spreadsheet ID</Label>
          <Input
            value={spreadsheetId}
            onChange={(e) => setSpreadsheetId(e.target.value)}
            placeholder="1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms"
            className="bg-gray-700 border-gray-600 text-white"
          />
          <p className="text-xs text-gray-400 mt-1">
            Extract from the Google Sheets URL between /d/ and /edit
          </p>
        </div>

        <div>
          <Label className="text-gray-300">Range</Label>
          <Input
            value={range}
            onChange={(e) => setRange(e.target.value)}
            placeholder="A:Z or A1:C10"
            className="bg-gray-700 border-gray-600 text-white"
          />
        </div>

        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={headers}
            onChange={(e) => setHeaders(e.target.checked)}
            className="rounded"
          />
          <Label className="text-gray-300">First row contains headers</Label>
        </div>

        <div className="flex space-x-2">
          <Button onClick={handleSave} className="bg-green-600 hover:bg-green-700">
            <Save className="h-4 w-4 mr-2" />
            Save Config
          </Button>
          <Button 
            onClick={validateConnection} 
            variant="outline" 
            disabled={isValidating}
            className="border-gray-600"
          >
            {isValidating ? (
              'Validating...'
            ) : (
              <>
                <Play className="h-4 w-4 mr-2" />
                Test Connection
              </>
            )}
          </Button>
        </div>

        {spreadsheetId && (
          <div className="mt-4 p-3 bg-green-900/20 border border-green-500/30 rounded">
            <div className="flex items-center text-green-400 text-sm">
              <CheckCircle className="h-4 w-4 mr-2" />
              Configuration ready
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export const DiscordWebhookConfigForm = ({ nodeData, onUpdate }: NodeConfigFormProps) => {
  const [webhookUrl, setWebhookUrl] = useState(nodeData.config?.webhookUrl || '');
  const [username, setUsername] = useState(nodeData.config?.username || 'Workflow Bot');
  const [avatarUrl, setAvatarUrl] = useState(nodeData.config?.avatarUrl || '');
  const [content, setContent] = useState(nodeData.config?.content || 'Hello from workflow!');
  const [embedTitle, setEmbedTitle] = useState(nodeData.config?.embedTitle || '');
  const [embedDescription, setEmbedDescription] = useState(nodeData.config?.embedDescription || '');
  const [showUrl, setShowUrl] = useState(false);

  const handleSave = () => {
    onUpdate({
      config: {
        ...nodeData.config,
        webhookUrl,
        username,
        avatarUrl,
        content,
        embedTitle,
        embedDescription,
      }
    });
  };

  const testWebhook = async () => {
    if (!webhookUrl) return;
    
    const payload = {
      username,
      avatar_url: avatarUrl,
      content: `🧪 Test message from workflow at ${new Date().toLocaleTimeString()}`,
      embeds: embedTitle || embedDescription ? [{
        title: embedTitle,
        description: embedDescription,
        color: 0x00ff00,
        timestamp: new Date().toISOString(),
      }] : undefined,
    };

    try {
      await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
    } catch (error) {
      console.error('Webhook test failed:', error);
    }
  };

  return (
    <Card className="bg-gray-800/50 border-gray-700">
      <CardHeader>
        <CardTitle className="text-sm text-white flex items-center">
          <MessageSquare className="h-4 w-4 mr-2" />
          Discord Webhook Configuration
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="basic">
          <TabsList className="grid w-full grid-cols-2 bg-gray-700/50">
            <TabsTrigger value="basic">Basic</TabsTrigger>
            <TabsTrigger value="advanced">Advanced</TabsTrigger>
          </TabsList>

          <TabsContent value="basic" className="space-y-4 mt-4">
            <div>
              <Label className="text-gray-300">Webhook URL</Label>
              <div className="relative">
                <Input
                  type={showUrl ? 'text' : 'password'}
                  value={webhookUrl}
                  onChange={(e) => setWebhookUrl(e.target.value)}
                  placeholder="https://discord.com/api/webhooks/..."
                  className="bg-gray-700 border-gray-600 text-white pr-10"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2"
                  onClick={() => setShowUrl(!showUrl)}
                >
                  {showUrl ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            <div>
              <Label className="text-gray-300">Message Content</Label>
              <Textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Your message content..."
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            <div>
              <Label className="text-gray-300">Bot Username</Label>
              <Input
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
          </TabsContent>

          <TabsContent value="advanced" className="space-y-4 mt-4">
            <div>
              <Label className="text-gray-300">Avatar URL</Label>
              <Input
                value={avatarUrl}
                onChange={(e) => setAvatarUrl(e.target.value)}
                placeholder="https://example.com/avatar.png"
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            <div>
              <Label className="text-gray-300">Embed Title</Label>
              <Input
                value={embedTitle}
                onChange={(e) => setEmbedTitle(e.target.value)}
                placeholder="Optional embed title"
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            <div>
              <Label className="text-gray-300">Embed Description</Label>
              <Textarea
                value={embedDescription}
                onChange={(e) => setEmbedDescription(e.target.value)}
                placeholder="Optional embed description"
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex space-x-2 mt-6">
          <Button onClick={handleSave} className="bg-indigo-600 hover:bg-indigo-700">
            <Save className="h-4 w-4 mr-2" />
            Save Config
          </Button>
          <Button onClick={testWebhook} variant="outline" className="border-gray-600">
            <Play className="h-4 w-4 mr-2" />
            Test Webhook
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export const CustomCodeConfigForm = ({ nodeData, onUpdate }: NodeConfigFormProps) => {
  const [jsCode, setJsCode] = useState(nodeData.config?.jsCode || `// Your JavaScript code here
function processData(input) {
  // Transform the input data
  const result = {
    processed: true,
    timestamp: new Date().toISOString(),
    data: input
  };
  
  return result;
}

// Return the result
return processData(input);`);
  const [testInput, setTestInput] = useState(nodeData.config?.testInput || '{"example": "data"}');
  const [isRunning, setIsRunning] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);

  const handleSave = () => {
    onUpdate({
      config: {
        ...nodeData.config,
        jsCode,
        testInput,
      }
    });
  };

  const runTest = async () => {
    setIsRunning(true);
    setTestResult(null);

    try {
      // Simulate code execution in a safe environment
      const inputData = JSON.parse(testInput);
      
      // In a real implementation, this would run in a sandboxed environment
      const result = {
        success: true,
        output: {
          processed: true,
          timestamp: new Date().toISOString(),
          data: inputData
        },
        executionTime: Math.floor(Math.random() * 100) + 50
      };

      setTimeout(() => {
        setTestResult(result);
        setIsRunning(false);
      }, 1000);
    } catch (error) {
      setTestResult({
        success: false,
        error: error instanceof Error ? error.message : 'Invalid JSON input'
      });
      setIsRunning(false);
    }
  };

  return (
    <Card className="bg-gray-800/50 border-gray-700">
      <CardHeader>
        <CardTitle className="text-sm text-white flex items-center">
          <Code className="h-4 w-4 mr-2" />
          Custom JavaScript Configuration
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="code">
          <TabsList className="grid w-full grid-cols-2 bg-gray-700/50">
            <TabsTrigger value="code">Code Editor</TabsTrigger>
            <TabsTrigger value="test">Test & Debug</TabsTrigger>
          </TabsList>

          <TabsContent value="code" className="space-y-4 mt-4">
            <div>
              <Label className="text-gray-300">JavaScript Code</Label>
              <Textarea
                value={jsCode}
                onChange={(e) => setJsCode(e.target.value)}
                className="bg-gray-900 border-gray-600 text-white font-mono text-sm h-64"
                placeholder="Enter your JavaScript code here..."
              />
              <p className="text-xs text-gray-400 mt-1">
                Available variables: <code>input</code> (incoming data). Use <code>return</code> to output results.
              </p>
            </div>
          </TabsContent>

          <TabsContent value="test" className="space-y-4 mt-4">
            <div>
              <Label className="text-gray-300">Test Input (JSON)</Label>
              <Textarea
                value={testInput}
                onChange={(e) => setTestInput(e.target.value)}
                className="bg-gray-900 border-gray-600 text-white font-mono text-sm h-24"
                placeholder='{"example": "data"}'
              />
            </div>

            <Button 
              onClick={runTest} 
              disabled={isRunning}
              className="bg-orange-600 hover:bg-orange-700"
            >
              <Play className="h-4 w-4 mr-2" />
              {isRunning ? 'Running...' : 'Test Code'}
            </Button>

            {testResult && (
              <div className={`p-3 rounded border ${
                testResult.success 
                  ? 'bg-green-900/20 border-green-500/30' 
                  : 'bg-red-900/20 border-red-500/30'
              }`}>
                <div className="flex items-center space-x-2 mb-2">
                  {testResult.success ? (
                    <CheckCircle className="h-4 w-4 text-green-400" />
                  ) : (
                    <AlertTriangle className="h-4 w-4 text-red-400" />
                  )}
                  <span className={`text-sm font-medium ${
                    testResult.success ? 'text-green-400' : 'text-red-400'
                  }`}>
                    {testResult.success ? 'Execution Successful' : 'Execution Failed'}
                  </span>
                  {testResult.executionTime && (
                    <Badge variant="outline" className="text-xs">
                      {testResult.executionTime}ms
                    </Badge>
                  )}
                </div>
                
                <pre className="text-xs bg-gray-900/50 p-2 rounded overflow-x-auto">
                  {testResult.success 
                    ? JSON.stringify(testResult.output, null, 2)
                    : testResult.error
                  }
                </pre>
              </div>
            )}
          </TabsContent>
        </Tabs>

        <div className="flex space-x-2 mt-6">
          <Button onClick={handleSave} className="bg-orange-600 hover:bg-orange-700">
            <Save className="h-4 w-4 mr-2" />
            Save Code
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

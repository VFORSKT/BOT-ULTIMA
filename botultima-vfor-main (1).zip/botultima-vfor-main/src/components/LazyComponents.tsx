
import { lazy, Suspense } from 'react';
import { Skeleton } from '@/components/ui/skeleton';

// Loading fallback component
const LoadingFallback = () => (
  <div className="space-y-4 p-4">
    <Skeleton className="h-8 w-full" />
    <Skeleton className="h-32 w-full" />
    <Skeleton className="h-8 w-3/4" />
  </div>
);

// Lazy loaded components for better performance
export const LazyWorkflowCanvas = lazy(() => import('@/components/workflow/WorkflowCanvas'));
export const LazyNodePalette = lazy(() => import('@/components/workflow/NodePalette'));
export const LazyInspectorPanel = lazy(() => import('@/components/workflow/InspectorPanel'));
export const LazyEnhancedIntegrationsPanel = lazy(() => import('@/components/workflow/EnhancedIntegrationsPanel'));
export const LazyWorkflowSimulator = lazy(() => import('@/components/workflow/WorkflowSimulator'));
export const LazyDebuggingConsole = lazy(() => import('@/components/workflow/DebuggingConsole'));
export const LazyAIAgentBuilder = lazy(() => import('@/components/workflow/AIAgentBuilder'));

// Wrapper components with proper error boundaries and loading states
export const WorkflowCanvasLazy = (props: any) => (
  <Suspense fallback={<LoadingFallback />}>
    <LazyWorkflowCanvas {...props} />
  </Suspense>
);

export const NodePaletteLazy = (props: any) => (
  <Suspense fallback={<LoadingFallback />}>
    <LazyNodePalette {...props} />
  </Suspense>
);

export const InspectorPanelLazy = (props: any) => (
  <Suspense fallback={<LoadingFallback />}>
    <LazyInspectorPanel {...props} />
  </Suspense>
);

export const EnhancedIntegrationsPanelLazy = (props: any) => (
  <Suspense fallback={<LoadingFallback />}>
    <LazyEnhancedIntegrationsPanel {...props} />
  </Suspense>
);

export const WorkflowSimulatorLazy = (props: any) => (
  <Suspense fallback={<LoadingFallback />}>
    <LazyWorkflowSimulator {...props} />
  </Suspense>
);

export const DebuggingConsoleLazy = (props: any) => (
  <Suspense fallback={<LoadingFallback />}>
    <LazyDebuggingConsole {...props} />
  </Suspense>
);

export const AIAgentBuilderLazy = (props: any) => (
  <Suspense fallback={<LoadingFallback />}>
    <LazyAIAgentBuilder {...props} />
  </Suspense>
);

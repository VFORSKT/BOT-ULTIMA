
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { 
  Bot, 
  Send, 
  Lightbulb, 
  X, 
  Minimize2, 
  Maximize2, 
  Sparkles,
  MessageSquare,
  HelpCircle
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  category?: string;
}

const AIAssistant = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'assistant',
      content: "Hello! I'm your AI assistant for BOTultima 3.0. I can help you build bots, understand features, troubleshoot issues, and guide you through the platform. What would you like to know?",
      timestamp: new Date(),
      category: 'welcome'
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const quickSuggestions = [
    { text: "How do I create my first bot?", category: "tutorial" },
    { text: "What integrations are available?", category: "features" },
    { text: "Help with workflow builder", category: "support" },
    { text: "Pricing and plan differences", category: "billing" },
    { text: "API documentation", category: "development" }
  ];

  useEffect(() => {
    // Auto-open assistant for new users
    const checkUserPreferences = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          const { data: preferences } = await supabase
            .from('user_preferences')
            .select('ai_assistant_auto_open, has_seen_welcome')
            .eq('user_id', user.id)
            .single();

          if (preferences?.ai_assistant_auto_open && !preferences?.has_seen_welcome) {
            setIsOpen(true);
            // Mark as seen
            await supabase
              .from('user_preferences')
              .update({ has_seen_welcome: true })
              .eq('user_id', user.id);
          }
        }
      } catch (error) {
        console.error('Error checking user preferences:', error);
      }
    };

    checkUserPreferences();
  }, []);

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsLoading(true);

    try {
      // Log the question
      const { data: { user } } = await supabase.auth.getUser();
      
      // Simulate AI response based on content
      let aiResponse = getAIResponse(inputMessage);
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: aiResponse,
        timestamp: new Date(),
        category: getCategoryFromMessage(inputMessage)
      };

      setMessages(prev => [...prev, assistantMessage]);

      // Log to database if user is authenticated
      if (user) {
        await supabase.from('ai_support_logs').insert({
          user_id: user.id,
          question: inputMessage,
          response: aiResponse,
          category: getCategoryFromMessage(inputMessage)
        });
      }
    } catch (error) {
      console.error('Error sending message:', error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: "I'm sorry, I encountered an error. Please try again or contact support if the issue persists.",
        timestamp: new Date(),
        category: 'error'
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const getAIResponse = (input: string): string => {
    const lowerInput = input.toLowerCase();
    
    if (lowerInput.includes('create') && lowerInput.includes('bot')) {
      return "To create your first bot:\n\n1. Click the 'Create New Bot' button on your dashboard\n2. Choose between Visual Builder or AI Agent mode\n3. In Visual Builder: Drag and drop nodes to create your workflow\n4. Start with a Trigger node, add AI processing with GPT nodes\n5. Connect actions like replies or integrations\n6. Test your bot using the simulator\n7. Deploy when ready!\n\nWould you like me to guide you through any specific step?";
    }
    
    if (lowerInput.includes('integration')) {
      return "BOTultima 3.0 supports many integrations:\n\n• **Messaging**: Telegram, WhatsApp, Discord\n• **AI Models**: GPT-4, GPT-4o-mini, Claude\n• **Productivity**: Gmail, Google Docs, Notion, Airtable\n• **Communication**: Slack, Microsoft Teams\n• **File Handling**: Upload/Download nodes\n• **APIs**: Custom API connections\n\nEach integration has pre-built nodes you can drag into your workflow. Need help setting up a specific integration?";
    }
    
    if (lowerInput.includes('workflow') || lowerInput.includes('builder')) {
      return "The Workflow Builder is your visual bot creation tool:\n\n• **Nodes**: Drag from the left panel (Trigger, GPT, Condition, Reply, etc.)\n• **Connections**: Link nodes to create your bot's logic flow\n• **Configuration**: Click any node to edit its settings in the right panel\n• **Testing**: Use the simulator tab to test your bot\n• **AI Suggestions**: Purple suggestions appear based on your workflow\n\nWhat specific aspect of the builder would you like help with?";
    }
    
    if (lowerInput.includes('pricing') || lowerInput.includes('plan')) {
      return "BOTultima 3.0 Pricing Plans:\n\n🆓 **Starter (Free)**\n• 1 bot\n• 3,000 Mixtral tokens/month\n• Community support\n• Basic integrations\n\n💡 **Maker (₹299/month)**\n• 5 bots\n• 20,000 GPT-4 tokens/month\n• AI Agents\n• All integrations\n• Priority support\n\n🚀 **Agency (₹1,999/month)**\n• Unlimited bots\n• 100,000 tokens/month\n• White-label\n• Team collaboration\n• Custom integrations\n\nUpgrade anytime from your dashboard!";
    }
    
    if (lowerInput.includes('api') || lowerInput.includes('documentation')) {
      return "BOTultima 3.0 API & Documentation:\n\n• **REST API**: Full CRUD operations for bots and workflows\n• **Webhooks**: Real-time bot events and triggers\n• **SDKs**: JavaScript, Python, and more coming soon\n• **OpenAPI Spec**: Complete API documentation\n• **Rate Limits**: Based on your plan\n\nAccess documentation at `/docs` or through the Help Center. Need specific API endpoints?";
    }
    
    return "I'm here to help with BOTultima 3.0! I can assist with:\n\n• Creating and managing bots\n• Understanding features and integrations\n• Troubleshooting issues\n• Billing and account questions\n• API documentation\n• Best practices and tips\n\nCould you be more specific about what you'd like help with?";
  };

  const getCategoryFromMessage = (input: string): string => {
    const lowerInput = input.toLowerCase();
    if (lowerInput.includes('create') || lowerInput.includes('tutorial')) return 'tutorial';
    if (lowerInput.includes('integration') || lowerInput.includes('api')) return 'development';
    if (lowerInput.includes('pricing') || lowerInput.includes('plan') || lowerInput.includes('billing')) return 'billing';
    if (lowerInput.includes('error') || lowerInput.includes('problem') || lowerInput.includes('help')) return 'support';
    return 'general';
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInputMessage(suggestion);
  };

  if (!isOpen) {
    return (
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setIsOpen(true)}
          className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 shadow-lg shadow-green-500/25 rounded-full p-4"
        >
          <Bot className="h-6 w-6" />
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <Card className={`bg-gray-900/95 border-green-500/30 backdrop-blur-sm transition-all duration-300 ${
        isMinimized ? 'w-80 h-16' : 'w-80 h-96'
      }`}>
        <CardHeader className="p-4 border-b border-gray-700/50">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center">
                <Bot className="h-4 w-4 text-white" />
              </div>
              <div>
                <CardTitle className="text-sm text-white">AI Assistant</CardTitle>
                <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">
                  <Sparkles className="h-3 w-3 mr-1" />
                  Online
                </Badge>
              </div>
            </div>
            <div className="flex items-center space-x-1">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setIsMinimized(!isMinimized)}
                className="text-gray-400 hover:text-white p-1"
              >
                {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setIsOpen(false)}
                className="text-gray-400 hover:text-white p-1"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>

        {!isMinimized && (
          <CardContent className="p-0 flex flex-col h-80">
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-lg text-sm ${
                      message.type === 'user'
                        ? 'bg-green-600 text-white'
                        : 'bg-gray-700 text-gray-100'
                    }`}
                  >
                    <div className="whitespace-pre-wrap">{message.content}</div>
                    {message.category && message.type === 'assistant' && (
                      <Badge className="mt-2 text-xs bg-gray-600/50 text-gray-300 border-gray-500/30">
                        {message.category}
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
              
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-gray-700 text-gray-100 p-3 rounded-lg text-sm">
                    <div className="flex items-center space-x-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-green-500"></div>
                      <span>Thinking...</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {quickSuggestions.length > 0 && messages.length <= 1 && (
              <div className="p-3 border-t border-gray-700/50">
                <div className="text-xs text-gray-400 mb-2 flex items-center">
                  <Lightbulb className="h-3 w-3 mr-1" />
                  Quick suggestions:
                </div>
                <div className="space-y-1">
                  {quickSuggestions.slice(0, 3).map((suggestion, index) => (
                    <button
                      key={index}
                      onClick={() => handleSuggestionClick(suggestion.text)}
                      className="w-full text-left text-xs p-2 bg-gray-800/50 hover:bg-gray-700/50 rounded border border-gray-600/30 hover:border-green-500/30 transition-colors text-gray-300"
                    >
                      {suggestion.text}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="p-3 border-t border-gray-700/50">
              <div className="flex space-x-2">
                <Textarea
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Ask me anything about BOTultima..."
                  className="flex-1 bg-gray-800 border-gray-600 text-white placeholder-gray-400 resize-none min-h-0 h-10"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                />
                <Button 
                  onClick={handleSendMessage}
                  disabled={!inputMessage.trim() || isLoading}
                  className="bg-green-600 hover:bg-green-700"
                  size="sm"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        )}
      </Card>
    </div>
  );
};

export default AIAssistant;

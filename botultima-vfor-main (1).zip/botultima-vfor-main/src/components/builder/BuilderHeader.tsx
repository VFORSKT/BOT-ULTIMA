
import { Badge } from "@/components/ui/badge";
import { Brain, Bot, Sparkles } from "lucide-react";

interface BuilderHeaderProps {
  mode: 'visual' | 'agent';
}

const BuilderHeader = ({ mode }: BuilderHeaderProps) => {
  return (
    <div className="h-16 bg-gradient-to-r from-gray-900/90 via-gray-800/90 to-gray-900/90 border-b border-gray-700/50 backdrop-blur-lg flex items-center justify-between px-6 shadow-lg">
      <div className="flex items-center space-x-6">
        <Badge className={`${
          mode === 'agent' 
            ? 'bg-gradient-to-r from-purple-500/20 to-pink-500/20 text-purple-300 border-purple-500/30 shadow-lg shadow-purple-500/10' 
            : 'bg-gradient-to-r from-blue-500/20 to-cyan-500/20 text-blue-300 border-blue-500/30 shadow-lg shadow-blue-500/10'
        } px-4 py-2 text-sm font-semibold transition-all duration-300 hover:scale-105`}>
          {mode === 'agent' ? <Brain className="h-4 w-4 mr-2" /> : <Bot className="h-4 w-4 mr-2" />}
          {mode === 'agent' ? 'AI Agent Builder' : 'Visual Builder'}
          <Sparkles className="h-3 w-3 ml-2 opacity-70" />
        </Badge>
      </div>
      
      <div className="flex items-center space-x-4">
        <div className="hidden md:flex items-center space-x-2 text-sm text-gray-400">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span>Live Preview</span>
        </div>
      </div>
    </div>
  );
};

export default BuilderHeader;

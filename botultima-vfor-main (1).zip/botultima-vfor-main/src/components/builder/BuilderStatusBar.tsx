
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Save, 
  Play, 
  Pause, 
  Wifi, 
  WifiOff, 
  Clock, 
  Users,
  Zap
} from "lucide-react";

interface BuilderStatusBarProps {
  isConnected?: boolean;
  lastSaved?: string;
  activeUsers?: number;
  isRunning?: boolean;
  onSave?: () => void;
  onToggleRun?: () => void;
}

const BuilderStatusBar = ({ 
  isConnected = true,
  lastSaved = "2 minutes ago",
  activeUsers = 1,
  isRunning = false,
  onSave,
  onToggleRun
}: BuilderStatusBarProps) => {
  return (
    <div className="h-12 bg-gray-900/90 border-t border-gray-700/50 backdrop-blur-sm flex items-center justify-between px-6 text-sm">
      {/* Left side - Status indicators */}
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          {isConnected ? (
            <Wifi className="h-4 w-4 text-green-400" />
          ) : (
            <WifiOff className="h-4 w-4 text-red-400" />
          )}
          <span className="text-gray-400">
            {isConnected ? 'Connected' : 'Disconnected'}
          </span>
        </div>
        
        <div className="flex items-center space-x-2 text-gray-400">
          <Clock className="h-4 w-4" />
          <span>Saved {lastSaved}</span>
        </div>
        
        <div className="flex items-center space-x-2 text-gray-400">
          <Users className="h-4 w-4" />
          <span>{activeUsers} active</span>
        </div>
      </div>

      {/* Right side - Actions */}
      <div className="flex items-center space-x-3">
        <Badge 
          variant="outline" 
          className={`${
            isRunning 
              ? 'border-green-500/50 text-green-400 bg-green-500/10' 
              : 'border-gray-500/50 text-gray-400 bg-gray-500/10'
          } transition-all duration-300`}
        >
          <div className={`w-2 h-2 rounded-full mr-2 ${
            isRunning ? 'bg-green-400 animate-pulse' : 'bg-gray-400'
          }`}></div>
          {isRunning ? 'Running' : 'Stopped'}
        </Badge>
        
        <Button
          size="sm"
          variant="ghost"
          onClick={onSave}
          className="text-gray-400 hover:text-white hover:bg-gray-700/50 transition-all duration-300"
        >
          <Save className="h-4 w-4 mr-1" />
          Save
        </Button>
        
        <Button
          size="sm"
          onClick={onToggleRun}
          className={`${
            isRunning
              ? 'bg-red-500/20 text-red-400 border-red-500/30 hover:bg-red-500/30'
              : 'bg-green-500/20 text-green-400 border-green-500/30 hover:bg-green-500/30'
          } transition-all duration-300 border`}
        >
          {isRunning ? (
            <>
              <Pause className="h-4 w-4 mr-1" />
              Stop
            </>
          ) : (
            <>
              <Play className="h-4 w-4 mr-1" />
              Run
              <Zap className="h-3 w-3 ml-1" />
            </>
          )}
        </Button>
      </div>
    </div>
  );
};

export default BuilderStatusBar;


import { Button } from "@/components/ui/button";
import { Bot, Brain, Zap } from "lucide-react";

type BuilderMode = 'visual' | 'agent';

interface BuilderModeToggleProps {
  currentMode: BuilderMode;
  onModeChange: (mode: BuilderMode) => void;
}

const BuilderModeToggle = ({ currentMode, onModeChange }: BuilderModeToggleProps) => {
  return (
    <div className="p-4">
      <div className="flex space-x-2 bg-gray-800/50 p-1 rounded-lg border border-gray-700/50">
        <Button 
          size="sm" 
          variant={currentMode === 'visual' ? 'default' : 'ghost'}
          onClick={() => onModeChange('visual')}
          className={`flex-1 transition-all duration-300 ${
            currentMode === 'visual' 
              ? 'bg-gradient-to-r from-blue-500 to-cyan-500 text-white shadow-lg shadow-blue-500/25 transform scale-105' 
              : 'text-gray-400 hover:text-white hover:bg-gray-700/50'
          }`}
        >
          <Bot className="h-4 w-4 mr-2" />
          Visual
          {currentMode === 'visual' && <Zap className="h-3 w-3 ml-2" />}
        </Button>
        <Button 
          size="sm" 
          variant={currentMode === 'agent' ? 'default' : 'ghost'}
          onClick={() => onModeChange('agent')}
          className={`flex-1 transition-all duration-300 ${
            currentMode === 'agent' 
              ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg shadow-purple-500/25 transform scale-105' 
              : 'text-gray-400 hover:text-white hover:bg-gray-700/50'
          }`}
        >
          <Brain className="h-4 w-4 mr-2" />
          Agent
          {currentMode === 'agent' && <Zap className="h-3 w-3 ml-2" />}
        </Button>
      </div>
    </div>
  );
};

export default BuilderModeToggle;


import { Button } from "@/components/ui/button";
import { 
  Undo, 
  Redo, 
  Copy, 
  Scissors, 
  FileText, 
  Download,
  Upload,
  Settings,
  HelpCircle,
  Zap
} from "lucide-react";

interface BuilderQuickActionsProps {
  onUndo?: () => void;
  onRedo?: () => void;
  onCopy?: () => void;
  onCut?: () => void;
  onExport?: () => void;
  onImport?: () => void;
  onSettings?: () => void;
  onHelp?: () => void;
}

const BuilderQuickActions = ({
  onUndo,
  onRedo,
  onCopy,
  onCut,
  onExport,
  onImport,
  onSettings,
  onHelp
}: BuilderQuickActionsProps) => {
  return (
    <div className="flex items-center space-x-1 bg-gray-800/50 rounded-lg p-1 border border-gray-700/50">
      {/* Edit Actions */}
      <div className="flex items-center space-x-1 pr-2 border-r border-gray-700/50">
        <Button
          size="sm"
          variant="ghost"
          onClick={onUndo}
          className="h-8 w-8 p-0 text-gray-400 hover:text-white hover:bg-gray-700/50 transition-all duration-200"
        >
          <Undo className="h-4 w-4" />
        </Button>
        <Button
          size="sm"
          variant="ghost"
          onClick={onRedo}
          className="h-8 w-8 p-0 text-gray-400 hover:text-white hover:bg-gray-700/50 transition-all duration-200"
        >
          <Redo className="h-4 w-4" />
        </Button>
      </div>

      {/* Clipboard Actions */}
      <div className="flex items-center space-x-1 pr-2 border-r border-gray-700/50">
        <Button
          size="sm"
          variant="ghost"
          onClick={onCopy}
          className="h-8 w-8 p-0 text-gray-400 hover:text-white hover:bg-gray-700/50 transition-all duration-200"
        >
          <Copy className="h-4 w-4" />
        </Button>
        <Button
          size="sm"
          variant="ghost"
          onClick={onCut}
          className="h-8 w-8 p-0 text-gray-400 hover:text-white hover:bg-gray-700/50 transition-all duration-200"
        >
          <Scissors className="h-4 w-4" />
        </Button>
      </div>

      {/* File Actions */}
      <div className="flex items-center space-x-1 pr-2 border-r border-gray-700/50">
        <Button
          size="sm"
          variant="ghost"
          onClick={onImport}
          className="h-8 w-8 p-0 text-gray-400 hover:text-white hover:bg-gray-700/50 transition-all duration-200"
        >
          <Upload className="h-4 w-4" />
        </Button>
        <Button
          size="sm"
          variant="ghost"
          onClick={onExport}
          className="h-8 w-8 p-0 text-gray-400 hover:text-white hover:bg-gray-700/50 transition-all duration-200"
        >
          <Download className="h-4 w-4" />
        </Button>
      </div>

      {/* Utility Actions */}
      <div className="flex items-center space-x-1">
        <Button
          size="sm"
          variant="ghost"
          onClick={onSettings}
          className="h-8 w-8 p-0 text-gray-400 hover:text-white hover:bg-gray-700/50 transition-all duration-200"
        >
          <Settings className="h-4 w-4" />
        </Button>
        <Button
          size="sm"
          variant="ghost"
          onClick={onHelp}
          className="h-8 w-8 p-0 text-gray-400 hover:text-white hover:bg-gray-700/50 transition-all duration-200"
        >
          <HelpCircle className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
};

export default BuilderQuickActions;


import { ReactNode } from 'react';
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, History, ArrowLeft } from "lucide-react";

interface BuilderSidebarProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
  onBack: () => void;
  title: string;
  subtitle: string;
  children: ReactNode;
}

const BuilderSidebar = ({ 
  collapsed, 
  onToggleCollapse, 
  onBack, 
  title, 
  subtitle, 
  children 
}: BuilderSidebarProps) => {
  return (
    <div className={`${
      collapsed ? 'w-16' : 'w-80'
    } bg-gradient-to-b from-gray-900/95 via-gray-900/90 to-gray-800/95 border-r border-gray-700/50 backdrop-blur-xl flex flex-col transition-all duration-500 ease-in-out shadow-2xl`}>
      
      {/* Header */}
      <div className="p-4 border-b border-gray-700/50 bg-gray-800/30">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onToggleCollapse}
              className="text-gray-400 hover:text-white hover:bg-gray-700/50 p-2 rounded-lg transition-all duration-300"
            >
              {collapsed ? 
                <ChevronRight className="h-4 w-4" /> : 
                <ChevronLeft className="h-4 w-4" />
              }
            </Button>
            {!collapsed && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={onBack}
                className="text-gray-400 hover:text-white hover:bg-gray-700/50 transition-all duration-300"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            )}
          </div>
          {!collapsed && (
            <div className="flex space-x-2">
              <Button 
                size="sm" 
                variant="outline" 
                className="bg-gray-700/50 border-gray-600/50 text-gray-300 hover:bg-gray-600/50 hover:text-white transition-all duration-300 shadow-lg"
              >
                <History className="h-4 w-4 mr-2" />
                Versions
              </Button>
            </div>
          )}
        </div>
        
        {!collapsed && (
          <div className="space-y-2">
            <h1 className="text-xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
              {title}
            </h1>
            <p className="text-gray-400 text-sm leading-relaxed">{subtitle}</p>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">
        {children}
      </div>

      {/* Footer gradient */}
      <div className="h-8 bg-gradient-to-t from-gray-900/80 to-transparent pointer-events-none"></div>
    </div>
  );
};

export default BuilderSidebar;

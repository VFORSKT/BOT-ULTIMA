import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Bot, Menu, X, User, LayoutDashboard, Settings as SettingsIcon, Wrench } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useUser, UserButton } from "@clerk/clerk-react";
const Navigation = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();
  const {
    isSignedIn,
    user
  } = useUser();
  return <nav className="fixed top-0 left-0 right-0 z-50 bg-gray-900/80 backdrop-blur-lg border-b border-gray-800/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-2 cursor-pointer" onClick={() => navigate('/')}>
            <div className="w-8 h-8 flex items-center justify-center transform hover:scale-110 transition-transform duration-300">
              <img alt="SixMorph Logo" src="/lovable-uploads/9b5733d6-6a35-4629-9541-608a5d04375f.jpg" className="w-8 h-8 object-fill" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-green-400 to-emerald-300 bg-clip-text text-transparent">SixMorph </span>
            <span className="text-xs bg-green-500/20 text-green-400 px-2 py-1 rounded-full">
              by VFOR
            </span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {isSignedIn && <>
                <button onClick={() => navigate('/dashboard')} className="text-gray-300 hover:text-green-400 transition-colors duration-300 flex items-center space-x-1">
                  <LayoutDashboard className="h-4 w-4" />
                  <span>Dashboard</span>
                </button>
                <button onClick={() => navigate('/my-bots')} className="text-gray-300 hover:text-green-400 transition-colors duration-300 flex items-center space-x-1">
                  <Bot className="h-4 w-4" />
                  <span>My Bots</span>
                </button>
                <button onClick={() => navigate('/builder')} className="text-gray-300 hover:text-green-400 transition-colors duration-300 flex items-center space-x-1">
                  <Wrench className="h-4 w-4" />
                  <span>Builder</span>
                </button>
                <button onClick={() => navigate('/settings')} className="text-gray-300 hover:text-green-400 transition-colors duration-300 flex items-center space-x-1">
                  <SettingsIcon className="h-4 w-4" />
                  <span>Settings</span>
                </button>
              </>}
            {!isSignedIn && <button onClick={() => navigate('/dashboard')} className="text-gray-300 hover:text-green-400 transition-colors duration-300 flex items-center space-x-1">
                <LayoutDashboard className="h-4 w-4" />
                <span>Dashboard</span>
              </button>}
            <button onClick={() => {
            const element = document.getElementById('features');
            if (element) {
              element.scrollIntoView({
                behavior: 'smooth'
              });
            } else {
              navigate('/#features');
            }
          }} className="text-gray-300 hover:text-green-400 transition-colors duration-300">
              Features
            </button>
            <button onClick={() => {
            const element = document.getElementById('pricing');
            if (element) {
              element.scrollIntoView({
                behavior: 'smooth'
              });
            } else {
              navigate('/pricing');
            }
          }} className="text-gray-300 hover:text-green-400 transition-colors duration-300">
              Pricing
            </button>
            <button onClick={() => navigate('/marketplace')} className="text-gray-300 hover:text-green-400 transition-colors duration-300">
              Marketplace
            </button>
            <button onClick={() => navigate('/docs')} className="text-gray-300 hover:text-green-400 transition-colors duration-300">
              Docs
            </button>
          </div>

          {/* Desktop Auth Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            {isSignedIn ? <div className="flex items-center space-x-4">
                <span className="text-gray-300 text-sm">
                  Welcome, {user?.firstName || user?.emailAddresses[0]?.emailAddress}
                </span>
                <UserButton appearance={{
              elements: {
                avatarBox: "w-8 h-8"
              }
            }} afterSignOutUrl="/" />
              </div> : <>
                <Button variant="ghost" className="text-gray-300 hover:text-green-400 hover:bg-green-500/10" onClick={() => navigate('/auth')}>
                  Sign In
                </Button>
                <Button className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white px-6 rounded-lg shadow-lg shadow-green-500/25 transform hover:scale-105 transition-all duration-300" onClick={() => navigate('/auth')}>
                  Get Started
                </Button>
              </>}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button variant="ghost" size="sm" onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-gray-300 hover:text-green-400">
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 bg-gray-900/95 rounded-lg mt-2 border border-gray-800/50">
              {isSignedIn && <>
                  <button onClick={() => {
              setIsMenuOpen(false);
              navigate('/dashboard');
            }} className="block w-full text-left px-3 py-2 text-gray-300 hover:text-green-400 transition-colors">
                    Dashboard
                  </button>
                  <button onClick={() => {
              setIsMenuOpen(false);
              navigate('/my-bots');
            }} className="block w-full text-left px-3 py-2 text-gray-300 hover:text-green-400 transition-colors">
                    My Bots
                  </button>
                  <button onClick={() => {
              setIsMenuOpen(false);
              navigate('/builder');
            }} className="block w-full text-left px-3 py-2 text-gray-300 hover:text-green-400 transition-colors">
                    Builder
                  </button>
                  <button onClick={() => {
              setIsMenuOpen(false);
              navigate('/settings');
            }} className="block w-full text-left px-3 py-2 text-gray-300 hover:text-green-400 transition-colors">
                    Settings
                  </button>
                </>}
              {!isSignedIn && <button onClick={() => {
            setIsMenuOpen(false);
            navigate('/dashboard');
          }} className="block w-full text-left px-3 py-2 text-gray-300 hover:text-green-400 transition-colors">
                  Dashboard
                </button>}
              <button onClick={() => {
            setIsMenuOpen(false);
            const element = document.getElementById('features');
            if (element) {
              element.scrollIntoView({
                behavior: 'smooth'
              });
            } else {
              navigate('/#features');
            }
          }} className="block w-full text-left px-3 py-2 text-gray-300 hover:text-green-400 transition-colors">
                Features
              </button>
              <button onClick={() => {
            setIsMenuOpen(false);
            const element = document.getElementById('pricing');
            if (element) {
              element.scrollIntoView({
                behavior: 'smooth'
              });
            } else {
              navigate('/pricing');
            }
          }} className="block w-full text-left px-3 py-2 text-gray-300 hover:text-green-400 transition-colors">
                Pricing
              </button>
              <button onClick={() => {
            setIsMenuOpen(false);
            navigate('/marketplace');
          }} className="block w-full text-left px-3 py-2 text-gray-300 hover:text-green-400 transition-colors">
                Marketplace
              </button>
              <button onClick={() => {
            setIsMenuOpen(false);
            navigate('/docs');
          }} className="block w-full text-left px-3 py-2 text-gray-300 hover:text-green-400 transition-colors">
                Docs
              </button>
              <div className="border-t border-gray-800/50 pt-3 mt-3">
                {isSignedIn ? <div className="px-3 py-2">
                    <UserButton afterSignOutUrl="/" />
                  </div> : <>
                    <Button variant="ghost" className="w-full justify-start text-gray-300 hover:text-green-400 hover:bg-green-500/10" onClick={() => {
                setIsMenuOpen(false);
                navigate('/auth');
              }}>
                      Sign In
                    </Button>
                    <Button className="w-full mt-2 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700" onClick={() => {
                setIsMenuOpen(false);
                navigate('/auth');
              }}>
                      Get Started
                    </Button>
                  </>}
              </div>
            </div>
          </div>}
      </div>
    </nav>;
};
export default Navigation;

import { useState, useEffect } from "react";
import { useUser } from "@clerk/clerk-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart3, 
  Bot, 
  Brain, 
  TrendingUp, 
  Users, 
  Zap,
  Activity,
  Calendar
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

interface UserStats {
  totalBots: number;
  totalAgents: number;
  totalExecutions: number;
  totalInteractions: number;
  activeWorkflows: number;
  createdThisMonth: number;
}

const UserAnalytics = () => {
  const { user } = useUser();
  const [stats, setStats] = useState<UserStats>({
    totalBots: 0,
    totalAgents: 0,
    totalExecutions: 0,
    totalInteractions: 0,
    activeWorkflows: 0,
    createdThisMonth: 0
  });
  const [isLoading, setIsLoading] = useState(true);
  const [chartData, setChartData] = useState<any[]>([]);

  useEffect(() => {
    if (user?.id) {
      loadUserStats();
      loadChartData();
    }
  }, [user?.id]);

  const loadUserStats = async () => {
    if (!user?.id) return;

    try {
      // Get user's bots count
      const { data: bots, error: botsError } = await supabase
        .from('bots')
        .select('id, created_at, is_deployed')
        .eq('user_id', user.id);

      if (botsError) throw botsError;

      // Get user's agents count
      const { data: agents, error: agentsError } = await supabase
        .from('agents')
        .select('id, created_at, is_active')
        .eq('user_id', user.id);

      if (agentsError) throw agentsError;

      // Get workflow executions count
      const { data: executions, error: executionsError } = await supabase
        .from('workflow_executions')
        .select('id, started_at, status')
        .eq('user_id', user.id);

      if (executionsError) throw executionsError;

      // Calculate stats
      const now = new Date();
      const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      
      const botsThisMonth = bots?.filter(bot => new Date(bot.created_at) >= thisMonth).length || 0;
      const agentsThisMonth = agents?.filter(agent => new Date(agent.created_at) >= thisMonth).length || 0;
      
      setStats({
        totalBots: bots?.length || 0,
        totalAgents: agents?.length || 0,
        totalExecutions: executions?.length || 0,
        totalInteractions: (executions?.length || 0) * 3, // Simulated interaction count
        activeWorkflows: bots?.filter(bot => bot.is_deployed).length || 0,
        createdThisMonth: botsThisMonth + agentsThisMonth
      });

    } catch (error) {
      console.error('Error loading user stats:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadChartData = async () => {
    if (!user?.id) return;

    try {
      // Generate last 7 days data
      const last7Days = Array.from({ length: 7 }, (_, i) => {
        const date = new Date();
        date.setDate(date.getDate() - (6 - i));
        return {
          date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
          bots: Math.floor(Math.random() * 5) + 1,
          agents: Math.floor(Math.random() * 3) + 1,
          executions: Math.floor(Math.random() * 10) + 2
        };
      });

      setChartData(last7Days);
    } catch (error) {
      console.error('Error loading chart data:', error);
    }
  };

  const statCards = [
    {
      title: "Total Bots",
      value: stats.totalBots,
      change: `+${Math.min(stats.createdThisMonth, stats.totalBots)} this month`,
      icon: <Bot className="h-5 w-5" />,
      color: "text-green-400"
    },
    {
      title: "AI Agents", 
      value: stats.totalAgents,
      change: `${stats.totalAgents > 0 ? stats.totalAgents : 0} active`,
      icon: <Brain className="h-5 w-5" />,
      color: "text-blue-400"
    },
    {
      title: "Workflow Runs",
      value: stats.totalExecutions,
      change: `${stats.activeWorkflows} active workflows`,
      icon: <Zap className="h-5 w-5" />,
      color: "text-yellow-400"
    },
    {
      title: "Total Interactions",
      value: stats.totalInteractions,
      change: `~${Math.round(stats.totalInteractions / Math.max(stats.totalBots, 1))} avg per bot`,
      icon: <Activity className="h-5 w-5" />,
      color: "text-purple-400"
    }
  ];

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="text-center py-8 text-gray-400">Loading your analytics...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Your Analytics</h2>
          <p className="text-gray-400">Personal dashboard for your bots and AI agents</p>
        </div>
        <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
          <Calendar className="h-4 w-4 mr-2" />
          Last 30 days
        </Badge>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => (
          <Card key={index} className="bg-gray-800/50 border-gray-700 hover:border-green-500/30 transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm font-medium">{stat.title}</p>
                  <p className="text-2xl font-bold text-white mt-2">{stat.value}</p>
                  <p className="text-sm text-gray-500 mt-1">{stat.change}</p>
                </div>
                <div className={stat.color}>
                  {stat.icon}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Activity Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="date" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937', 
                    border: '1px solid #374151',
                    borderRadius: '8px'
                  }}
                />
                <Line type="monotone" dataKey="executions" stroke="#10B981" strokeWidth={2} />
                <Line type="monotone" dataKey="bots" stroke="#3B82F6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Resource Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="date" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937', 
                    border: '1px solid #374151',
                    borderRadius: '8px'
                  }}
                />
                <Bar dataKey="bots" fill="#10B981" />
                <Bar dataKey="agents" fill="#8B5CF6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array.from({ length: 5 }, (_, i) => (
              <div key={i} className="flex items-center space-x-4 p-3 bg-gray-900/50 rounded-lg">
                <div className="w-8 h-8 bg-green-500/20 rounded-full flex items-center justify-center">
                  <Bot className="h-4 w-4 text-green-400" />
                </div>
                <div className="flex-1">
                  <p className="text-white text-sm">Bot workflow executed successfully</p>
                  <p className="text-gray-400 text-xs">
                    {new Date(Date.now() - (i * 3600000)).toLocaleString()}
                  </p>
                </div>
                <Badge className="bg-green-500/20 text-green-400 text-xs">
                  Success
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UserAnalytics;

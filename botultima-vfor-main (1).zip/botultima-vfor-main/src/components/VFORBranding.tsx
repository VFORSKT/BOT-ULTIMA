
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Heart, Users, Globe } from "lucide-react";
const VFORBranding = () => {
  return <div className="bg-gradient-to-r from-green-900/20 to-emerald-900/20 border border-green-500/20 rounded-xl p-6">
      <div className="flex items-start space-x-4">
        <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg">
          <Users className="h-8 w-8 text-white" />
        </div>
        
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <h3 className="text-xl font-bold text-white">VFOR Community</h3>
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
              <Heart className="h-3 w-3 mr-1" />
              India
            </Badge>
          </div>
          
          <p className="text-gray-300 text-sm leading-relaxed mb-4">We are a passionate group of developers and AI enthusiasts from India, united under the VFOR Community. SixMorph was built by our team to democratize AI automation and empower creators worldwide.</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
            <div className="flex items-center space-x-2 text-sm text-gray-400">
              <Globe className="h-4 w-4 text-green-400" />
              <span>Global Impact</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-gray-400">
              <Heart className="h-4 w-4 text-red-400" />
              <span>Community First</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-gray-400">
              <Users className="h-4 w-4 text-blue-400" />
              <span>Open Source</span>
            </div>
          </div>
          
          <div className="bg-gray-800/30 rounded-lg p-4 border border-gray-700/30">
            <p className="text-gray-300 text-sm mb-3">
              <strong className="text-green-400">Our Mission:</strong> Maximum profits from SixMorph go back to the VFOR community, 
              charities, and funding future open-source projects that benefit everyone.
            </p>
            
            <div className="flex flex-wrap gap-3">
              <a href="https://www.reddit.com/r/VFORcommunitylabs/s/IVRGOXrU3U" target="_blank" rel="noopener noreferrer" className="inline-flex items-center space-x-2 text-green-400 hover:text-green-300 transition-colors text-sm">
                <span>Join Community</span>
                <ExternalLink className="h-3 w-3" />
              </a>
              
              <a href="https://www.instagram.com/vforcommunitylabs?igsh=MWp6eGRoNm5nNGNoMw==" target="_blank" rel="noopener noreferrer" className="inline-flex items-center space-x-2 text-blue-400 hover:text-blue-300 transition-colors text-sm">
                <span>Instagram</span>
                <ExternalLink className="h-3 w-3" />
              </a>
              
              <a href="https://x.com/vforcommunity7?t=Yg_SSQkGH1kZY23PIerUOg&s=35" target="_blank" rel="noopener noreferrer" className="inline-flex items-center space-x-2 text-gray-400 hover:text-gray-300 transition-colors text-sm">
                <span>Twitter</span>
                <ExternalLink className="h-3 w-3" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>;
};
export default VFORBranding;

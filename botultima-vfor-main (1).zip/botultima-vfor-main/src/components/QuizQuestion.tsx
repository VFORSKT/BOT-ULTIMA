
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Check } from "lucide-react";

interface QuizQuestionProps {
  question: string;
  options: string[];
  selectedAnswer?: string;
  onAnswerSelect: (answer: string) => void;
}

const QuizQuestion = ({ question, options, selectedAnswer, onAnswerSelect }: QuizQuestionProps) => {
  const [hoveredOption, setHoveredOption] = useState<string | null>(null);

  return (
    <div className="space-y-3">
      <div className="grid gap-3">
        {options.map((option, index) => {
          const isSelected = selectedAnswer === option;
          const isHovered = hoveredOption === option;
          
          return (
            <Card
              key={index}
              className={`cursor-pointer transition-all duration-200 ${
                isSelected
                  ? 'bg-green-500/20 border-green-500 ring-1 ring-green-500/50'
                  : isHovered
                  ? 'bg-gray-700/50 border-gray-500'
                  : 'bg-gray-700/30 border-gray-600 hover:border-gray-500'
              }`}
              onClick={() => onAnswerSelect(option)}
              onMouseEnter={() => setHoveredOption(option)}
              onMouseLeave={() => setHoveredOption(null)}
            >
              <div className="p-4 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                    isSelected
                      ? 'border-green-500 bg-green-500'
                      : 'border-gray-400'
                  }`}>
                    {isSelected && <Check className="h-3 w-3 text-white" />}
                  </div>
                  <span className={`font-medium transition-colors ${
                    isSelected ? 'text-green-300' : 'text-gray-200'
                  }`}>
                    {option}
                  </span>
                </div>
                
                <div className={`text-xs px-2 py-1 rounded-full transition-all ${
                  isSelected
                    ? 'bg-green-500/30 text-green-300'
                    : 'bg-gray-600/50 text-gray-400'
                }`}>
                  {String.fromCharCode(65 + index)}
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default QuizQuestion;

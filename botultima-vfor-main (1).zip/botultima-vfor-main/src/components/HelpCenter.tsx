
import { useState, useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { 
  Search, 
  BookOpen, 
  MessageSquare, 
  Lightbulb, 
  Bot,
  Clock,
  CheckCircle,
  HelpCircle,
  ArrowRight,
  Star
} from 'lucide-react';
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";

const HelpCenter = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [supportRequests, setSupportRequests] = useState<any[]>([]);
  const navigate = useNavigate();

  const faqs = [
    {
      id: '1',
      question: 'How do I create my first bot?',
      answer: 'To create your first bot, go to the Builder page and start by dragging a "Trigger" block onto the canvas. Then add AI blocks like "GPT Response" and connect them together. Configure each block by clicking on it and filling in the settings.',
      category: 'Getting Started',
      helpful: 24,
    },
    {
      id: '2',
      question: 'What integrations are available?',
      answer: 'BOTultima supports Gmail, Notion, Airtable, Telegram, Google Docs, and custom API integrations. You can connect these by adding the respective blocks to your workflow and providing API credentials.',
      category: 'Integrations',
      helpful: 18,
    },
    {
      id: '3',
      question: 'How do I upgrade my plan?',
      answer: 'You can upgrade your plan from the Pricing page or your Dashboard. We offer Maker (₹299/month) and Agency (₹1,999/month) plans with additional features like more tokens, integrations, and priority support.',
      category: 'Billing',
      helpful: 31,
    },
    {
      id: '4',
      question: 'How do I deploy my bot to Telegram?',
      answer: 'First create a bot with @BotFather on Telegram to get your bot token. Then add a Telegram block to your workflow, enter the token, and click Deploy. Your bot will be live instantly!',
      category: 'Deployment',
      helpful: 27,
    },
    {
      id: '5',
      question: 'What AI models can I use?',
      answer: 'Free plans get Mixtral tokens, while paid plans get access to GPT-4. Maker plan includes 20K GPT-4 tokens monthly, and Agency plan has unlimited tokens.',
      category: 'AI Features',
      helpful: 22,
    },
    {
      id: '6',
      question: 'How do I set up Gmail integration?',
      answer: 'Add a Gmail block to your workflow, then configure it with your Gmail API credentials. For paid plans, we provide OAuth integration for easier setup.',
      category: 'Integrations',
      helpful: 15,
    },
  ];

  const categories = ['All', 'Getting Started', 'Integrations', 'Billing', 'Deployment', 'AI Features'];

  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredFAQs = faqs.filter(faq => 
    (selectedCategory === 'All' || faq.category === selectedCategory) &&
    (searchQuery === '' || 
     faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
     faq.answer.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleAISearch = async () => {
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    
    try {
      const user = await supabase.auth.getUser();
      if (!user.data.user) {
        toast({
          title: "Authentication Required",
          description: "Please log in to use AI search.",
          variant: "destructive",
        });
        navigate('/auth');
        return;
      }

      // Mock AI response - in real implementation, this would call OpenAI
      const mockAIResponse = `Based on your question "${searchQuery}", here are some suggestions:

1. Check our documentation for detailed guides
2. Try the visual builder to create your workflow step by step  
3. Use the tutorials section for video guides
4. Contact support if you need personalized help

For immediate help, you can also use the AI assistant in the bottom right corner of your screen.`;

      // Save support request to database
      const { error } = await supabase
        .from('support_requests')
        .insert({
          question: searchQuery,
          ai_response: mockAIResponse,
          user_id: user.data.user.id,
        });

      if (error) {
        console.error('Error saving support request:', error);
      }

      setSearchResults([{
        id: Date.now(),
        question: searchQuery,
        answer: mockAIResponse,
        type: 'ai-response'
      }]);

      toast({
        title: "AI Search Complete",
        description: "Here's what I found for your question.",
      });
    } catch (error) {
      console.error('Error with AI search:', error);
      toast({
        title: "Search Error",
        description: "Something went wrong with the AI search. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSearching(false);
    }
  };

  const loadSupportHistory = useCallback(async () => {
    try {
      const user = await supabase.auth.getUser();
      if (!user.data.user) return;

      const { data, error } = await supabase
        .from('support_requests')
        .select('*')
        .eq('user_id', user.data.user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error loading support history:', error);
        return;
      }

      setSupportRequests(data || []);
    } catch (error) {
      console.error('Error loading support history:', error);
    }
  }, []);

  const markAsHelpful = (faqId: string) => {
    toast({
      title: "Thanks for your feedback!",
      description: "This helps us improve our help center.",
    });
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-green-400 to-emerald-300 bg-clip-text text-transparent">
          Help Center
        </h1>
        <p className="text-xl text-gray-400">
          Get help building amazing AI bots with BOTultima
        </p>
      </div>

      {/* AI-Powered Search */}
      <Card className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border-green-500/30">
        <CardHeader>
          <CardTitle className="flex items-center text-white">
            <Bot className="w-6 h-6 mr-2 text-green-400" />
            AI-Powered Search
          </CardTitle>
          <CardDescription>
            Ask anything about BOTultima and get instant AI-powered answers
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-2">
            <Input
              placeholder="Ask me anything: 'How do I create a customer support bot?'"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 bg-gray-800 border-gray-600 text-white"
              onKeyPress={(e) => e.key === 'Enter' && handleAISearch()}
            />
            <Button 
              onClick={handleAISearch}
              disabled={isSearching || !searchQuery.trim()}
              className="bg-green-500 hover:bg-green-600"
            >
              {isSearching ? (
                <div className="flex items-center">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Searching...
                </div>
              ) : (
                <>
                  <Search className="w-4 h-4 mr-2" />
                  Ask AI
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* AI Search Results */}
      {searchResults.length > 0 && (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Lightbulb className="w-5 h-5 mr-2 text-yellow-400" />
              AI Response
            </CardTitle>
          </CardHeader>
          <CardContent>
            {searchResults.map((result) => (
              <div key={result.id} className="space-y-4">
                <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                  <h4 className="font-medium text-blue-300 mb-2">Your Question:</h4>
                  <p className="text-gray-300">{result.question}</p>
                </div>
                <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
                  <h4 className="font-medium text-green-300 mb-2 flex items-center">
                    <Bot className="w-4 h-4 mr-1" />
                    AI Answer:
                  </h4>
                  <div className="text-gray-300 whitespace-pre-line">{result.answer}</div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-gray-800/50 border-gray-700 hover:border-green-500/50 transition-colors cursor-pointer"
              onClick={() => navigate('/builder')}>
          <CardContent className="p-6 text-center">
            <Bot className="w-12 h-12 text-green-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-white mb-2">Start Building</h3>
            <p className="text-gray-400 text-sm">Create your first bot with our visual builder</p>
            <ArrowRight className="w-4 h-4 text-green-400 mx-auto mt-2" />
          </CardContent>
        </Card>

        <Card className="bg-gray-800/50 border-gray-700 hover:border-blue-500/50 transition-colors cursor-pointer"
              onClick={() => navigate('/docs')}>
          <CardContent className="p-6 text-center">
            <BookOpen className="w-12 h-12 text-blue-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-white mb-2">Documentation</h3>
            <p className="text-gray-400 text-sm">Detailed guides and tutorials</p>
            <ArrowRight className="w-4 h-4 text-blue-400 mx-auto mt-2" />
          </CardContent>
        </Card>

        <Card className="bg-gray-800/50 border-gray-700 hover:border-purple-500/50 transition-colors cursor-pointer"
              onClick={() => navigate('/tutorials')}>
          <CardContent className="p-6 text-center">
            <MessageSquare className="w-12 h-12 text-purple-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-white mb-2">Tutorials</h3>
            <p className="text-gray-400 text-sm">Video guides for common tasks</p>
            <ArrowRight className="w-4 h-4 text-purple-400 mx-auto mt-2" />
          </CardContent>
        </Card>
      </div>

      {/* Categories */}
      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <Button
            key={category}
            variant={selectedCategory === category ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedCategory(category)}
            className={selectedCategory === category 
              ? "bg-green-500 hover:bg-green-600" 
              : "border-gray-600 text-gray-300 hover:text-green-400"
            }
          >
            {category}
          </Button>
        ))}
      </div>

      {/* FAQ Section */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <HelpCircle className="w-5 h-5 mr-2 text-green-400" />
            Frequently Asked Questions
          </CardTitle>
          <CardDescription>
            Common questions about BOTultima
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="space-y-2">
            {filteredFAQs.map((faq) => (
              <AccordionItem key={faq.id} value={faq.id} className="border-gray-700">
                <AccordionTrigger className="text-white hover:text-green-400">
                  <div className="flex items-center justify-between w-full pr-4">
                    <span className="text-left">{faq.question}</span>
                    <Badge variant="outline" className="text-gray-400 border-gray-600">
                      {faq.category}
                    </Badge>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="text-gray-300">
                  <div className="space-y-4">
                    <p>{faq.answer}</p>
                    <div className="flex items-center justify-between pt-2 border-t border-gray-700">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => markAsHelpful(faq.id)}
                        className="text-gray-400 hover:text-green-400"
                      >
                        <Star className="w-4 h-4 mr-1" />
                        Helpful ({faq.helpful})
                      </Button>
                      <span className="text-xs text-gray-500">{faq.category}</span>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          {filteredFAQs.length === 0 && (
            <div className="text-center py-8">
              <HelpCircle className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400">No FAQs found matching your search.</p>
              <p className="text-gray-500 text-sm mt-2">Try the AI search above for personalized help.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Contact Support */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Still Need Help?</CardTitle>
          <CardDescription>
            Our support team is here to help you succeed
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
              <h4 className="font-medium text-green-300 mb-2">Email Support</h4>
              <p className="text-gray-400 text-sm mb-3">Get detailed help via email</p>
              <p className="text-green-400 text-sm">shakibking104@gmail.com</p>
            </div>
            <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
              <h4 className="font-medium text-blue-300 mb-2">AI Assistant</h4>
              <p className="text-gray-400 text-sm mb-3">Chat with our AI assistant</p>
              <p className="text-blue-400 text-sm">Available 24/7 in bottom-right corner</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default HelpCenter;

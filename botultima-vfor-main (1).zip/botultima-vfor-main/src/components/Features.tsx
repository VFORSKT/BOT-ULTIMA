import { Bot, Zap, Brain, Rocket, Globe, Users, Lock, Sparkles } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
const Features = () => {
  const features = [{
    icon: <Bot className="h-8 w-8" />,
    title: "Visual Bot Builder",
    description: "Drag, drop, and connect blocks to create complex automation flows. No coding required.",
    color: "text-green-400"
  }, {
    icon: <Brain className="h-8 w-8" />,
    title: "AI Agent Studio",
    description: "Create intelligent agents that can perform complex tasks and make decisions autonomously.",
    color: "text-blue-400"
  }, {
    icon: <Zap className="h-8 w-8" />,
    title: "One-Click Deployment",
    description: "Deploy your bots instantly to Telegram, Discord, WhatsApp, and more with a single click.",
    color: "text-yellow-400"
  }, {
    icon: <Sparkles className="h-8 w-8" />,
    title: "Multi-Model AI",
    description: "Powered by GPT-4, Mixtral, and DeepSeek with automatic fallback and cost optimization.",
    color: "text-purple-400"
  }, {
    icon: <Globe className="h-8 w-8" />,
    title: "Global Marketplace",
    description: "Share your bots with the community or monetize your creations in our marketplace.",
    color: "text-emerald-400"
  }, {
    icon: <Users className="h-8 w-8" />,
    title: "Team Collaboration",
    description: "Work together with your team on bot projects with real-time collaboration features.",
    color: "text-orange-400"
  }];
  return <section id="features" className="py-24 px-4 relative">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-green-400 to-emerald-300 bg-clip-text text-transparent">
            Everything You Need to Build AI Bots
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">From simple chatbots to complex AI agents, SixMorph provides all the tools you need to bring your automation ideas to life.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => <Card key={index} className="bg-gray-900/50 border-gray-800/50 hover:border-green-500/30 transition-all duration-300 hover:shadow-2xl hover:shadow-green-500/10 group cursor-pointer transform hover:scale-105">
              <CardHeader>
                <div className={`${feature.color} mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  {feature.icon}
                </div>
                <CardTitle className="text-white group-hover:text-green-400 transition-colors duration-300">
                  {feature.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-400">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>)}
        </div>

        {/* How It Works Section */}
        <div className="mt-24">
          <div className="text-center mb-16">
            <h3 className="text-3xl md:text-4xl font-bold mb-6 text-white">
              How BOTultima Works
            </h3>
            <p className="text-lg text-gray-400 max-w-2xl mx-auto">
              From idea to deployment in three simple steps
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center group">
              <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <span className="text-2xl font-bold text-white">1</span>
              </div>
              <h4 className="text-xl font-semibold text-white mb-4">Describe Your Idea</h4>
              <p className="text-gray-400">
                Simply describe what you want your bot to do. Our AI understands natural language and converts your ideas into visual flows.
              </p>
            </div>

            <div className="text-center group">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <span className="text-2xl font-bold text-white">2</span>
              </div>
              <h4 className="text-xl font-semibold text-white mb-4">Customize & Test</h4>
              <p className="text-gray-400">
                Use our visual editor to fine-tune your bot's behavior. Test everything in real-time with our sandbox environment.
              </p>
            </div>

            <div className="text-center group">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <span className="text-2xl font-bold text-white">3</span>
              </div>
              <h4 className="text-xl font-semibold text-white mb-4">Deploy Instantly</h4>
              <p className="text-gray-400">
                One click deploys your bot to any platform. Monitor performance and iterate based on real user interactions.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default Features;
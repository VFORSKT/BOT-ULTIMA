
import { useEffect, useRef } from 'react';
import { Bot } from 'lucide-react';

const RobotWelcome = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Animated 3D-style robots
    const robots = [
      {
        x: canvas.width * 0.25,
        y: canvas.height * 0.5,
        size: 100,
        rotation: 0,
        bobOffset: 0,
        glowIntensity: 0.5
      },
      {
        x: canvas.width * 0.75,
        y: canvas.height * 0.5,
        size: 120,
        rotation: 0,
        bobOffset: Math.PI,
        glowIntensity: 0.8
      }
    ];

    const drawRobot = (robot: any, time: number) => {
      const { x, y, size, rotation, bobOffset, glowIntensity } = robot;
      
      // Calculate bob animation
      const bobY = y + Math.sin(time * 0.003 + bobOffset) * 15;
      
      ctx.save();
      ctx.translate(x, bobY);
      ctx.rotate(rotation + Math.sin(time * 0.002) * 0.1);

      // Robot glow effect
      const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, size);
      gradient.addColorStop(0, `rgba(34, 197, 94, ${glowIntensity})`);
      gradient.addColorStop(0.5, `rgba(34, 197, 94, ${glowIntensity * 0.5})`);
      gradient.addColorStop(1, 'rgba(34, 197, 94, 0)');
      
      ctx.fillStyle = gradient;
      ctx.fillRect(-size, -size, size * 2, size * 2);

      // Robot body (main chassis)
      ctx.fillStyle = '#1f2937';
      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 3;
      ctx.fillRect(-size * 0.4, -size * 0.5, size * 0.8, size);
      ctx.strokeRect(-size * 0.4, -size * 0.5, size * 0.8, size);

      // Robot head
      ctx.fillStyle = '#374151';
      ctx.fillRect(-size * 0.3, -size * 0.8, size * 0.6, size * 0.4);
      ctx.strokeRect(-size * 0.3, -size * 0.8, size * 0.6, size * 0.4);

      // Robot eyes (glowing)
      const eyeGlow = Math.sin(time * 0.01) * 0.5 + 0.5;
      ctx.fillStyle = `rgba(34, 197, 94, ${eyeGlow})`;
      ctx.fillRect(-size * 0.2, -size * 0.7, size * 0.1, size * 0.1);
      ctx.fillRect(size * 0.1, -size * 0.7, size * 0.1, size * 0.1);

      // Robot arms
      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 8;
      ctx.lineCap = 'round';
      
      // Left arm
      ctx.beginPath();
      ctx.moveTo(-size * 0.4, -size * 0.2);
      ctx.lineTo(-size * 0.7, -size * 0.1 + Math.sin(time * 0.004) * 10);
      ctx.stroke();

      // Right arm
      ctx.beginPath();
      ctx.moveTo(size * 0.4, -size * 0.2);
      ctx.lineTo(size * 0.7, -size * 0.1 + Math.cos(time * 0.004) * 10);
      ctx.stroke();

      // Robot legs
      ctx.beginPath();
      ctx.moveTo(-size * 0.2, size * 0.5);
      ctx.lineTo(-size * 0.2, size * 0.8);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(size * 0.2, size * 0.5);
      ctx.lineTo(size * 0.2, size * 0.8);
      ctx.stroke();

      // Chest details
      ctx.fillStyle = '#22c55e';
      ctx.fillRect(-size * 0.1, -size * 0.2, size * 0.2, size * 0.1);
      
      ctx.restore();
    };

    const animate = (time: number) => {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      robots.forEach(robot => drawRobot(robot, time));

      requestAnimationFrame(animate);
    };

    animate(0);

    return () => {
      window.removeEventListener('resize', resizeCanvas);
    };
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-40">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
      />
      
      {/* Welcome Message */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center animate-fade-in">
          <div className="mb-8">
            <h1 className="text-6xl font-bold text-green-400 mb-4 animate-pulse">
              HELLO SIR!
            </h1>
            <p className="text-2xl text-white mb-6">
              Welcome to the future of AI automation
            </p>
            <div className="flex items-center justify-center space-x-4 text-xl text-green-300">
              <Bot className="h-8 w-8" />
              <span>Create Your Bot and AI Agent With Us</span>
              <Bot className="h-8 w-8" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RobotWelcome;

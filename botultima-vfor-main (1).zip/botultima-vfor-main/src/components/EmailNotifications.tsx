
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { 
  Mail, 
  Bell, 
  CheckCircle, 
  AlertCircle, 
  Info,
  Settings,
  Clock
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface EmailLog {
  id: string;
  email_type: string;
  recipient_email: string;
  subject: string;
  status: string;
  sent_at: string;
}

interface NotificationSettings {
  bot_status_updates: boolean;
  weekly_reports: boolean;
  security_alerts: boolean;
  feature_announcements: boolean;
  billing_notifications: boolean;
}

const EmailNotifications = () => {
  const [emailLogs, setEmailLogs] = useState<EmailLog[]>([]);
  const [settings, setSettings] = useState<NotificationSettings>({
    bot_status_updates: true,
    weekly_reports: true,
    security_alerts: true,
    feature_announcements: false,
    billing_notifications: true
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadEmailLogs();
  }, []);

  const loadEmailLogs = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: logs } = await supabase
        .from('emails')
        .select('*')
        .eq('user_id', user.id)
        .order('sent_at', { ascending: false })
        .limit(20);

      if (logs) {
        setEmailLogs(logs);
      }
    } catch (error) {
      console.error('Error loading email logs:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSettingChange = (setting: keyof NotificationSettings, value: boolean) => {
    setSettings(prev => ({ ...prev, [setting]: value }));
    // In a real app, this would save to the database
  };

  const getEmailIcon = (type: string) => {
    switch (type) {
      case 'welcome':
        return <Mail className="h-4 w-4 text-blue-400" />;
      case 'alert':
        return <AlertCircle className="h-4 w-4 text-red-400" />;
      case 'notification':
        return <Bell className="h-4 w-4 text-yellow-400" />;
      case 'report':
        return <Info className="h-4 w-4 text-green-400" />;
      default:
        return <Mail className="h-4 w-4 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'sent':
        return (
          <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
            <CheckCircle className="h-3 w-3 mr-1" />
            Sent
          </Badge>
        );
      case 'failed':
        return (
          <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
            <AlertCircle className="h-3 w-3 mr-1" />
            Failed
          </Badge>
        );
      case 'pending':
        return (
          <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
            <Clock className="h-3 w-3 mr-1" />
            Pending
          </Badge>
        );
      default:
        return (
          <Badge className="bg-gray-500/20 text-gray-400 border-gray-500/30">
            {status}
          </Badge>
        );
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-white mb-2">Email Notifications</h2>
        <p className="text-gray-400">Manage your email preferences and view notification history</p>
      </div>

      {/* Notification Settings */}
      <Card className="bg-gray-900/50 border-gray-800/50">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Settings className="h-5 w-5 mr-2 text-green-400" />
            Notification Preferences
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-white">Bot Status Updates</h3>
                  <p className="text-sm text-gray-400">Get notified when your bots go online/offline</p>
                </div>
                <Switch
                  checked={settings.bot_status_updates}
                  onCheckedChange={(value) => handleSettingChange('bot_status_updates', value)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-white">Weekly Reports</h3>
                  <p className="text-sm text-gray-400">Receive weekly analytics and performance reports</p>
                </div>
                <Switch
                  checked={settings.weekly_reports}
                  onCheckedChange={(value) => handleSettingChange('weekly_reports', value)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-white">Security Alerts</h3>
                  <p className="text-sm text-gray-400">Important security notifications and warnings</p>
                </div>
                <Switch
                  checked={settings.security_alerts}
                  onCheckedChange={(value) => handleSettingChange('security_alerts', value)}
                />
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-white">Feature Announcements</h3>
                  <p className="text-sm text-gray-400">Updates about new features and improvements</p>
                </div>
                <Switch
                  checked={settings.feature_announcements}
                  onCheckedChange={(value) => handleSettingChange('feature_announcements', value)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-white">Billing Notifications</h3>
                  <p className="text-sm text-gray-400">Payment confirmations and billing reminders</p>
                </div>
                <Switch
                  checked={settings.billing_notifications}
                  onCheckedChange={(value) => handleSettingChange('billing_notifications', value)}
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-gray-700">
            <Button className="bg-green-600 hover:bg-green-700">
              Save Preferences
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Email History */}
      <Card className="bg-gray-900/50 border-gray-800/50">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Mail className="h-5 w-5 mr-2 text-blue-400" />
            Email History
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="animate-pulse flex items-center space-x-4 p-4 bg-gray-800/30 rounded-lg">
                  <div className="w-8 h-8 bg-gray-700 rounded-full"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-gray-700 rounded w-1/4"></div>
                    <div className="h-3 bg-gray-700 rounded w-3/4"></div>
                  </div>
                  <div className="w-16 h-6 bg-gray-700 rounded"></div>
                </div>
              ))}
            </div>
          ) : emailLogs.length > 0 ? (
            <div className="space-y-4">
              {emailLogs.map((log) => (
                <div key={log.id} className="flex items-center justify-between p-4 bg-gray-800/30 rounded-lg border border-gray-700/30">
                  <div className="flex items-center space-x-4">
                    {getEmailIcon(log.email_type)}
                    <div>
                      <h3 className="font-medium text-white">{log.subject || 'No Subject'}</h3>
                      <p className="text-sm text-gray-400">
                        To: {log.recipient_email} • {new Date(log.sent_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <Badge variant="outline" className="border-gray-600 text-gray-400">
                      {log.email_type}
                    </Badge>
                    {getStatusBadge(log.status)}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Mail className="h-12 w-12 text-gray-600 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-400 mb-2">No email history</h3>
              <p className="text-gray-500">Your email notifications will appear here</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default EmailNotifications;


import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Zap, 
  TrendingUp, 
  Calendar, 
  AlertTriangle,
  Plus,
  BarChart3
} from "lucide-react";

const TokenUsageDashboard = () => {
  const currentUsage = 8500;
  const totalTokens = 20000;
  const usagePercentage = (currentUsage / totalTokens) * 100;

  const dailyUsage = [
    { day: "Mon", tokens: 1200 },
    { day: "Tue", tokens: 890 },
    { day: "Wed", tokens: 1450 },
    { day: "Thu", tokens: 980 },
    { day: "Fri", tokens: 1680 },
    { day: "Sat", tokens: 760 },
    { day: "Sun", tokens: 540 },
  ];

  const maxDailyUsage = Math.max(...dailyUsage.map(d => d.tokens));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Token Usage</h2>
          <p className="text-gray-400">Monitor your AI token consumption</p>
        </div>
        <Button className="bg-green-600 hover:bg-green-700">
          <Plus className="h-4 w-4 mr-2" />
          Buy More Tokens
        </Button>
      </div>

      {/* Usage Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Current Usage Card */}
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Zap className="h-5 w-5 mr-2 text-green-400" />
              Current Usage
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-white mb-2">
                {currentUsage.toLocaleString()}
              </div>
              <div className="text-gray-400">
                of {totalTokens.toLocaleString()} tokens
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Usage</span>
                <span className="text-white">{usagePercentage.toFixed(1)}%</span>
              </div>
              <Progress 
                value={usagePercentage} 
                className="h-3"
              />
            </div>

            <div className="flex items-center justify-center space-x-2">
              {usagePercentage > 80 ? (
                <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
                  <AlertTriangle className="h-3 w-3 mr-1" />
                  High Usage
                </Badge>
              ) : usagePercentage > 60 ? (
                <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  Moderate Usage
                </Badge>
              ) : (
                <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                  <Zap className="h-3 w-3 mr-1" />
                  Good Usage
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Progress Ring */}
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <BarChart3 className="h-5 w-5 mr-2 text-blue-400" />
              Usage Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent className="flex items-center justify-center">
            <div className="relative w-40 h-40">
              {/* SVG Progress Ring */}
              <svg className="w-40 h-40 -rotate-90" viewBox="0 0 160 160">
                {/* Background Circle */}
                <circle
                  cx="80"
                  cy="80"
                  r="70"
                  stroke="rgb(55, 65, 81)"
                  strokeWidth="10"
                  fill="none"
                />
                {/* Progress Circle */}
                <circle
                  cx="80"
                  cy="80"
                  r="70"
                  stroke="rgb(34, 197, 94)"
                  strokeWidth="10"
                  fill="none"
                  strokeDasharray={`${(usagePercentage / 100) * 440} 440`}
                  strokeLinecap="round"
                  className="transition-all duration-1000 ease-out"
                />
              </svg>
              {/* Center Text */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">
                    {usagePercentage.toFixed(0)}%
                  </div>
                  <div className="text-xs text-gray-400">Used</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Daily Usage Chart */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Calendar className="h-5 w-5 mr-2 text-purple-400" />
            Weekly Usage
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {dailyUsage.map((day, index) => (
              <div key={index} className="flex items-center space-x-4">
                <div className="w-12 text-sm text-gray-400 font-medium">
                  {day.day}
                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-3">
                    <div className="flex-1 bg-gray-700 rounded-full h-3 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-green-500 to-emerald-400 transition-all duration-700 ease-out"
                        style={{
                          width: `${(day.tokens / maxDailyUsage) * 100}%`
                        }}
                      />
                    </div>
                    <div className="w-16 text-sm text-white text-right">
                      {day.tokens.toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6 pt-4 border-t border-gray-700">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-lg font-bold text-white">7.5K</div>
                <div className="text-xs text-gray-400">This Week</div>
              </div>
              <div>
                <div className="text-lg font-bold text-white">1.2K</div>
                <div className="text-xs text-gray-400">Daily Avg</div>
              </div>
              <div>
                <div className="text-lg font-bold text-green-400">+15%</div>
                <div className="text-xs text-gray-400">vs Last Week</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TokenUsageDashboard;

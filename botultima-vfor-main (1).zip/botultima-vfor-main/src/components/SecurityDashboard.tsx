import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Shield, AlertTriangle, Eye, Clock, Lock, Activity } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface SecurityEvent {
  id: string;
  event_type: string;
  created_at: string;
  details: any;
  ip_address?: string | null;
  user_agent?: string;
}

const SecurityDashboard = () => {
  const [securityEvents, setSecurityEvents] = useState<SecurityEvent[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({
    totalEvents: 0,
    recentSignins: 0,
    failedAttempts: 0,
    keyGenerations: 0
  });
  const { toast } = useToast();

  useEffect(() => {
    loadSecurityData();
  }, []);

  const loadSecurityData = async () => {
    setIsLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Load security events for the current user
      const { data: events, error } = await supabase
        .from('security_audit_logs')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) {
        console.error('Error loading security events:', error);
        return;
      }

      // Transform the data to handle the ip_address type conversion
      const transformedEvents: SecurityEvent[] = (events || []).map(event => ({
        ...event,
        ip_address: event.ip_address ? String(event.ip_address) : null
      }));

      setSecurityEvents(transformedEvents);

      // Calculate statistics
      const now = new Date();
      const last24Hours = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      const recentEvents = transformedEvents.filter(
        event => new Date(event.created_at) > last24Hours
      );

      setStats({
        totalEvents: transformedEvents.length,
        recentSignins: recentEvents.filter(e => e.event_type === 'signin_success').length,
        failedAttempts: recentEvents.filter(e => e.event_type === 'signin_failed').length,
        keyGenerations: recentEvents.filter(e => e.event_type === 'sixmorph_key_generated').length
      });
    } catch (error) {
      console.error('Failed to load security data:', error);
      toast({
        title: "Error",
        description: "Failed to load security data",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getEventIcon = (eventType: string) => {
    switch (eventType) {
      case 'signin_success':
        return <Shield className="h-4 w-4 text-green-500" />;
      case 'signin_failed':
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case 'signup_success':
        return <Activity className="h-4 w-4 text-blue-500" />;
      case 'signout':
        return <Lock className="h-4 w-4 text-gray-500" />;
      case 'sixmorph_key_generated':
        return <Eye className="h-4 w-4 text-purple-500" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const getEventBadgeColor = (eventType: string) => {
    switch (eventType) {
      case 'signin_success':
      case 'signup_success':
        return 'bg-green-500/20 text-green-400';
      case 'signin_failed':
        return 'bg-red-500/20 text-red-400';
      case 'signout':
        return 'bg-gray-500/20 text-gray-400';
      case 'sixmorph_key_generated':
        return 'bg-purple-500/20 text-purple-400';
      default:
        return 'bg-blue-500/20 text-blue-400';
    }
  };

  const formatEventType = (eventType: string) => {
    return eventType.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin h-8 w-8 border-2 border-green-400 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Security Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Events</p>
                <p className="text-2xl font-bold text-white">{stats.totalEvents}</p>
              </div>
              <Activity className="h-8 w-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Recent Sign-ins</p>
                <p className="text-2xl font-bold text-green-400">{stats.recentSignins}</p>
              </div>
              <Shield className="h-8 w-8 text-green-400" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Failed Attempts</p>
                <p className="text-2xl font-bold text-red-400">{stats.failedAttempts}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-400" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Key Generations</p>
                <p className="text-2xl font-bold text-purple-400">{stats.keyGenerations}</p>
              </div>
              <Eye className="h-8 w-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Security Events Log */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white flex items-center">
              <Shield className="h-5 w-5 mr-2 text-green-400" />
              Security Activity Log
            </CardTitle>
            <Button
              onClick={loadSecurityData}
              variant="outline"
              size="sm"
              className="border-gray-600"
            >
              Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-96">
            {securityEvents.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No security events recorded yet.
              </div>
            ) : (
              <div className="space-y-3">
                {securityEvents.map((event) => (
                  <div
                    key={event.id}
                    className="flex items-center justify-between p-3 bg-gray-900/50 rounded-lg border border-gray-700"
                  >
                    <div className="flex items-center space-x-3">
                      {getEventIcon(event.event_type)}
                      <div>
                        <div className="text-white text-sm font-medium">
                          {formatEventType(event.event_type)}
                        </div>
                        <div className="text-gray-400 text-xs">
                          {new Date(event.created_at).toLocaleString()}
                        </div>
                        {event.details && Object.keys(event.details).length > 0 && (
                          <div className="text-gray-500 text-xs mt-1">
                            {event.details.email && `Email: ${event.details.email}`}
                            {event.details.error && ` • Error: ${event.details.error}`}
                          </div>
                        )}
                      </div>
                    </div>
                    <Badge className={getEventBadgeColor(event.event_type)}>
                      {formatEventType(event.event_type)}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
};

export default SecurityDashboard;

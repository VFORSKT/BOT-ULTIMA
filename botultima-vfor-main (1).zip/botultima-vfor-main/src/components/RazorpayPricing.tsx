
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Check, 
  Crown, 
  Zap, 
  Rocket, 
  Star,
  Shield,
  Clock,
  Users,
  BarChart3
} from "lucide-react";

const RazorpayPricing = () => {
  const [billingCycle, setBillingCycle] = useState("monthly");

  const plans = [
    {
      name: "Starter",
      price: billingCycle === "monthly" ? 999 : 9990,
      originalPrice: billingCycle === "monthly" ? null : 11988,
      description: "Perfect for individuals getting started",
      icon: <Zap className="h-6 w-6" />,
      color: "from-blue-500 to-cyan-500",
      features: [
        "5,000 AI tokens/month",
        "2 active bots",
        "Basic templates",
        "Email support",
        "API access",
        "Analytics dashboard"
      ],
      popular: false
    },
    {
      name: "Maker",
      price: billingCycle === "monthly" ? 2899 : 28990,
      originalPrice: billingCycle === "monthly" ? null : 34788,
      description: "Best for professionals and small teams",
      icon: <Crown className="h-6 w-6" />,
      color: "from-green-500 to-emerald-500",
      features: [
        "20,000 AI tokens/month",
        "5 active bots",
        "Advanced templates",
        "Priority support",
        "Custom integrations",
        "Advanced analytics",
        "Team collaboration",
        "White-label options"
      ],
      popular: true
    },
    {
      name: "Enterprise",
      price: billingCycle === "monthly" ? 9999 : 99990,
      originalPrice: billingCycle === "monthly" ? null : 119988,
      description: "For large organizations with custom needs",
      icon: <Rocket className="h-6 w-6" />,
      color: "from-purple-500 to-pink-500",
      features: [
        "100,000 AI tokens/month",
        "Unlimited bots",
        "Custom development",
        "24/7 phone support",
        "On-premise deployment",
        "Advanced security",
        "Custom reporting",
        "Dedicated account manager"
      ],
      popular: false
    }
  ];

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0
    }).format(price / 100);
  };

  const initiatePayment = async (plan) => {
    // Razorpay integration would go here
    console.log(`Initiating payment for ${plan.name} plan`);
    
    // Mock Razorpay options
    const options = {
      key: "rzp_test_your_key_here", // Replace with actual Razorpay key
      amount: plan.price,
      currency: "INR",
      name: "BOTultima",
      description: `${plan.name} Plan Subscription`,
      image: "/logo.png",
      handler: function (response) {
        console.log("Payment successful:", response);
        // Handle successful payment
      },
      prefill: {
        name: "John Doe",
        email: "john.doe@example.com",
        contact: "+919999999999"
      },
      theme: {
        color: "#22c55e"
      }
    };
    
    // In a real implementation, you would:
    // const rzp = new window.Razorpay(options);
    // rzp.open();
    
    alert(`Payment initiated for ${plan.name} plan - ${formatPrice(plan.price)}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900 text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-green-400 to-emerald-300 bg-clip-text text-transparent">
            Choose Your Plan
          </h1>
          <p className="text-xl text-gray-300 mb-8">
            Unlock the full potential of AI automation with our flexible pricing
          </p>
          
          {/* Billing Toggle */}
          <div className="flex items-center justify-center space-x-4 mb-8">
            <span className={`${billingCycle === 'monthly' ? 'text-white' : 'text-gray-400'}`}>
              Monthly
            </span>
            <button
              onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'yearly' : 'monthly')}
              className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-700 transition-colors focus:outline-none focus:ring-2 focus:ring-green-500"
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-green-500 transition-transform ${
                  billingCycle === 'yearly' ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
            <span className={`${billingCycle === 'yearly' ? 'text-white' : 'text-gray-400'}`}>
              Yearly
            </span>
            {billingCycle === 'yearly' && (
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30 ml-2">
                Save 20%
              </Badge>
            )}
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {plans.map((plan, index) => (
            <Card
              key={index}
              className={`relative bg-gray-800/50 border-gray-700 hover:border-gray-600 transition-all duration-300 ${
                plan.popular ? 'ring-2 ring-green-500/50 scale-105' : ''
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-green-500 text-white px-4 py-1">
                    <Star className="h-3 w-3 mr-1" />
                    Most Popular
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center pb-4">
                <div className={`w-16 h-16 mx-auto mb-4 bg-gradient-to-r ${plan.color} rounded-xl flex items-center justify-center`}>
                  {plan.icon}
                </div>
                <CardTitle className="text-2xl font-bold text-white">{plan.name}</CardTitle>
                <p className="text-gray-400">{plan.description}</p>
              </CardHeader>
              
              <CardContent className="pt-0">
                <div className="text-center mb-6">
                  <div className="flex items-center justify-center space-x-2">
                    <span className="text-4xl font-bold text-white">
                      {formatPrice(plan.price)}
                    </span>
                    <span className="text-gray-400">
                      /{billingCycle === 'monthly' ? 'month' : 'year'}
                    </span>
                  </div>
                  {plan.originalPrice && (
                    <div className="text-sm text-gray-500 line-through mt-1">
                      {formatPrice(plan.originalPrice)}
                    </div>
                  )}
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-gray-300">
                      <Check className="h-4 w-4 text-green-400 mr-3 flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  onClick={() => initiatePayment(plan)}
                  className={`w-full ${
                    plan.popular
                      ? 'bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700'
                      : 'bg-gray-700 hover:bg-gray-600'
                  } text-white font-semibold py-3 rounded-lg transition-all duration-300`}
                >
                  {plan.popular ? 'Start Free Trial' : 'Get Started'}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Features Comparison */}
        <Card className="bg-gray-800/50 border-gray-700 mb-12">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-white text-center">
              Compare All Features
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-700">
                    <th className="text-left py-4 text-gray-300">Features</th>
                    <th className="text-center py-4 text-gray-300">Starter</th>
                    <th className="text-center py-4 text-gray-300">Maker</th>
                    <th className="text-center py-4 text-gray-300">Enterprise</th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  {[
                    { feature: "AI Tokens/month", starter: "5,000", maker: "20,000", enterprise: "100,000" },
                    { feature: "Active Bots", starter: "2", maker: "5", enterprise: "Unlimited" },
                    { feature: "Team Members", starter: "1", maker: "5", enterprise: "Unlimited" },
                    { feature: "API Access", starter: "✓", maker: "✓", enterprise: "✓" },
                    { feature: "Custom Integrations", starter: "✗", maker: "✓", enterprise: "✓" },
                    { feature: "Priority Support", starter: "✗", maker: "✓", enterprise: "✓" },
                    { feature: "White-label", starter: "✗", maker: "✓", enterprise: "✓" },
                    { feature: "On-premise Deployment", starter: "✗", maker: "✗", enterprise: "✓" },
                  ].map((row, index) => (
                    <tr key={index} className="border-b border-gray-700/50">
                      <td className="py-4 text-white font-medium">{row.feature}</td>
                      <td className="py-4 text-center text-gray-300">{row.starter}</td>
                      <td className="py-4 text-center text-gray-300">{row.maker}</td>
                      <td className="py-4 text-center text-gray-300">{row.enterprise}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Trust Indicators */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <div className="text-center p-6 bg-gray-800/30 rounded-lg border border-gray-700">
            <Shield className="h-8 w-8 text-green-400 mx-auto mb-3" />
            <h3 className="font-semibold text-white mb-2">Secure Payments</h3>
            <p className="text-sm text-gray-400">256-bit SSL encryption</p>
          </div>
          <div className="text-center p-6 bg-gray-800/30 rounded-lg border border-gray-700">
            <Clock className="h-8 w-8 text-blue-400 mx-auto mb-3" />
            <h3 className="font-semibold text-white mb-2">14-day Trial</h3>
            <p className="text-sm text-gray-400">No commitment required</p>
          </div>
          <div className="text-center p-6 bg-gray-800/30 rounded-lg border border-gray-700">
            <Users className="h-8 w-8 text-purple-400 mx-auto mb-3" />
            <h3 className="font-semibold text-white mb-2">10K+ Users</h3>
            <p className="text-sm text-gray-400">Trusted by professionals</p>
          </div>
          <div className="text-center p-6 bg-gray-800/30 rounded-lg border border-gray-700">
            <BarChart3 className="h-8 w-8 text-orange-400 mx-auto mb-3" />
            <h3 className="font-semibold text-white mb-2">99.9% Uptime</h3>
            <p className="text-sm text-gray-400">Enterprise-grade reliability</p>
          </div>
        </div>

        {/* FAQ Section */}
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-white text-center">
              Frequently Asked Questions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {[
              {
                question: "How does the billing work?",
                answer: "You're billed monthly or yearly based on your selected plan. You can upgrade, downgrade, or cancel anytime."
              },
              {
                question: "What payment methods do you accept?",
                answer: "We accept all major credit cards, debit cards, UPI, and net banking through Razorpay's secure payment gateway."
              },
              {
                question: "Can I cancel my subscription anytime?",
                answer: "Yes, you can cancel your subscription anytime. You'll continue to have access until the end of your billing period."
              },
              {
                question: "Do you offer refunds?",
                answer: "We offer a 14-day money-back guarantee for all new subscriptions. No questions asked."
              }
            ].map((faq, index) => (
              <div key={index}>
                <h4 className="font-semibold text-white mb-2">{faq.question}</h4>
                <p className="text-gray-400">{faq.answer}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default RazorpayPricing;

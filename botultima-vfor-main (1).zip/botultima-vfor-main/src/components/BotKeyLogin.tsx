
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Key, Zap, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

interface BotKeyLoginProps {
  onClose: () => void;
}

const BotKeyLogin = ({ onClose }: BotKeyLoginProps) => {
  const [sixMorphKey, setSixMorphKey] = useState("");
  const [isVerifying, setIsVerifying] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSixMorphKeyLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsVerifying(true);

    try {
      // Verify the SixMorph Key against the database
      const { data: keyData, error: keyError } = await supabase
        .from('sixmorph_keys')
        .select('user_id, is_active, last_used_at, usage_count')
        .eq('key_value', sixMorphKey)
        .eq('is_active', true)
        .single();

      if (keyError || !keyData) {
        throw new Error("Invalid SixMorph Key");
      }

      // Update key usage statistics
      const { error: updateError } = await supabase
        .from('sixmorph_keys')
        .update({
          last_used_at: new Date().toISOString(),
          usage_count: (keyData.usage_count || 0) + 1
        })
        .eq('key_value', sixMorphKey);

      if (updateError) {
        console.error('Error updating key usage:', updateError);
      }

      // Get current login count first, then update it
      const { data: currentProfile } = await supabase
        .from('profiles')
        .select('login_count')
        .eq('id', keyData.user_id)
        .single();

      // Update user's last login with incremented login count
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          last_login_at: new Date().toISOString(),
          login_count: (currentProfile?.login_count || 0) + 1
        })
        .eq('id', keyData.user_id);

      if (profileError) {
        console.error('Error updating profile:', profileError);
      }

      toast({
        title: "Welcome back!",
        description: "SixMorph Key verified successfully",
      });
      
      // Store the session info
      localStorage.setItem("sixMorphSession", sixMorphKey);
      localStorage.setItem("sixMorphUserId", keyData.user_id);
      
      navigate("/dashboard");
      onClose();
      
    } catch (error) {
      console.error('SixMorph Key login error:', error);
      toast({
        title: "Invalid Key",
        description: "Please check your SixMorph Key and try again",
        variant: "destructive",
      });
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <Card className="bg-gray-800/95 border-green-500/30 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Key className="h-5 w-5 mr-2 text-green-400" />
          SixMorph Key Login
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSixMorphKeyLogin} className="space-y-4">
          <div>
            <Label htmlFor="sixMorphKey" className="text-gray-300">Enter your SixMorph Key</Label>
            <Input
              id="sixMorphKey"
              type="text"
              value={sixMorphKey}
              onChange={(e) => setSixMorphKey(e.target.value)}
              className="bg-gray-700 border-gray-600 text-white font-mono"
              placeholder="SM_XXXXXXXX_XXXXXXXX_XXXXXXXX"
              required
            />
          </div>
          
          <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3">
            <div className="flex items-start space-x-2">
              <AlertCircle className="h-4 w-4 text-blue-400 mt-0.5" />
              <div className="text-blue-400 text-sm">
                <p className="font-medium">Quick Access</p>
                <p>Use your unique SixMorph Key for instant access to your projects and bots.</p>
              </div>
            </div>
          </div>

          <div className="flex space-x-3">
            <Button
              type="submit"
              disabled={isVerifying || !sixMorphKey}
              className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
            >
              <Zap className="h-4 w-4 mr-2" />
              {isVerifying ? "Verifying..." : "Access Dashboard"}
            </Button>
            <Button
              type="button"
              onClick={onClose}
              variant="outline"
              className="border-gray-600 hover:bg-gray-700"
            >
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default BotKeyLogin;

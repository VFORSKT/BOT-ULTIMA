import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Crown, Check, Zap, Star } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './AuthenticationManager';
import { useToast } from '@/hooks/use-toast';

interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  currency: string;
  interval_type: string;
  features: string[];
  is_active: boolean;
}

interface UserSubscription {
  id: string;
  plan_id: string;
  status: string;
  current_period_end: string;
  plan_name: string;
  features: string[];
}

const SubscriptionManager = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [currentSubscription, setCurrentSubscription] = useState<UserSubscription | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadPlansAndSubscription();
    }
  }, [user]);

  const loadPlansAndSubscription = async () => {
    try {
      // Load subscription plans
      const { data: plansData, error: plansError } = await supabase
        .from('subscription_plans')
        .select('*')
        .eq('is_active', true)
        .order('price', { ascending: true });

      if (plansError) throw plansError;

      // Transform plans data to match interface
      const transformedPlans: SubscriptionPlan[] = (plansData || []).map(plan => ({
        ...plan,
        features: Array.isArray(plan.features) ? plan.features.filter((feature): feature is string => typeof feature === 'string') : []
      }));

      // Load user's current subscription
      const { data: subscriptionData, error: subscriptionError } = await supabase
        .rpc('get_user_subscription_status', { p_user_id: user?.id });

      if (subscriptionError && subscriptionError.code !== 'PGRST116') {
        throw subscriptionError;
      }

      setPlans(transformedPlans);
      
      // Transform subscription data if it exists
      if (subscriptionData?.[0]) {
        const rawSubscription = subscriptionData[0];
        const transformedSubscription: UserSubscription = {
          id: '', // This will be populated from user_subscriptions table if needed
          plan_id: '', // This will be populated from user_subscriptions table if needed
          status: rawSubscription.status,
          current_period_end: rawSubscription.expires_at,
          plan_name: rawSubscription.plan_name,
          features: Array.isArray(rawSubscription.features) ? rawSubscription.features.filter((feature): feature is string => typeof feature === 'string') : []
        };
        setCurrentSubscription(transformedSubscription);
      } else {
        setCurrentSubscription(null);
      }
    } catch (error) {
      console.error('Error loading subscription data:', error);
      toast({
        title: "Error",
        description: "Failed to load subscription information",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubscribe = async (planId: string) => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to subscribe to a plan.",
        variant: "destructive",
      });
      return;
    }

    try {
      // Create a purchase record
      const { error: purchaseError } = await supabase
        .from('purchases')
        .insert({
          user_id: user.id,
          item_type: 'subscription',
          item_id: planId,
          amount: plans.find(p => p.id === planId)?.price || 0,
          status: 'completed'
        });

      if (purchaseError) throw purchaseError;

      // Create or update user subscription
      const { error: subscriptionError } = await supabase
        .from('user_subscriptions')
        .upsert({
          user_id: user.id,
          plan_id: planId,
          status: 'active',
          current_period_start: new Date().toISOString(),
          current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
        });

      if (subscriptionError) throw subscriptionError;

      toast({
        title: "Subscription Updated",
        description: "Your subscription has been updated successfully!",
      });

      loadPlansAndSubscription();
    } catch (error) {
      console.error('Subscription error:', error);
      toast({
        title: "Subscription Failed",
        description: "Failed to update your subscription. Please try again.",
        variant: "destructive",
      });
    }
  };

  const getPlanIcon = (planName: string) => {
    switch (planName.toLowerCase()) {
      case 'free': return <Zap className="h-6 w-6" />;
      case 'pro': return <Star className="h-6 w-6" />;
      case 'premium': return <Crown className="h-6 w-6" />;
      default: return <Zap className="h-6 w-6" />;
    }
  };

  const getPlanColor = (planName: string) => {
    switch (planName.toLowerCase()) {
      case 'free': return 'border-gray-600';
      case 'pro': return 'border-blue-500';
      case 'premium': return 'border-purple-500';
      default: return 'border-gray-600';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin h-8 w-8 border-2 border-green-400 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Current Subscription Status */}
      {currentSubscription && (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Crown className="h-5 w-5 mr-2 text-green-400" />
              Current Plan: {currentSubscription.plan_name}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-4">
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                {currentSubscription.status}
              </Badge>
              {currentSubscription.current_period_end && (
                <span className="text-gray-400 text-sm">
                  Expires: {new Date(currentSubscription.current_period_end).toLocaleDateString()}
                </span>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Subscription Plans */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan) => {
          const isCurrentPlan = currentSubscription?.plan_name === plan.name;
          
          return (
            <Card
              key={plan.id}
              className={`bg-gray-800/50 ${getPlanColor(plan.name)} transition-all duration-300 hover:scale-105 ${
                isCurrentPlan ? 'ring-2 ring-green-500' : ''
              }`}
            >
              <CardHeader className="text-center">
                <div className="flex items-center justify-center mb-4">
                  <div className={`p-3 rounded-full ${
                    plan.name.toLowerCase() === 'free' ? 'bg-gray-500/20' :
                    plan.name.toLowerCase() === 'pro' ? 'bg-blue-500/20' : 'bg-purple-500/20'
                  }`}>
                    {getPlanIcon(plan.name)}
                  </div>
                </div>
                <CardTitle className="text-white text-2xl">{plan.name}</CardTitle>
                <div className="text-3xl font-bold text-white">
                  ${plan.price}
                  <span className="text-gray-400 text-base font-normal">/{plan.interval_type}</span>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {plan.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Check className="h-4 w-4 text-green-400" />
                      <span className="text-gray-300 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
                
                <Button
                  onClick={() => handleSubscribe(plan.id)}
                  disabled={isCurrentPlan}
                  className={`w-full ${
                    isCurrentPlan 
                      ? 'bg-gray-600 text-gray-400 cursor-not-allowed' 
                      : plan.name.toLowerCase() === 'free'
                        ? 'bg-gray-600 hover:bg-gray-700'
                        : plan.name.toLowerCase() === 'pro'
                          ? 'bg-blue-600 hover:bg-blue-700'
                          : 'bg-purple-600 hover:bg-purple-700'
                  }`}
                >
                  {isCurrentPlan ? 'Current Plan' : `Subscribe to ${plan.name}`}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

export default SubscriptionManager;

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { User, MapPin, Briefcase, Building, Phone, Mail, Globe, Save, Plus, X, Camera } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useHybridAuth } from './HybridAuth';
import { useToast } from '@/hooks/use-toast';

interface ProfileData {
  id: string;
  username: string;
  email: string;
  bio: string;
  avatar_url: string;
  company_name: string;
  job_title: string;
  phone: string;
  location: string;
  website_url: string;
  github_url: string;
  twitter_url: string;
  skills: string[];
  social_links: Record<string, string>;
}

const ProfileBuilder = () => {
  const { user, isAuthenticated } = useHybridAuth();
  const { toast } = useToast();
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [newSkill, setNewSkill] = useState('');

  useEffect(() => {
    if (user && isAuthenticated) {
      loadProfile();
    }
  }, [user, isAuthenticated]);

  const loadProfile = async () => {
    try {
      const userId = user?.id;
      if (!userId) return;

      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setProfile({
          ...data,
          skills: Array.isArray(data.skills) ? data.skills.filter((skill): skill is string => typeof skill === 'string') : [],
          social_links: typeof data.social_links === 'object' && data.social_links !== null ? data.social_links as Record<string, string> : {}
        });
      } else {
        // Create initial profile for new users
        const userEmail = user?.email || user?.primaryEmailAddress?.emailAddress || '';
        const initialProfile = {
          id: userId,
          username: user?.firstName || user?.fullName || userEmail.split('@')[0] || 'User',
          email: userEmail,
          bio: '',
          avatar_url: user?.imageUrl || '',
          company_name: '',
          job_title: '',
          phone: '',
          location: '',
          website_url: '',
          github_url: '',
          twitter_url: '',
          skills: [],
          social_links: {}
        };
        setProfile(initialProfile);
        
        // Save initial profile to database
        const { error: insertError } = await supabase
          .from('profiles')
          .insert({
            id: userId,
            username: initialProfile.username,
            email: initialProfile.email,
            avatar_url: initialProfile.avatar_url,
            plan: 'free',
            role: 'user'
          });
          
        if (insertError) {
          console.error('Error creating initial profile:', insertError);
        }
      }
    } catch (error) {
      console.error('Error loading profile:', error);
      toast({
        title: "Error",
        description: "Failed to load profile data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!profile || !user) return;

    setSaving(true);
    try {
      const updateData = {
        username: profile.username,
        bio: profile.bio,
        avatar_url: profile.avatar_url,
        company_name: profile.company_name,
        job_title: profile.job_title,
        phone: profile.phone,
        location: profile.location,
        website_url: profile.website_url,
        github_url: profile.github_url,
        twitter_url: profile.twitter_url,
        skills: profile.skills,
        social_links: profile.social_links
      };

      const { error } = await supabase
        .from('profiles')
        .update(updateData)
        .eq('id', user.id);

      if (error) {
        throw error;
      }

      toast({
        title: "Profile Updated",
        description: "Your profile has been saved successfully.",
      });
    } catch (error) {
      console.error('Error saving profile:', error);
      toast({
        title: "Save Failed",
        description: "Failed to save profile. Please try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleAddSkill = () => {
    if (newSkill.trim() && profile && !profile.skills.includes(newSkill.trim())) {
      setProfile({
        ...profile,
        skills: [...profile.skills, newSkill.trim()]
      });
      setNewSkill('');
    }
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    if (profile) {
      setProfile({
        ...profile,
        skills: profile.skills.filter(skill => skill !== skillToRemove)
      });
    }
  };

  const updateField = (field: keyof ProfileData, value: any) => {
    if (profile) {
      setProfile({ ...profile, [field]: value });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin h-8 w-8 border-2 border-green-400 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="text-center p-8">
        <p className="text-gray-400">Failed to load profile data</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Profile Builder</h2>
          <p className="text-gray-400">Customize your professional profile</p>
        </div>
        <Button 
          onClick={handleSave} 
          disabled={saving}
          className="bg-green-600 hover:bg-green-700"
        >
          <Save className="h-4 w-4 mr-2" />
          {saving ? 'Saving...' : 'Save Profile'}
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Preview */}
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Profile Preview</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <div className="relative inline-block">
                <Avatar className="w-20 h-20 mx-auto mb-4">
                  <AvatarImage src={profile.avatar_url} />
                  <AvatarFallback className="bg-green-600 text-white text-xl">
                    {profile.username?.charAt(0)?.toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
                <Button
                  size="sm"
                  className="absolute bottom-3 right-0 rounded-full w-8 h-8 p-0 bg-green-600 hover:bg-green-700"
                >
                  <Camera className="h-4 w-4" />
                </Button>
              </div>
              <h3 className="text-lg font-semibold text-white">{profile.username}</h3>
              {profile.job_title && (
                <p className="text-gray-400">{profile.job_title}</p>
              )}
              {profile.company_name && (
                <p className="text-gray-500 text-sm">{profile.company_name}</p>
              )}
            </div>
            
            {profile.bio && (
              <p className="text-gray-300 text-sm text-center">{profile.bio}</p>
            )}
            
            {profile.skills.length > 0 && (
              <div>
                <p className="text-sm font-medium text-gray-400 mb-2">Skills</p>
                <div className="flex flex-wrap gap-2">
                  {profile.skills.slice(0, 5).map((skill, index) => (
                    <Badge key={index} className="bg-green-500/20 text-green-400 border-green-500/30">
                      {skill}
                    </Badge>
                  ))}
                  {profile.skills.length > 5 && (
                    <Badge className="bg-gray-500/20 text-gray-400">
                      +{profile.skills.length - 5} more
                    </Badge>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Profile Form */}
        <div className="lg:col-span-2 space-y-6">
          {/* Basic Information */}
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <User className="h-5 w-5 mr-2" />
                Basic Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Username
                  </label>
                  <Input
                    value={profile.username}
                    onChange={(e) => updateField('username', e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white"
                    placeholder="Your username"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Email
                  </label>
                  <Input
                    value={profile.email}
                    onChange={(e) => updateField('email', e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white"
                    placeholder="your@email.com"
                    disabled
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Avatar URL
                </label>
                <Input
                  value={profile.avatar_url}
                  onChange={(e) => updateField('avatar_url', e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white"
                  placeholder="https://example.com/avatar.jpg"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Bio
                </label>
                <Textarea
                  value={profile.bio}
                  onChange={(e) => updateField('bio', e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white"
                  placeholder="Tell us about yourself..."
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Professional Information */}
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Briefcase className="h-5 w-5 mr-2" />
                Professional Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Job Title
                  </label>
                  <Input
                    value={profile.job_title}
                    onChange={(e) => updateField('job_title', e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white"
                    placeholder="Software Developer"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Company
                  </label>
                  <Input
                    value={profile.company_name}
                    onChange={(e) => updateField('company_name', e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white"
                    placeholder="Company Name"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Skills */}
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Skills</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  value={newSkill}
                  onChange={(e) => setNewSkill(e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white flex-1"
                  placeholder="Add a skill..."
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddSkill();
                    }
                  }}
                />
                <Button onClick={handleAddSkill} className="bg-green-600 hover:bg-green-700">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {profile.skills.map((skill, index) => (
                  <Badge
                    key={index}
                    className="bg-green-500/20 text-green-400 border-green-500/30 pr-1"
                  >
                    {skill}
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleRemoveSkill(skill)}
                      className="ml-2 h-4 w-4 p-0 hover:bg-red-500/20 text-red-400"
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Phone className="h-5 w-5 mr-2" />
                Contact & Social
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Phone
                  </label>
                  <Input
                    value={profile.phone}
                    onChange={(e) => updateField('phone', e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white"
                    placeholder="+1 (555) 123-4567"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Location
                  </label>
                  <Input
                    value={profile.location}
                    onChange={(e) => updateField('location', e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white"
                    placeholder="City, Country"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Website
                  </label>
                  <Input
                    value={profile.website_url}
                    onChange={(e) => updateField('website_url', e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white"
                    placeholder="https://yourwebsite.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    GitHub
                  </label>
                  <Input
                    value={profile.github_url}
                    onChange={(e) => updateField('github_url', e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white"
                    placeholder="https://github.com/username"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ProfileBuilder;

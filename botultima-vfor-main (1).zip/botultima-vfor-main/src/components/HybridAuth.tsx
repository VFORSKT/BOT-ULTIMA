
import { useAuth as useSupabaseAuth } from './AuthenticationManager';
import { useAuth as useClerkAuth, useUser } from '@clerk/clerk-react';
import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface HybridUser {
  id: string;
  email?: string;
  firstName?: string;
  fullName?: string;
  imageUrl?: string;
  primaryEmailAddress?: {
    emailAddress: string;
  };
}

export const useHybridAuth = () => {
  const supabaseAuth = useSupabaseAuth();
  const clerkAuth = useClerkAuth();
  const { user: clerkUser } = useUser();
  const [hybridLoading, setHybridLoading] = useState(true);

  useEffect(() => {
    const syncAuthStates = async () => {
      if (clerkAuth.isLoaded) {
        setHybridLoading(false);
        
        if (clerkAuth.isSignedIn && clerkUser) {
          // User is signed in with Clerk - create/update profile with Clerk ID as string
          try {
            const { data: existingProfile, error: profileError } = await supabase
              .from('profiles')
              .select('*')
              .eq('clerk_id', clerkUser.id)
              .single();

            if (profileError && profileError.code === 'PGRST116') {
              // Profile doesn't exist, create it
              const { error: insertError } = await supabase
                .from('profiles')
                .insert({
                  id: clerkUser.id, // Use Clerk ID directly
                  clerk_id: clerkUser.id,
                  email: clerkUser.primaryEmailAddress?.emailAddress,
                  username: clerkUser.fullName || clerkUser.primaryEmailAddress?.emailAddress?.split('@')[0],
                  avatar_url: clerkUser.imageUrl,
                  plan: 'free',
                  role: 'user'
                });

              if (insertError) {
                console.error('Error creating Clerk profile:', insertError);
              }
            }
          } catch (syncError) {
            console.error('Error syncing Clerk profile:', syncError);
          }
        }
      }
    };

    syncAuthStates();
  }, [clerkAuth.isLoaded, clerkAuth.isSignedIn, clerkUser, supabaseAuth]);

  // Create a normalized user object
  const normalizedUser: HybridUser | null = clerkAuth.isSignedIn && clerkUser 
    ? {
        id: clerkUser.id,
        email: clerkUser.primaryEmailAddress?.emailAddress,
        firstName: clerkUser.firstName,
        fullName: clerkUser.fullName,
        imageUrl: clerkUser.imageUrl,
        primaryEmailAddress: clerkUser.primaryEmailAddress
      }
    : supabaseAuth.user 
    ? {
        id: supabaseAuth.user.id,
        email: supabaseAuth.user.email,
        firstName: supabaseAuth.user.user_metadata?.first_name,
        fullName: supabaseAuth.user.user_metadata?.full_name,
        imageUrl: supabaseAuth.user.user_metadata?.avatar_url
      }
    : null;

  return {
    user: normalizedUser,
    isAuthenticated: clerkAuth.isSignedIn || !!supabaseAuth.user,
    loading: hybridLoading || !clerkAuth.isLoaded || supabaseAuth.loading,
    clerkAuth,
    supabaseAuth,
    signOut: async () => {
      await clerkAuth.signOut();
      await supabaseAuth.signOut();
    }
  };
};

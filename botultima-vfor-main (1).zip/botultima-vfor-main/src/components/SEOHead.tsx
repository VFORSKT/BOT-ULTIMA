
import { useEffect } from 'react';

interface SEOHeadProps {
  title?: string;
  description?: string;
  keywords?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogUrl?: string;
  canonicalUrl?: string;
}

const SEOHead = ({
  title = "BOTultima 3.0 - The Ultimate No-Code AI Automation Platform by VFOR",
  description = "Build powerful AI bots with no coding required. BOTultima 3.0 by VFOR - India's first AI bot-building studio. Create, deploy, and scale AI automation workflows instantly.",
  keywords = "AI bot builder, no-code automation, chatbot creator, AI workflows, bot building platform, artificial intelligence, automation tools",
  ogTitle = "BOTultima 3.0 - No-Code AI Bot Builder by VFOR",
  ogDescription = "Create powerful AI bots without coding. Deploy instantly on Telegram, WhatsApp, and more. Start building for free with BOTultima 3.0.",
  ogUrl = "https://botultima.com",
  canonicalUrl
}: SEOHeadProps) => {
  useEffect(() => {
    // Update document title
    document.title = title;

    // Update or create meta tags
    const updateMetaTag = (name: string, content: string, property?: boolean) => {
      const selector = property ? `meta[property="${name}"]` : `meta[name="${name}"]`;
      let meta = document.querySelector(selector) as HTMLMetaElement;
      
      if (!meta) {
        meta = document.createElement('meta');
        if (property) {
          meta.setAttribute('property', name);
        } else {
          meta.setAttribute('name', name);
        }
        document.head.appendChild(meta);
      }
      meta.setAttribute('content', content);
    };

    // Basic meta tags
    updateMetaTag('description', description);
    updateMetaTag('keywords', keywords);
    updateMetaTag('robots', 'index,follow');
    updateMetaTag('author', 'VFOR');

    // Open Graph meta tags
    updateMetaTag('og:title', ogTitle, true);
    updateMetaTag('og:description', ogDescription, true);
    updateMetaTag('og:type', 'website', true);
    updateMetaTag('og:url', ogUrl, true);
    updateMetaTag('og:site_name', 'BOTultima 3.0', true);

    // Twitter meta tags
    updateMetaTag('twitter:card', 'summary_large_image');
    updateMetaTag('twitter:title', ogTitle);
    updateMetaTag('twitter:description', ogDescription);

    // Canonical URL
    if (canonicalUrl) {
      let link = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
      if (!link) {
        link = document.createElement('link');
        link.setAttribute('rel', 'canonical');
        document.head.appendChild(link);
      }
      link.setAttribute('href', canonicalUrl);
    }

    // Structured data for homepage
    if (window.location.pathname === '/') {
      const structuredData = {
        "@context": "https://schema.org",
        "@type": "SoftwareApplication",
        "name": "BOTultima 3.0",
        "description": description,
        "applicationCategory": "BusinessApplication",
        "operatingSystem": "Web",
        "offers": {
          "@type": "Offer",
          "price": "0",
          "priceCurrency": "USD"
        },
        "creator": {
          "@type": "Organization",
          "name": "VFOR",
          "description": "India's first AI bot-building studio"
        }
      };

      let script = document.querySelector('script[type="application/ld+json"]');
      if (!script) {
        script = document.createElement('script');
        script.setAttribute('type', 'application/ld+json');
        document.head.appendChild(script);
      }
      script.textContent = JSON.stringify(structuredData);
    }
  }, [title, description, keywords, ogTitle, ogDescription, ogUrl, canonicalUrl]);

  return null;
};

export default SEOHead;

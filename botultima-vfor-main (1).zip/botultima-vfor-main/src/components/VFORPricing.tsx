import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Crown, Zap, Building2, Star, Shield, Clock, Users, BarChart3 } from "lucide-react";
const VFORPricing = () => {
  const [billingCycle, setBillingCycle] = useState("monthly");
  const plans = [{
    name: "Starter",
    price: billingCycle === "monthly" ? 0 : 0,
    description: "Perfect for getting started",
    icon: <Zap className="h-6 w-6" />,
    color: "from-blue-500 to-cyan-500",
    features: ["1 Bot", "3,000 Mixtral tokens/month", "Basic templates", "Community support", "Telegram deployment"],
    notIncluded: ["No GPT-4 access", "No AI agents", "No custom branding", "No analytics", "Basic support only"],
    popular: false
  }, {
    name: "Maker",
    price: billingCycle === "monthly" ? 299 : 2990,
    originalPrice: billingCycle === "monthly" ? null : 3588,
    description: "For serious bot creators",
    icon: <Crown className="h-6 w-6" />,
    color: "from-green-500 to-emerald-500",
    features: ["5 Bots", "20,000 GPT-4 tokens/month", "AI Agent Studio", "All platform deployments", "Gmail & Notion integration", "Advanced templates", "Priority support", "Analytics dashboard", "Custom integrations", "API access"],
    notIncluded: ["Limited concurrent executions"],
    popular: true
  }, {
    name: "Agency",
    price: billingCycle === "monthly" ? 1999 : 19990,
    originalPrice: billingCycle === "monthly" ? null : 23988,
    description: "For teams and businesses",
    icon: <Building2 className="h-6 w-6" />,
    color: "from-purple-500 to-pink-500",
    features: ["Unlimited bots", "Unlimited GPT-4 Pro tokens", "White-label solution", "Team collaboration", "Advanced analytics", "Custom onboarding", "24/7 priority support", "API access", "Custom models", "Priority features", "Dedicated manager", "SLA guarantee"],
    notIncluded: [],
    popular: false
  }];
  const formatPrice = price => {
    return `₹${price}`;
  };
  const initiatePayment = async plan => {
    console.log(`Initiating payment for ${plan.name} plan`);
    alert(`Payment initiated for ${plan.name} plan - ${formatPrice(plan.price)}`);
  };
  return <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900 text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header with VFOR Logo */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <img src="/lovable-uploads/500179b6-0788-48ac-a2d3-c24dbadfc2a9.png" alt="VFOR Logo" className="w-16 h-16 mr-4" />
            <div>
              <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-green-400 to-emerald-300 bg-clip-text text-transparent">SixMorph</h1>
              <p className="text-sm text-green-400 font-medium">by VFOR</p>
            </div>
          </div>
          <p className="text-xl text-gray-300 mb-8">
            The Ultimate Bot Creation Platform
          </p>
          
          {/* Billing Toggle */}
          <div className="flex items-center justify-center space-x-4 mb-8">
            <span className={`${billingCycle === 'monthly' ? 'text-white' : 'text-gray-400'}`}>
              Monthly
            </span>
            <button onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'yearly' : 'monthly')} className="relative inline-flex h-6 w-11 items-center rounded-full bg-gray-700 transition-colors focus:outline-none focus:ring-2 focus:ring-green-500">
              <span className={`inline-block h-4 w-4 transform rounded-full bg-green-500 transition-transform ${billingCycle === 'yearly' ? 'translate-x-6' : 'translate-x-1'}`} />
            </button>
            <span className={`${billingCycle === 'yearly' ? 'text-white' : 'text-gray-400'}`}>
              Yearly
            </span>
            {billingCycle === 'yearly' && <Badge className="bg-green-500/20 text-green-400 border-green-500/30 ml-2">
                Save 20%
              </Badge>}
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {plans.map((plan, index) => <Card key={index} className={`relative bg-gray-800/50 border-gray-700 hover:border-gray-600 transition-all duration-300 ${plan.popular ? 'ring-2 ring-green-500/50 scale-105' : ''}`}>
              {plan.popular && <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-green-500 text-white px-4 py-1">
                    <Star className="h-3 w-3 mr-1" />
                    Most Popular
                  </Badge>
                </div>}
              
              <CardHeader className="text-center pb-4">
                <div className={`w-16 h-16 mx-auto mb-4 bg-gradient-to-r ${plan.color} rounded-xl flex items-center justify-center`}>
                  {plan.icon}
                </div>
                <CardTitle className="text-2xl font-bold text-white">{plan.name}</CardTitle>
                <p className="text-gray-400">{plan.description}</p>
              </CardHeader>
              
              <CardContent className="pt-0">
                <div className="text-center mb-6">
                  <div className="flex items-center justify-center space-x-2">
                    <span className="text-4xl font-bold text-white">
                      {formatPrice(plan.price)}
                    </span>
                    <span className="text-gray-400">
                      /{billingCycle === 'monthly' ? 'month' : 'year'}
                    </span>
                  </div>
                  {plan.originalPrice && <div className="text-sm text-gray-500 line-through mt-1">
                      {formatPrice(plan.originalPrice)}
                    </div>}
                </div>

                <ul className="space-y-3 mb-4">
                  {plan.features.map((feature, featureIndex) => <li key={featureIndex} className="flex items-center text-gray-300">
                      <Check className="h-4 w-4 text-green-400 mr-3 flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </li>)}
                </ul>

                {plan.notIncluded && plan.notIncluded.length > 0 && <>
                    <div className="text-gray-400 text-sm font-medium mb-2">Not included:</div>
                    <ul className="space-y-2 mb-6">
                      {plan.notIncluded.map((item, itemIndex) => <li key={itemIndex} className="flex items-center text-gray-500">
                          <span className="text-red-400 mr-3">✗</span>
                          <span className="text-xs">{item}</span>
                        </li>)}
                    </ul>
                  </>}

                <Button onClick={() => initiatePayment(plan)} className={`w-full ${plan.popular ? 'bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700' : 'bg-gray-700 hover:bg-gray-600'} text-white font-semibold py-3 rounded-lg transition-all duration-300`}>
                  {plan.name === 'Starter' ? 'Get Started' : 'Start Free Trial'}
                </Button>
              </CardContent>
            </Card>)}
        </div>

        {/* Trust Indicators */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <div className="text-center p-6 bg-gray-800/30 rounded-lg border border-gray-700">
            <Shield className="h-8 w-8 text-green-400 mx-auto mb-3" />
            <h3 className="font-semibold text-white mb-2">Secure Payments</h3>
            <p className="text-sm text-gray-400">256-bit SSL encryption</p>
          </div>
          <div className="text-center p-6 bg-gray-800/30 rounded-lg border border-gray-700">
            <Clock className="h-8 w-8 text-blue-400 mx-auto mb-3" />
            <h3 className="font-semibold text-white mb-2">14-day Trial</h3>
            <p className="text-sm text-gray-400">No commitment required</p>
          </div>
          <div className="text-center p-6 bg-gray-800/30 rounded-lg border border-gray-700">
            <Users className="h-8 w-8 text-purple-400 mx-auto mb-3" />
            <h3 className="font-semibold text-white mb-2">VFOR Community</h3>
            <p className="text-sm text-gray-400">Join our growing ecosystem</p>
          </div>
          <div className="text-center p-6 bg-gray-800/30 rounded-lg border border-gray-700">
            <BarChart3 className="h-8 w-8 text-orange-400 mx-auto mb-3" />
            <h3 className="font-semibold text-white mb-2">99.9% Uptime</h3>
            <p className="text-sm text-gray-400">Enterprise-grade reliability</p>
          </div>
        </div>

        {/* API Keys Notice */}
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-white text-center">
              API Keys Setup
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-blue-900/20 border border-blue-500/30 rounded">
                <h3 className="font-semibold text-blue-300 mb-2">OpenAI API Key</h3>
                <p className="text-sm text-blue-200">Required for GPT-4 models and advanced AI features</p>
              </div>
              <div className="p-4 bg-purple-900/20 border border-purple-500/30 rounded">
                <h3 className="font-semibold text-purple-300 mb-2">DeepSeek API Key</h3>
                <p className="text-sm text-purple-200">Required for DeepSeek reasoning models</p>
              </div>
              <div className="p-4 bg-orange-900/20 border border-orange-500/30 rounded">
                <h3 className="font-semibold text-orange-300 mb-2">Mixtral API Key</h3>
                <p className="text-sm text-orange-200">Required for fast multilingual processing</p>
              </div>
            </div>
            <p className="text-center text-gray-400 text-sm">
              API keys can be configured after signup in your dashboard settings
            </p>
          </CardContent>
        </Card>
      </div>
    </div>;
};
export default VFORPricing;
import { useEffect, useRef } from "react";

const AnimatedBackground = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);

    let animationId: number;
    let time = 0;

    // Floating orbs data
    const orbs = Array.from({ length: 8 }, (_, i) => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      radius: Math.random() * 20 + 10,
      speed: Math.random() * 0.5 + 0.2,
      angle: Math.random() * Math.PI * 2,
      orbitRadius: Math.random() * 100 + 50,
      centerX: Math.random() * canvas.width,
      centerY: Math.random() * canvas.height,
      opacity: Math.random() * 0.6 + 0.2,
    }));

    // Stars data
    const stars = Array.from({ length: 150 }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      radius: Math.random() * 1.5 + 0.5,
      opacity: Math.random() * 0.8 + 0.2,
      twinkleSpeed: Math.random() * 0.02 + 0.01,
    }));

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Dark gradient background
      const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
      gradient.addColorStop(0, "rgba(17, 24, 39, 0.95)");
      gradient.addColorStop(0.5, "rgba(31, 41, 55, 0.9)");
      gradient.addColorStop(1, "rgba(17, 24, 39, 0.95)");
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw animated starfield
      stars.forEach((star) => {
        const twinkle = Math.sin(time * star.twinkleSpeed) * 0.3 + 0.7;
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(34, 197, 94, ${star.opacity * twinkle})`;
        ctx.fill();
        
        // Add subtle glow
        ctx.shadowBlur = 4;
        ctx.shadowColor = "rgba(34, 197, 94, 0.5)";
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      // Draw flowing wavy grid
      const gridSize = 50;
      const waveAmplitude = 10;
      const waveFrequency = 0.01;
      
      ctx.strokeStyle = "rgba(34, 197, 94, 0.15)";
      ctx.lineWidth = 1;
      ctx.shadowBlur = 2;
      ctx.shadowColor = "rgba(34, 197, 94, 0.3)";

      // Vertical wavy lines
      for (let x = 0; x <= canvas.width; x += gridSize) {
        ctx.beginPath();
        for (let y = 0; y <= canvas.height; y += 2) {
          const waveX = x + Math.sin(y * waveFrequency + time * 0.001) * waveAmplitude;
          if (y === 0) {
            ctx.moveTo(waveX, y);
          } else {
            ctx.lineTo(waveX, y);
          }
        }
        ctx.stroke();
      }

      // Horizontal wavy lines
      for (let y = 0; y <= canvas.height; y += gridSize) {
        ctx.beginPath();
        for (let x = 0; x <= canvas.width; x += 2) {
          const waveY = y + Math.sin(x * waveFrequency + time * 0.001 + Math.PI / 2) * waveAmplitude;
          if (x === 0) {
            ctx.moveTo(x, waveY);
          } else {
            ctx.lineTo(x, waveY);
          }
        }
        ctx.stroke();
      }

      ctx.shadowBlur = 0;

      // Draw floating orbs
      orbs.forEach((orb) => {
        // Update orb position (orbital motion)
        orb.angle += orb.speed * 0.01;
        orb.x = orb.centerX + Math.cos(orb.angle) * orb.orbitRadius;
        orb.y = orb.centerY + Math.sin(orb.angle) * orb.orbitRadius;

        // Keep orbs within bounds
        if (orb.centerX < -orb.orbitRadius || orb.centerX > canvas.width + orb.orbitRadius) {
          orb.centerX = Math.random() * canvas.width;
        }
        if (orb.centerY < -orb.orbitRadius || orb.centerY > canvas.height + orb.orbitRadius) {
          orb.centerY = Math.random() * canvas.height;
        }

        // Draw orb with neon glow
        const gradient = ctx.createRadialGradient(orb.x, orb.y, 0, orb.x, orb.y, orb.radius);
        gradient.addColorStop(0, `rgba(34, 197, 94, ${orb.opacity})`);
        gradient.addColorStop(0.4, `rgba(6, 182, 212, ${orb.opacity * 0.6})`);
        gradient.addColorStop(1, "transparent");

        ctx.beginPath();
        ctx.arc(orb.x, orb.y, orb.radius, 0, Math.PI * 2);
        ctx.fillStyle = gradient;
        ctx.fill();

        // Add outer glow
        ctx.shadowBlur = 20;
        ctx.shadowColor = "rgba(34, 197, 94, 0.4)";
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      time += 16;
      animationId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener("resize", resizeCanvas);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none"
      style={{ zIndex: 1 }}
    />
  );
};

export default AnimatedBackground;

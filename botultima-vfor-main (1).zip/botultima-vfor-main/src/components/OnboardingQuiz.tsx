import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, ArrowRight, Sparkles, Target, Users, Zap } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import QuizResults from "./QuizResults";
import QuizQuestion from "./QuizQuestion";

interface Question {
  id: string;
  question: string;
  options: string[];
  category: string;
}

interface QuizAnalysis {
  user_profile: {
    experience_level: string;
    primary_goal: string;
    industry: string;
    preferred_approach: string;
    budget_range: string;
    time_commitment: string;
  };
  recommended_agents: Array<{
    id: string;
    name: string;
    description: string;
    category: string;
    difficulty_level: string;
    match_score: number;
  }>;
  recommended_workflows: Array<{
    id: string;
    name: string;
    description: string;
    category: string;
    difficulty_level: string;
    match_score: number;
  }>;
  next_steps: string[];
}

const OnboardingQuiz = () => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [isLoading, setIsLoading] = useState(true);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [analysis, setAnalysis] = useState<QuizAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    loadQuestions();
  }, []);

  const loadQuestions = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('quiz_questions')
        .select('*')
        .order('created_at');

      if (error) throw error;

      const formattedQuestions = data.map((q) => ({
        id: q.id,
        question: q.question,
        options: Array.isArray(q.options) ? q.options : JSON.parse(q.options as string),
        category: q.category,
      }));

      setQuestions(formattedQuestions);
    } catch (err) {
      console.error('Error loading questions:', err);
      setError('Failed to load quiz questions. Please refresh and try again.');
      toast({
        title: "Error",
        description: "Failed to load quiz questions",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAnswerSelect = (answer: string) => {
    setAnswers(prev => ({
      ...prev,
      [currentQuestion]: answer
    }));
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      submitQuiz();
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    }
  };

  const submitQuiz = async () => {
    try {
      setIsAnalyzing(true);
      
      // Convert answers to the format expected by the database function
      const answersArray = questions.map((_, index) => answers[index] || '');
      
      // Call the analyze function
      const { data: analysisData, error: analysisError } = await supabase
        .rpc('analyze_quiz_results', { answers: answersArray });

      if (analysisError) throw analysisError;

      // Type cast the Json response to our QuizAnalysis interface
      const typedAnalysis = analysisData as unknown as QuizAnalysis;
      setAnalysis(typedAnalysis);

      // Store the quiz results if user is authenticated
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          const { error: saveError } = await supabase
            .from('quiz_results')
            .insert({
              user_id: user.id,
              answers: answersArray,
              analysis_result: analysisData,
              recommended_agents: (analysisData as unknown as QuizAnalysis).recommended_agents,
              recommended_workflows: (analysisData as unknown as QuizAnalysis).recommended_workflows,
            });

          if (saveError) {
            console.error('Error saving quiz results:', saveError);
          }
        }
      } catch (saveErr) {
        console.error('Error saving quiz results:', saveErr);
        // Don't block the user experience if saving fails
      }

      setShowResults(true);
      toast({
        title: "Analysis Complete!",
        description: "Your personalized recommendations are ready",
      });
    } catch (err) {
      console.error('Error analyzing quiz:', err);
      setError('Failed to analyze your responses. Please try again.');
      toast({
        title: "Analysis Failed",
        description: "Failed to generate recommendations. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setShowResults(false);
    setAnalysis(null);
    setError(null);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900 flex items-center justify-center">
        <Card className="bg-gray-800/95 border-green-500/30 backdrop-blur-sm">
          <CardContent className="p-8">
            <div className="flex items-center space-x-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-400"></div>
              <p className="text-white">Loading your personalized quiz...</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900 flex items-center justify-center">
        <Card className="bg-gray-800/95 border-red-500/30 backdrop-blur-sm max-w-md">
          <CardContent className="p-8 text-center">
            <div className="text-red-400 mb-4">
              <Target className="h-12 w-12 mx-auto" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Something went wrong</h3>
            <p className="text-gray-300 mb-4">{error}</p>
            <Button onClick={() => window.location.reload()} className="bg-green-600 hover:bg-green-700">
              Retry
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (showResults && analysis) {
    return <QuizResults analysis={analysis} onRetake={resetQuiz} />;
  }

  if (questions.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900 flex items-center justify-center">
        <Card className="bg-gray-800/95 border-orange-500/30 backdrop-blur-sm max-w-md">
          <CardContent className="p-8 text-center">
            <div className="text-orange-400 mb-4">
              <Sparkles className="h-12 w-12 mx-auto" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">No Questions Available</h3>
            <p className="text-gray-300 mb-4">Please check back later or contact support.</p>
            <Button onClick={() => window.location.reload()} className="bg-green-600 hover:bg-green-700">
              Refresh
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const progress = ((currentQuestion + 1) / questions.length) * 100;
  const currentQ = questions[currentQuestion];
  const currentAnswer = answers[currentQuestion];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900 p-4">
      <div className="max-w-2xl mx-auto pt-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <img src="/lovable-uploads/500179b6-0788-48ac-a2d3-c24dbadfc2a9.png" alt="VFOR Logo" className="w-12 h-12 mr-3" />
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-green-400 to-emerald-300 bg-clip-text text-transparent">
                SixMorph Onboarding
              </h1>
              <p className="text-sm text-green-400 font-medium">Discover Your AI Automation Path</p>
            </div>
          </div>
          
          <div className="flex items-center justify-between text-sm text-gray-400 mb-4">
            <span>Question {currentQuestion + 1} of {questions.length}</span>
            <Badge variant="outline" className="border-green-500/30 text-green-400">
              {Math.round(progress)}% Complete
            </Badge>
          </div>
          
          <Progress value={progress} className="h-2 bg-gray-800">
            <div 
              className="h-full bg-gradient-to-r from-green-500 to-emerald-500 transition-all duration-500 ease-out rounded-full"
              style={{ width: `${progress}%` }}
            />
          </Progress>
        </div>

        {/* Question Card */}
        <Card className="bg-gray-800/95 border-green-500/30 backdrop-blur-sm mb-6">
          <CardHeader>
            <CardTitle className="text-white text-xl flex items-center">
              <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white font-bold text-sm mr-3">
                {currentQuestion + 1}
              </div>
              {currentQ?.question}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <QuizQuestion
              question={currentQ?.question || ''}
              options={currentQ?.options || []}
              selectedAnswer={currentAnswer}
              onAnswerSelect={handleAnswerSelect}
            />
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between items-center">
          <Button
            onClick={handlePrevious}
            variant="outline"
            disabled={currentQuestion === 0}
            className="border-gray-600 hover:bg-gray-700 disabled:opacity-50"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Previous
          </Button>

          <div className="flex items-center space-x-2 text-gray-400">
            {questions.map((_, index) => (
              <div
                key={index}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  index < currentQuestion
                    ? 'bg-green-500'
                    : index === currentQuestion
                    ? 'bg-green-400 ring-2 ring-green-400/50'
                    : 'bg-gray-600'
                }`}
              />
            ))}
          </div>

          <Button
            onClick={handleNext}
            disabled={!currentAnswer || isAnalyzing}
            className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 disabled:opacity-50"
          >
            {isAnalyzing ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Analyzing...
              </>
            ) : currentQuestion === questions.length - 1 ? (
              <>
                Get Results
                <Zap className="h-4 w-4 ml-2" />
              </>
            ) : (
              <>
                Next
                <ArrowRight className="h-4 w-4 ml-2" />
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default OnboardingQuiz;

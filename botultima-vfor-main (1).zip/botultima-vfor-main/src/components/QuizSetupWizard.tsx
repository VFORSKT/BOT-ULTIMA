
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Plus, Trash2, Save } from "lucide-react";

interface QuizQuestion {
  question: string;
  options: string[];
  category: string;
  weight: number;
}

const QuizSetupWizard = () => {
  const [questions, setQuestions] = useState<QuizQuestion[]>([
    {
      question: "",
      options: ["", "", "", ""],
      category: "general",
      weight: 1
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const addQuestion = () => {
    setQuestions([...questions, {
      question: "",
      options: ["", "", "", ""],
      category: "general",
      weight: 1
    }]);
  };

  const removeQuestion = (index: number) => {
    setQuestions(questions.filter((_, i) => i !== index));
  };

  const updateQuestion = (index: number, field: keyof QuizQuestion, value: any) => {
    const updated = [...questions];
    updated[index] = { ...updated[index], [field]: value };
    setQuestions(updated);
  };

  const updateOption = (questionIndex: number, optionIndex: number, value: string) => {
    const updated = [...questions];
    updated[questionIndex].options[optionIndex] = value;
    setQuestions(updated);
  };

  const saveQuestions = async () => {
    setIsLoading(true);
    try {
      const validQuestions = questions.filter(q => 
        q.question.trim() && q.options.every(opt => opt.trim())
      );

      for (const question of validQuestions) {
        const { error } = await supabase
          .from('quiz_questions')
          .insert({
            question: question.question,
            options: question.options,
            category: question.category,
            weight: question.weight
          });

        if (error) throw error;
      }

      toast({
        title: "Success!",
        description: `${validQuestions.length} questions saved successfully`,
      });
    } catch (error) {
      console.error('Error saving questions:', error);
      toast({
        title: "Error",
        description: "Failed to save questions",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Quiz Setup</h2>
          <p className="text-gray-400">Configure onboarding quiz questions</p>
        </div>
        <div className="flex space-x-2">
          <Button onClick={addQuestion} variant="outline" className="border-green-500/30">
            <Plus className="h-4 w-4 mr-2" />
            Add Question
          </Button>
          <Button onClick={saveQuestions} disabled={isLoading} className="bg-green-600 hover:bg-green-700">
            <Save className="h-4 w-4 mr-2" />
            {isLoading ? "Saving..." : "Save All"}
          </Button>
        </div>
      </div>

      {questions.map((question, qIndex) => (
        <Card key={qIndex} className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center justify-between">
              Question {qIndex + 1}
              {questions.length > 1 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeQuestion(qIndex)}
                  className="text-red-400 hover:text-red-300"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-gray-300">Question Text</Label>
              <Textarea
                value={question.question}
                onChange={(e) => updateQuestion(qIndex, 'question', e.target.value)}
                className="bg-gray-700 border-gray-600 text-white"
                placeholder="Enter your question..."
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-300">Category</Label>
                <Select
                  value={question.category}
                  onValueChange={(value) => updateQuestion(qIndex, 'category', value)}
                >
                  <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">General</SelectItem>
                    <SelectItem value="experience">Experience</SelectItem>
                    <SelectItem value="goals">Goals</SelectItem>
                    <SelectItem value="technical">Technical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-gray-300">Weight</Label>
                <Input
                  type="number"
                  min="1"
                  max="10"
                  value={question.weight}
                  onChange={(e) => updateQuestion(qIndex, 'weight', parseInt(e.target.value) || 1)}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>

            <div>
              <Label className="text-gray-300">Answer Options</Label>
              <div className="grid grid-cols-2 gap-2 mt-2">
                {question.options.map((option, oIndex) => (
                  <Input
                    key={oIndex}
                    value={option}
                    onChange={(e) => updateOption(qIndex, oIndex, e.target.value)}
                    className="bg-gray-700 border-gray-600 text-white"
                    placeholder={`Option ${oIndex + 1}`}
                  />
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default QuizSetupWizard;

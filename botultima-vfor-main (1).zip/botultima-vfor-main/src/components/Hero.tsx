
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bot, Zap, Sparkles, ChevronRight, Play, MessageSquare, Brain, Send } from "lucide-react";
import { useNavigate } from "react-router-dom";
import AnimatedBackground from "./AnimatedBackground";
import BotLogicSequence from "./BotLogicSequence";
import SEOHead from "./SEOHead";

const Hero = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [currentFeature, setCurrentFeature] = useState(0);
  const [flowStep, setFlowStep] = useState(0);
  const navigate = useNavigate();

  const features = [
    "No-Code Bot Builder",
    "AI Agent Studio", 
    "Visual Flow Designer",
    "One-Click Deployment"
  ];

  const flowSteps = [
    { icon: MessageSquare, title: "User Input", description: "Describe your bot idea", active: false },
    { icon: Brain, title: "AI Processing", description: "GPT-4 analyzes requirements", active: false },
    { icon: Bot, title: "Bot Generation", description: "Visual flow created", active: false },
    { icon: Send, title: "Deploy", description: "One-click launch", active: false }
  ];

  useEffect(() => {
    setIsVisible(true);
    const featureInterval = setInterval(() => {
      setCurrentFeature((prev) => (prev + 1) % features.length);
    }, 2000);

    const flowInterval = setInterval(() => {
      setFlowStep((prev) => (prev + 1) % flowSteps.length);
    }, 1500);

    return () => {
      clearInterval(featureInterval);
      clearInterval(flowInterval);
    };
  }, []);

  return (
    <section className="relative pt-24 pb-12 px-4 overflow-hidden">
      <SEOHead />
      
      {/* Animated Background */}
      <AnimatedBackground />

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-12">
          {/* Badge */}
          <div className={`inline-flex items-center mb-6 transform transition-all duration-1000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30 px-4 py-2 text-sm font-medium rounded-full glow-green">
              <Sparkles className="w-4 h-4 mr-2" />
              Introducing SixMorph 3.0
            </Badge>
          </div>

          {/* Main Headline */}
          <h1 className={`text-5xl md:text-7xl lg:text-8xl font-bold mb-6 transform transition-all duration-1000 delay-200 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            <span className="bg-gradient-to-r from-white via-green-200 to-emerald-300 bg-clip-text text-transparent">
              The Ultimate
            </span>
            <br />
            <span className="bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent relative">
              No-Code AI
              <div className="absolute -top-2 -right-8 w-6 h-6 bg-green-500 rounded-full animate-ping opacity-75"></div>
            </span>
            <br />
            <span className="bg-gradient-to-r from-green-300 to-blue-400 bg-clip-text text-transparent">
              Automation Platform
            </span>
          </h1>

          {/* Dynamic Subtitle */}
          <div className={`text-xl md:text-2xl text-gray-300 mb-8 h-8 transform transition-all duration-1000 delay-400 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            <span className="inline-block">
              Build powerful{" "}
              <span className="text-green-400 font-semibold transition-all duration-500 text-glow">
                {features[currentFeature]}
              </span>
              {" "}in minutes
            </span>
          </div>

          {/* Description */}
          <p className={`text-lg md:text-xl text-gray-400 mb-12 max-w-3xl mx-auto leading-relaxed transform transition-all duration-1000 delay-600 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            Describe your idea, watch AI build your bot visually, test instantly, and deploy with one click. 
            No coding required. Powered by GPT-4, Mixtral, and DeepSeek.
          </p>

          {/* CTA Buttons with Enhanced Neon Halo */}
          <div className={`flex flex-col sm:flex-row gap-4 justify-center items-center mb-12 transform transition-all duration-1000 delay-800 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            <div className="relative group">
              {/* Layered Neon Halo Animation */}
              <div className="absolute -inset-4 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                <div className="absolute inset-0 bg-gradient-radial from-green-400/20 via-cyan-400/10 to-transparent rounded-xl blur-xl animate-pulse-halo"></div>
                <div className="absolute inset-0 bg-gradient-radial from-cyan-400/15 via-green-400/8 to-transparent rounded-xl blur-lg animate-pulse-halo-delayed"></div>
                <div className="absolute inset-0 bg-gradient-radial from-white/10 via-transparent to-transparent rounded-xl blur-md animate-pulse-halo-fast"></div>
              </div>
              
              <div className="absolute -inset-1 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-300 animate-pulse-glow"></div>
              <Button 
                size="lg" 
                className="relative bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white px-8 py-6 text-lg font-semibold rounded-xl shadow-2xl shadow-green-500/25 transform hover:scale-105 transition-all duration-300 group z-10"
                onClick={() => navigate('/builder')}
              >
                <Bot className="mr-2 h-5 w-5 group-hover:animate-bounce" />
                Try Building Your First Bot
                <ChevronRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
            
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-green-500/50 to-emerald-600/50 rounded-xl blur opacity-50 group-hover:opacity-75 transition duration-300"></div>
              <Button 
                size="lg" 
                variant="outline" 
                className="relative border-green-500/50 text-green-400 hover:bg-green-500/10 px-8 py-6 text-lg rounded-xl group"
                onClick={() => navigate('/tutorials')}
              >
                <Play className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
                Watch 2-Min Demo
              </Button>
            </div>
          </div>

          {/* Bot Logic Sequence Animation */}
          <div className={`mb-12 transform transition-all duration-1000 delay-1000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            <BotLogicSequence />
          </div>

          {/* Dynamic Stats Section */}
          <div className={`grid grid-cols-1 md:grid-cols-3 gap-8 max-w-2xl mx-auto mb-12 transform transition-all duration-1000 delay-1200 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            <div className="text-center group hover:scale-105 transition-transform duration-300">
              <div className="text-3xl font-bold text-green-400 mb-2 animate-pulse-glow">Active</div>
              <div className="text-gray-400 flex items-center justify-center gap-2">
                <Bot className="w-4 h-4" />
                Community
              </div>
            </div>
            <div className="text-center group hover:scale-105 transition-transform duration-300">
              <div className="text-3xl font-bold text-green-400 mb-2 animate-pulse-glow">Global</div>
              <div className="text-gray-400 flex items-center justify-center gap-2">
                <Zap className="w-4 h-4" />
                Reach
              </div>
            </div>
            <div className="text-center group hover:scale-105 transition-transform duration-300">
              <div className="text-3xl font-bold text-green-400 mb-2 animate-pulse-glow">99.9%</div>
              <div className="text-gray-400 flex items-center justify-center gap-2">
                <Sparkles className="w-4 h-4" />
                Uptime
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Bot Builder Flow Preview */}
        <div className={`relative transform transition-all duration-1000 delay-1400 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
          <div className="bg-gradient-to-r from-gray-900/50 to-gray-800/50 rounded-2xl border border-green-500/20 p-8 backdrop-blur-sm shadow-2xl shadow-green-500/10 glow">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                <div className="w-3 h-3 bg-yellow-500 rounded-full animate-pulse delay-100"></div>
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse delay-200"></div>
              </div>
              <div className="text-green-400 text-sm font-mono">SixMorph Builder</div>
            </div>
            
            <div className="space-y-4">
              {flowSteps.map((step, index) => {
                const Icon = step.icon;
                const isActive = index === flowStep;
                const isCompleted = index < flowStep;
                
                return (
                  <div 
                    key={index}
                    className={`flex items-center space-x-4 p-4 rounded-lg border transition-all duration-500 ${
                      isActive 
                        ? 'bg-green-500/20 border-green-500/50 shadow-lg shadow-green-500/25 scale-105' 
                        : isCompleted
                        ? 'bg-green-500/10 border-green-500/30'
                        : 'bg-gray-800/50 border-gray-700/50'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all duration-300 ${
                      isActive 
                        ? 'bg-green-500 animate-pulse-glow' 
                        : isCompleted
                        ? 'bg-green-600'
                        : 'bg-gray-600'
                    }`}>
                      <Icon className="w-4 h-4 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className={`font-semibold transition-colors duration-300 ${
                        isActive ? 'text-green-300' : isCompleted ? 'text-green-400' : 'text-gray-400'
                      }`}>
                        {step.title}
                      </div>
                      <div className="text-gray-400 text-sm">{step.description}</div>
                    </div>
                    {isActive && (
                      <div className="w-2 h-2 bg-green-400 rounded-full animate-ping"></div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;


import { SignedIn, SignedOut, SignInButton, SignUpButton, UserButton } from '@clerk/clerk-react';
import { Button } from '@/components/ui/button';
import { useHybridAuth } from './HybridAuth';

export const HybridAuthWrapper = ({ children }: { children: React.ReactNode }) => {
  const { loading } = useHybridAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/10 to-gray-900 flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-2 border-green-400 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <>
      <SignedIn>
        {children}
      </SignedIn>
      <SignedOut>
        <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/10 to-gray-900 flex items-center justify-center">
          <div className="text-center space-y-4">
            <h1 className="text-4xl font-bold text-white mb-8">Welcome to SixMorph</h1>
            <div className="space-y-4">
              <SignInButton mode="modal">
                <Button className="w-full bg-green-600 hover:bg-green-700">
                  Sign In with Clerk
                </Button>
              </SignInButton>
              <SignUpButton mode="modal">
                <Button variant="outline" className="w-full border-green-500 text-green-400 hover:bg-green-500/10">
                  Sign Up with Clerk
                </Button>
              </SignUpButton>
            </div>
          </div>
        </div>
      </SignedOut>
    </>
  );
};

export const AuthButton = () => {
  return (
    <SignedIn>
      <UserButton afterSignOutUrl="/" />
    </SignedIn>
  );
};

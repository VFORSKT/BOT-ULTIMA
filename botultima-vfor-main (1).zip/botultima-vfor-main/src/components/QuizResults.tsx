
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Trophy, 
  User, 
  Bot, 
  Workflow, 
  ArrowRight, 
  Star, 
  Target,
  Lightbulb,
  RefreshCw,
  ExternalLink
} from "lucide-react";
import { useNavigate } from "react-router-dom";

interface QuizAnalysis {
  user_profile: {
    experience_level: string;
    primary_goal: string;
    industry: string;
    preferred_approach: string;
    budget_range: string;
    time_commitment: string;
  };
  recommended_agents: Array<{
    id: string;
    name: string;
    description: string;
    category: string;
    difficulty_level: string;
    match_score: number;
  }>;
  recommended_workflows: Array<{
    id: string;
    name: string;
    description: string;
    category: string;
    difficulty_level: string;
    match_score: number;
  }>;
  next_steps: string[];
}

interface QuizResultsProps {
  analysis: QuizAnalysis;
  onRetake: () => void;
}

const QuizResults = ({ analysis, onRetake }: QuizResultsProps) => {
  const [activeTab, setActiveTab] = useState("profile");
  const navigate = useNavigate();

  const getDifficultyColor = (level: string) => {
    switch (level) {
      case 'beginner':
        return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'intermediate':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'advanced':
        return 'bg-red-500/20 text-red-400 border-red-500/30';
      default:
        return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const getExperienceIcon = (level: string) => {
    switch (level) {
      case 'beginner':
        return '🌱';
      case 'intermediate':
        return '🚀';
      case 'advanced':
        return '⚡';
      default:
        return '🎯';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900 p-4">
      <div className="max-w-4xl mx-auto pt-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Trophy className="h-12 w-12 text-yellow-500 mr-3" />
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-green-400 to-emerald-300 bg-clip-text text-transparent">
                Your AI Automation Profile
              </h1>
              <p className="text-green-400 font-medium">Personalized recommendations ready!</p>
            </div>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-gray-800/50 border border-gray-700">
            <TabsTrigger value="profile" className="flex items-center space-x-2">
              <User className="h-4 w-4" />
              <span>Profile</span>
            </TabsTrigger>
            <TabsTrigger value="agents" className="flex items-center space-x-2">
              <Bot className="h-4 w-4" />
              <span>Agents</span>
            </TabsTrigger>
            <TabsTrigger value="workflows" className="flex items-center space-x-2">
              <Workflow className="h-4 w-4" />
              <span>Workflows</span>
            </TabsTrigger>
            <TabsTrigger value="next-steps" className="flex items-center space-x-2">
              <Lightbulb className="h-4 w-4" />
              <span>Next Steps</span>
            </TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <Card className="bg-gray-800/95 border-green-500/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <User className="h-6 w-6 mr-2 text-green-400" />
                  Your Automation Profile
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-gray-700/50 rounded-lg">
                      <span className="text-gray-300">Experience Level</span>
                      <div className="flex items-center space-x-2">
                        <span className="text-2xl">{getExperienceIcon(analysis.user_profile.experience_level)}</span>
                        <Badge className={getDifficultyColor(analysis.user_profile.experience_level)}>
                          {analysis.user_profile.experience_level}
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between p-4 bg-gray-700/50 rounded-lg">
                      <span className="text-gray-300">Primary Goal</span>
                      <span className="text-green-400 font-medium">{analysis.user_profile.primary_goal}</span>
                    </div>
                    
                    <div className="flex items-center justify-between p-4 bg-gray-700/50 rounded-lg">
                      <span className="text-gray-300">Industry Focus</span>
                      <span className="text-blue-400 font-medium">{analysis.user_profile.industry}</span>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-gray-700/50 rounded-lg">
                      <span className="text-gray-300">Preferred Approach</span>
                      <span className="text-purple-400 font-medium">{analysis.user_profile.preferred_approach}</span>
                    </div>
                    
                    <div className="flex items-center justify-between p-4 bg-gray-700/50 rounded-lg">
                      <span className="text-gray-300">Budget Range</span>
                      <span className="text-yellow-400 font-medium">{analysis.user_profile.budget_range}</span>
                    </div>
                    
                    <div className="flex items-center justify-between p-4 bg-gray-700/50 rounded-lg">
                      <span className="text-gray-300">Time Commitment</span>
                      <span className="text-orange-400 font-medium">{analysis.user_profile.time_commitment}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Agents Tab */}
          <TabsContent value="agents">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-white flex items-center">
                  <Bot className="h-6 w-6 mr-2 text-green-400" />
                  Recommended AI Agents
                </h2>
                <Badge variant="outline" className="border-green-500/30 text-green-400">
                  {analysis.recommended_agents.length} matches found
                </Badge>
              </div>
              
              <div className="grid gap-4">
                {analysis.recommended_agents.map((agent, index) => (
                  <Card key={agent.id} className="bg-gray-800/95 border-green-500/30 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="text-lg font-bold text-white">{agent.name}</h3>
                            <Badge className={getDifficultyColor(agent.difficulty_level)}>
                              {agent.difficulty_level}
                            </Badge>
                            <div className="flex items-center space-x-1">
                              <Star className="h-4 w-4 text-yellow-500" />
                              <span className="text-yellow-500 font-medium">{agent.match_score}% match</span>
                            </div>
                          </div>
                          <p className="text-gray-300 mb-3">{agent.description}</p>
                          <Badge variant="outline" className="border-blue-500/30 text-blue-400">
                            {agent.category}
                          </Badge>
                        </div>
                      </div>
                      
                      <Button
                        onClick={() => navigate('/agents')}
                        className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                      >
                        Explore This Agent
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Workflows Tab */}
          <TabsContent value="workflows">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-white flex items-center">
                  <Workflow className="h-6 w-6 mr-2 text-green-400" />
                  Recommended Workflows
                </h2>
                <Badge variant="outline" className="border-green-500/30 text-green-400">
                  {analysis.recommended_workflows.length} matches found
                </Badge>
              </div>
              
              <div className="grid gap-4">
                {analysis.recommended_workflows.map((workflow, index) => (
                  <Card key={workflow.id} className="bg-gray-800/95 border-green-500/30 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="text-lg font-bold text-white">{workflow.name}</h3>
                            <Badge className={getDifficultyColor(workflow.difficulty_level)}>
                              {workflow.difficulty_level}
                            </Badge>
                            <div className="flex items-center space-x-1">
                              <Star className="h-4 w-4 text-yellow-500" />
                              <span className="text-yellow-500 font-medium">{workflow.match_score}% match</span>
                            </div>
                          </div>
                          <p className="text-gray-300 mb-3">{workflow.description}</p>
                          <Badge variant="outline" className="border-purple-500/30 text-purple-400">
                            {workflow.category}
                          </Badge>
                        </div>
                      </div>
                      
                      <Button
                        onClick={() => navigate('/builder')}
                        className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
                      >
                        Try This Workflow
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Next Steps Tab */}
          <TabsContent value="next-steps">
            <Card className="bg-gray-800/95 border-green-500/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Lightbulb className="h-6 w-6 mr-2 text-yellow-400" />
                  Your Next Steps
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {analysis.next_steps.map((step, index) => (
                    <div key={index} className="flex items-start space-x-4 p-4 bg-gray-700/50 rounded-lg">
                      <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <p className="text-gray-200">{step}</p>
                      </div>
                      <Target className="h-5 w-5 text-green-400 flex-shrink-0" />
                    </div>
                  ))}
                </div>
                
                <div className="mt-8 flex flex-col sm:flex-row gap-4">
                  <Button
                    onClick={() => navigate('/dashboard')}
                    className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                  >
                    Go to Dashboard
                    <ExternalLink className="h-4 w-4 ml-2" />
                  </Button>
                  
                  <Button
                    onClick={() => navigate('/builder')}
                    variant="outline"
                    className="flex-1 border-gray-600 hover:bg-gray-700"
                  >
                    Start Building
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Action Buttons */}
        <div className="flex justify-center mt-8">
          <Button
            onClick={onRetake}
            variant="outline"
            className="border-gray-600 hover:bg-gray-700"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Retake Quiz
          </Button>
        </div>
      </div>
    </div>
  );
};

export default QuizResults;

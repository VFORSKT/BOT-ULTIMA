
import { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bot, Send, X, Minimize2, Maximize2, Sparkles } from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
}

const AISupportAssistant = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: 'Hi! I\'m your BOTultima AI assistant. I can help you with:\n\n• Creating your first bot\n• Upgrading your plan\n• Setting up integrations (Gmail, Notion, etc.)\n• Troubleshooting issues\n\nWhat would you like to know?',
      timestamp: new Date(),
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getAIResponse = async (userMessage: string): Promise<string> => {
    // Simulate AI processing delay
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
    
    const message = userMessage.toLowerCase();
    
    // FAQ responses
    if (message.includes('create') || message.includes('build') || message.includes('make')) {
      return 'To create your first bot:\n\n1. Click "Start Building Now" on the homepage\n2. Drag workflow blocks from the left panel\n3. Connect them together\n4. Configure each block\'s settings\n5. Test your workflow\n6. Deploy when ready!\n\nStart with a "Trigger" block to begin your workflow. Need help with a specific integration?';
    }
    
    if (message.includes('upgrade') || message.includes('plan') || message.includes('pricing')) {
      return 'Our pricing plans:\n\n🆓 **Starter (Free)**: 1 bot, 3K Mixtral tokens, community support\n\n💎 **Maker (₹299/month)**: 5 bots, 20K GPT-4 tokens, AI Agents, Gmail & Notion integration\n\n🚀 **Agency (₹1,999/month)**: Unlimited bots, GPT-4 Pro, white-label, team access, priority support\n\nYou can upgrade anytime from your dashboard. Would you like me to guide you through the upgrade process?';
    }
    
    if (message.includes('gmail') || message.includes('email')) {
      return 'To integrate Gmail:\n\n1. Add a Gmail block to your workflow\n2. Click the Settings icon on the block\n3. Add your Gmail API credentials\n4. Test the connection\n\nFor the Maker plan and above, we provide OAuth integration for easier setup. Need help getting your Gmail API key?';
    }
    
    if (message.includes('notion')) {
      return 'Setting up Notion integration:\n\n1. Create a Notion integration at notion.com/developers\n2. Copy your integration token\n3. Add a Notion block to your workflow\n4. Paste the token in the API Key field\n5. Test the connection\n\nYou can then create pages, update databases, and more! What specific Notion action do you want to automate?';
    }
    
    if (message.includes('telegram') || message.includes('deploy')) {
      return 'To deploy your bot on Telegram:\n\n1. Create a bot with @BotFather on Telegram\n2. Get your bot token\n3. Add a Telegram block to your workflow\n4. Enter your bot token\n5. Click "Deploy" in the workflow canvas\n\nYour bot will be live instantly! You can also deploy to WhatsApp, Discord, and other platforms.';
    }
    
    if (message.includes('token') || message.includes('usage')) {
      return 'Token usage by plan:\n\n• **Free**: 3,000 Mixtral tokens/month\n• **Maker**: 20,000 GPT-4 tokens/month\n• **Agency**: Unlimited tokens\n\nTokens are consumed when AI processes text. Check your usage in the dashboard. Running low? Consider upgrading for more tokens and better AI models!';
    }
    
    if (message.includes('support') || message.includes('help') || message.includes('contact')) {
      return 'Get support:\n\n📧 **Email**: shakibking104@gmail.com\n📚 **Documentation**: Check our docs for detailed guides\n🎥 **Tutorials**: Video tutorials for common tasks\n💬 **Community**: Join our Reddit community\n🔧 **Status**: Check platform status\n\nFor urgent issues, email us directly. What specific problem can I help you solve?';
    }
    
    if (message.includes('hello') || message.includes('hi')) {
      return 'Hello! 👋 Welcome to BOTultima!\n\nI\'m here to help you build amazing AI bots. Whether you\'re just starting or need help with advanced integrations, I\'ve got you covered.\n\nWhat would you like to know about building bots?';
    }
    
    // Default response
    return 'I understand you\'re asking about: "' + userMessage + '"\n\nI can help you with:\n• Creating and building bots\n• Upgrading your plan\n• Setting up integrations (Gmail, Notion, Telegram)\n• Troubleshooting issues\n• Understanding pricing and features\n\nCould you be more specific about what you need help with?';
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputMessage,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    const currentMessage = inputMessage;
    setInputMessage('');
    setIsTyping(true);

    // Get AI response
    const botResponse = await getAIResponse(currentMessage);

    const botMessage: Message = {
      id: (Date.now() + 1).toString(),
      type: 'bot',
      content: botResponse,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, botMessage]);
    setIsTyping(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!isOpen) {
    return (
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setIsOpen(true)}
          className="w-16 h-16 rounded-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 shadow-2xl shadow-green-500/25 border-2 border-green-400/50 group"
        >
          <Bot className="h-8 w-8 text-white group-hover:scale-110 transition-transform" />
          <div className="absolute -top-2 -right-2">
            <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse"></div>
          </div>
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <Card className={`bg-gray-900/95 border-gray-700 backdrop-blur-sm shadow-2xl ${
        isMinimized ? 'w-80 h-16' : 'w-96 h-[500px]'
      } transition-all duration-300`}>
        <CardHeader className="pb-3 border-b border-gray-700">
          <CardTitle className="text-sm text-white flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-emerald-600 rounded-lg flex items-center justify-center">
                <Bot className="h-4 w-4 text-white" />
              </div>
              <span>BOTultima Assistant</span>
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                <Sparkles className="h-3 w-3 mr-1" />
                AI
              </Badge>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsMinimized(!isMinimized)}
                className="h-6 w-6 p-0 text-gray-400 hover:text-white"
              >
                {isMinimized ? <Maximize2 className="h-3 w-3" /> : <Minimize2 className="h-3 w-3" />}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsOpen(false)}
                className="h-6 w-6 p-0 text-gray-400 hover:text-white"
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        
        {!isMinimized && (
          <CardContent className="flex flex-col h-full p-0">
            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-80">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] p-3 rounded-lg ${
                      message.type === 'user'
                        ? 'bg-green-600 text-white'
                        : 'bg-gray-800 text-gray-100 border border-gray-700'
                    }`}
                  >
                    <div className="flex items-center space-x-2 mb-1">
                      {message.type === 'bot' && <Bot className="h-3 w-3 text-green-400" />}
                      <span className="text-xs opacity-75">
                        {message.timestamp.toLocaleTimeString()}
                      </span>
                    </div>
                    <div className="text-sm whitespace-pre-line">{message.content}</div>
                  </div>
                </div>
              ))}
              
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-gray-800 text-gray-100 border border-gray-700 p-3 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Bot className="h-3 w-3 text-green-400" />
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-bounce delay-100"></div>
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-bounce delay-200"></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
            
            {/* Input */}
            <div className="p-4 border-t border-gray-700">
              <div className="flex space-x-2">
                <Input
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask me anything about BOTultima..."
                  className="flex-1 bg-gray-800 border-gray-600 text-white placeholder-gray-400"
                  disabled={isTyping}
                />
                <Button 
                  onClick={handleSendMessage}
                  className="bg-green-600 hover:bg-green-700"
                  disabled={!inputMessage.trim() || isTyping}
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        )}
      </Card>
    </div>
  );
};

export default AISupportAssistant;


import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, X, Zap, Crown, Building, Star, Shield, Rocket } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Pricing = () => {
  const navigate = useNavigate();

  const plans = [
    {
      name: "Starter",
      price: "0",
      currency: "₹",
      description: "Perfect for getting started",
      icon: <Zap className="h-6 w-6" />,
      popular: false,
      color: "gray",
      features: [
        "1 Bot",
        "3,000 Mixtral tokens/month",
        "Basic templates",
        "Community support",
        "Telegram deployment"
      ],
      limitations: [
        "No GPT-4 access",
        "No AI agents",
        "No custom branding",
        "No analytics",
        "Basic support only"
      ]
    },
    {
      name: "Maker",
      price: "299",
      currency: "₹",
      description: "For serious bot creators",
      icon: <Crown className="h-6 w-6" />,
      popular: true,
      color: "green",
      features: [
        "5 Bots",
        "20,000 GPT-4 tokens/month",
        "AI Agent Studio",
        "All platform deployments",
        "Gmail & Notion integration",
        "Advanced templates",
        "Priority support",
        "Analytics dashboard",
        "Custom integrations",
        "API access"
      ],
      limitations: [
        "Limited team collaboration",
        "Basic analytics only"
      ]
    },
    {
      name: "Agency",
      price: "1,999",
      currency: "₹",
      description: "For teams and businesses",
      icon: <Building className="h-6 w-6" />,
      popular: false,
      color: "purple",
      features: [
        "Unlimited bots",
        "Unlimited GPT-4 Pro tokens",
        "White-label solution",
        "Team collaboration",
        "Advanced analytics",
        "Custom onboarding",
        "24/7 priority support",
        "API access",
        "Custom models",
        "Priority features",
        "Dedicated manager",
        "SLA guarantee"
      ],
      limitations: []
    }
  ];

  const allFeatures = [
    "Number of Bots",
    "AI Tokens per Month",
    "GPT-4 Access",
    "AI Agent Studio",
    "Platform Deployments",
    "Templates",
    "Support Level",
    "Analytics",
    "Custom Integrations",
    "API Access",
    "White-label",
    "Team Collaboration",
    "Custom Models",
    "SLA Guarantee"
  ];

  return (
    <section id="pricing" className="py-24 px-4 relative">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <Badge className="bg-green-500/20 text-green-400 border-green-500/30 px-4 py-2 text-sm font-medium rounded-full mb-6">
            <Star className="w-4 h-4 mr-2" />
            Affordable Pricing for India
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-green-400 to-emerald-300 bg-clip-text text-transparent">
            Choose Your Plan
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Start free and scale as you grow. All plans include our core bot building features.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto mb-16">
          {plans.map((plan, index) => (
            <div key={index} className="relative group">
              {/* Glowing Background for Popular Plan */}
              {plan.popular && (
                <div className="absolute -inset-1 bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl blur opacity-75 group-hover:opacity-100 transition duration-300 animate-pulse-glow"></div>
              )}
              
              <Card 
                className={`relative bg-gray-900/50 border-gray-800/50 hover:border-green-500/30 transition-all duration-300 hover:shadow-2xl hover:shadow-green-500/10 ${
                  plan.popular ? 'border-green-500/50 shadow-green-500/20 shadow-xl scale-105 z-10' : ''
                } hover:scale-105 transform`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-20">
                    <Badge className="bg-gradient-to-r from-green-500 to-emerald-600 text-white px-6 py-2 animate-pulse-glow">
                      <Crown className="w-4 h-4 mr-2" />
                      Most Popular
                    </Badge>
                  </div>
                )}
                
                <CardHeader className="text-center pb-8">
                  <div className={`${plan.popular ? 'text-green-400' : 'text-gray-400'} mb-4 flex justify-center`}>
                    {plan.icon}
                  </div>
                  <CardTitle className="text-2xl font-bold text-white mb-2">
                    {plan.name}
                  </CardTitle>
                  <CardDescription className="text-gray-400 mb-6">
                    {plan.description}
                  </CardDescription>
                  <div className="flex items-baseline justify-center">
                    <span className="text-4xl font-bold text-white">{plan.currency}{plan.price}</span>
                    <span className="text-gray-400 ml-2">/month</span>
                  </div>
                </CardHeader>

                <CardContent className="space-y-6">
                  <div className="space-y-3">
                    {plan.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center space-x-3">
                        <Check className="h-5 w-5 text-green-400 flex-shrink-0" />
                        <span className="text-gray-300">{feature}</span>
                      </div>
                    ))}
                  </div>

                  {plan.limitations.length > 0 && (
                    <div className="space-y-3 pt-4 border-t border-gray-800/50">
                      <p className="text-sm text-gray-500 font-medium">Not included:</p>
                      {plan.limitations.map((limitation, limitIndex) => (
                        <div key={limitIndex} className="flex items-center space-x-3">
                          <X className="h-5 w-5 text-gray-500 flex-shrink-0" />
                          <span className="text-gray-500 text-sm">{limitation}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="relative group">
                    {plan.popular && (
                      <div className="absolute -inset-1 bg-gradient-to-r from-green-500 to-emerald-600 rounded-lg blur opacity-75 group-hover:opacity-100 transition duration-300"></div>
                    )}
                    <Button 
                      className={`relative w-full py-6 text-lg font-semibold rounded-lg transition-all duration-300 ${
                        plan.popular 
                          ? 'bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white shadow-lg shadow-green-500/25' 
                          : 'bg-gray-800 hover:bg-gray-700 text-white border border-gray-700 hover:border-green-500/50'
                      }`}
                      onClick={() => navigate('/signup')}
                    >
                      {plan.name === 'Starter' ? (
                        <>
                          <Rocket className="mr-2 h-5 w-5" />
                          Start Free
                        </>
                      ) : (
                        <>
                          <Shield className="mr-2 h-5 w-5" />
                          Get {plan.name}
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>

        {/* Feature Comparison Table */}
        <div className="bg-gray-900/30 rounded-2xl border border-gray-800/50 p-8 backdrop-blur-sm">
          <h3 className="text-2xl font-bold text-center mb-8 text-white">
            Feature Comparison
          </h3>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-700">
                  <th className="text-left py-4 px-4 text-gray-300">Features</th>
                  {plans.map((plan, index) => (
                    <th key={index} className="text-center py-4 px-4">
                      <div className={`text-lg font-semibold ${plan.popular ? 'text-green-400' : 'text-gray-300'}`}>
                        {plan.name}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {allFeatures.map((feature, index) => (
                  <tr key={index} className="border-b border-gray-800/50 hover:bg-gray-800/30 transition-colors">
                    <td className="py-3 px-4 text-gray-300">{feature}</td>
                    <td className="py-3 px-4 text-center">
                      {feature === "Number of Bots" ? "1" : 
                       feature === "AI Tokens per Month" ? "3K Mixtral" :
                       feature === "GPT-4 Access" ? <X className="h-5 w-5 text-red-400 mx-auto" /> :
                       feature === "Support Level" ? "Community" :
                       feature === "Platform Deployments" ? "Telegram" :
                       feature === "Templates" ? "Basic" :
                       <Check className="h-5 w-5 text-green-400 mx-auto" />}
                    </td>
                    <td className="py-3 px-4 text-center">
                      {feature === "Number of Bots" ? "5" : 
                       feature === "AI Tokens per Month" ? "20K GPT-4" :
                       feature === "Support Level" ? "Priority" :
                       feature === "Platform Deployments" ? "All Platforms" :
                       feature === "Templates" ? "Advanced" :
                       feature === "Team Collaboration" ? "Limited" :
                       feature === "Analytics" ? "Basic" :
                       feature === "Custom Models" ? <X className="h-5 w-5 text-red-400 mx-auto" /> :
                       feature === "SLA Guarantee" ? <X className="h-5 w-5 text-red-400 mx-auto" /> :
                       <Check className="h-5 w-5 text-green-400 mx-auto" />}
                    </td>
                    <td className="py-3 px-4 text-center">
                      {feature === "Number of Bots" ? "Unlimited" : 
                       feature === "AI Tokens per Month" ? "Unlimited GPT-4 Pro" :
                       feature === "Support Level" ? "24/7 Dedicated" :
                       feature === "Platform Deployments" ? "All + Custom" :
                       feature === "Templates" ? "Premium + Custom" :
                       feature === "Team Collaboration" ? "Full" :
                       feature === "Analytics" ? "Advanced" :
                       <Check className="h-5 w-5 text-green-400 mx-auto" />}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="text-center mt-16">
          <p className="text-gray-400 mb-6">
            All plans include 14-day free trial • No setup fees • Cancel anytime
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-green-500/50 to-emerald-600/50 rounded-lg blur opacity-50 group-hover:opacity-75 transition duration-300"></div>
              <Button 
                variant="outline" 
                className="relative border-green-500/50 text-green-400 hover:bg-green-500/10"
              >
                View Full Comparison
              </Button>
            </div>
            <Button 
              variant="ghost" 
              className="text-gray-400 hover:text-green-400"
            >
              Contact Sales
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Pricing;

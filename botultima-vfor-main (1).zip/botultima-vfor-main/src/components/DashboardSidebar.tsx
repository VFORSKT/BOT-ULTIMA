
import { useState, useEffect } from "react";
import { useUser } from "@clerk/clerk-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Bot, 
  Brain, 
  BarChart3, 
  Users, 
  Settings, 
  HelpCircle, 
  LogOut,
  Home,
  Store,
  BookOpen,
  CreditCard,
  User,
  ChevronLeft,
  ChevronRight,
  Shield,
  Zap,
  Workflow
} from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

const DashboardSidebar = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const { user, isLoaded } = useUser();
  const navigate = useNavigate();
  const location = useLocation();

  // Check if user is admin
  useEffect(() => {
    const checkAdminStatus = async () => {
      if (!isLoaded || !user) return;

      try {
        const { data: profile, error } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', user.id)
          .single();

        if (!error && profile?.role === 'admin') {
          setIsAdmin(true);
        }
      } catch (error) {
        console.error('Error checking admin status:', error);
      }
    };

    checkAdminStatus();
  }, [user, isLoaded]);

  const menuItems = [
    { icon: <Home className="h-5 w-5" />, label: "Dashboard", path: "/dashboard" },
    { icon: <Bot className="h-5 w-5" />, label: "My Bots", path: "/my-bots", count: 2 },
    { icon: <Brain className="h-5 w-5" />, label: "AI Agents", path: "/agents", badge: "NEW" },
    { icon: <Workflow className="h-5 w-5" />, label: "Enhanced Builder", path: "/enhanced-builder", badge: "PRO" },
    { icon: <Store className="h-5 w-5" />, label: "Marketplace", path: "/marketplace" },
    { icon: <BarChart3 className="h-5 w-5" />, label: "Analytics", path: "/analytics" },
    { icon: <BookOpen className="h-5 w-5" />, label: "Tutorials", path: "/tutorials" },
    { icon: <Zap className="h-5 w-5" />, label: "Token Usage", path: "/token-usage" },
  ];

  const bottomItems = [
    { icon: <CreditCard className="h-5 w-5" />, label: "Subscription", path: "/pricing" },
    { icon: <Settings className="h-5 w-5" />, label: "Settings", path: "/settings" },
    { icon: <HelpCircle className="h-5 w-5" />, label: "Help", path: "/help" },
    // Only show admin panel if user is admin
    ...(isAdmin ? [{ icon: <Shield className="h-5 w-5" />, label: "Admin", path: "/admin" }] : []),
  ];

  // Get user plan from metadata with proper type safety
  const userPlan = (user?.unsafeMetadata?.plan as string) || 'Free';

  const isActivePath = (path: string) => {
    return location.pathname === path;
  };

  return (
    <div className={`fixed left-0 top-0 h-full bg-gray-900/90 backdrop-blur-lg border-r border-gray-800/50 transition-all duration-300 z-50 ${
      isCollapsed ? 'w-16' : 'w-64'
    }`}>
      {/* Header */}
      <div className="p-4 border-b border-gray-800/50">
        <div className="flex items-center justify-between">
          {!isCollapsed && (
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 flex items-center justify-center">
                <img 
                  src="/lovable-uploads/f2491956-759e-4c19-9f30-9178527e8e54.png" 
                  alt="SixMorph Logo" 
                  className="w-8 h-8 object-contain"
                />
              </div>
              <div>
                <div className="text-sm font-semibold text-white">SixMorph</div>
                <div className="text-xs text-gray-400">by VFOR</div>
              </div>
            </div>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="text-gray-400 hover:text-white"
          >
            {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      {/* User Info */}
      {!isCollapsed && isLoaded && (
        <div className="p-4 border-b border-gray-800/50">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center">
              {user?.imageUrl ? (
                <img 
                  src={user.imageUrl} 
                  alt="Profile" 
                  className="w-10 h-10 rounded-full object-cover"
                />
              ) : (
                <User className="h-5 w-5 text-white" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-white truncate">
                {user?.firstName || user?.fullName || 'User'}
              </div>
              <div className="text-xs text-gray-400">{userPlan} Plan</div>
            </div>
          </div>
          
          {/* Token Usage */}
          <div className="mt-4 p-3 bg-gray-800/50 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-gray-400">Token Usage</span>
              <span className="text-xs text-green-400">8.5K / 20K</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div className="bg-gradient-to-r from-green-500 to-emerald-600 h-2 rounded-full" style={{width: '42.5%'}}></div>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto">
        <div className="p-2">
          {menuItems.map((item, index) => (
            <button
              key={index}
              onClick={() => navigate(item.path)}
              className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-all duration-200 mb-1 group ${
                isActivePath(item.path)
                  ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
                  : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
              }`}
            >
              <div className={`${isActivePath(item.path) ? 'text-green-400' : 'text-gray-400 group-hover:text-white'} transition-colors`}>
                {item.icon}
              </div>
              {!isCollapsed && (
                <>
                  <span className="flex-1 text-left text-sm font-medium">{item.label}</span>
                  {item.count && (
                    <Badge className="bg-gray-700 text-gray-300 text-xs">
                      {item.count}
                    </Badge>
                  )}
                  {item.badge && (
                    <Badge className="bg-green-500 text-white text-xs">
                      {item.badge}
                    </Badge>
                  )}
                </>
              )}
            </button>
          ))}
        </div>
      </nav>

      {/* Bottom Section */}
      <div className="border-t border-gray-800/50 p-2">
        {bottomItems.map((item, index) => (
          <button
            key={index}
            onClick={() => navigate(item.path)}
            className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-all duration-200 mb-1 group ${
              isActivePath(item.path)
                ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
                : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
            }`}
          >
            <div className={`${isActivePath(item.path) ? 'text-green-400' : 'text-gray-400 group-hover:text-white'} transition-colors`}>
              {item.icon}
            </div>
            {!isCollapsed && (
              <span className="flex-1 text-left text-sm font-medium">{item.label}</span>
            )}
          </button>
        ))}
        
        <button className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-all duration-200 group">
          <LogOut className="h-5 w-5" />
          {!isCollapsed && (
            <span className="flex-1 text-left text-sm font-medium">Sign Out</span>
          )}
        </button>
      </div>
    </div>
  );
};

export default DashboardSidebar;

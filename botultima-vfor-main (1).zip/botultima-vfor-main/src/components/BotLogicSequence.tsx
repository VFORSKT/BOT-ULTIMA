
import { useEffect, useState } from "react";
import { MessageSquare, Brain, Bot, Send, ArrowRight } from "lucide-react";

const BotLogicSequence = () => {
  const [activeStep, setActiveStep] = useState(-1);

  const steps = [
    { icon: MessageSquare, title: "Trigger", color: "from-blue-400 to-blue-600" },
    { icon: Brain, title: "GPT", color: "from-purple-400 to-purple-600" },
    { icon: Bot, title: "Process", color: "from-green-400 to-green-600" },
    { icon: Send, title: "Reply", color: "from-emerald-400 to-emerald-600" },
  ];

  useEffect(() => {
    const sequence = async () => {
      // Reset
      setActiveStep(-1);
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Animate each step
      for (let i = 0; i < steps.length; i++) {
        setActiveStep(i);
        await new Promise(resolve => setTimeout(resolve, 800));
      }

      // Hold for a moment then restart
      await new Promise(resolve => setTimeout(resolve, 2000));
      sequence();
    };

    sequence();
  }, []);

  return (
    <div className="flex items-center justify-center space-x-4 p-6 rounded-xl bg-gray-900/30 border border-green-500/20 backdrop-blur-sm">
      {steps.map((step, index) => {
        const Icon = step.icon;
        const isActive = index <= activeStep;
        const isCurrent = index === activeStep;
        
        return (
          <div key={index} className="flex items-center space-x-4">
            {/* Step Block */}
            <div
              className={`relative p-4 rounded-lg border-2 transition-all duration-500 transform ${
                isActive 
                  ? `border-green-400/50 bg-gradient-to-r ${step.color} scale-110 shadow-lg` 
                  : 'border-gray-600/50 bg-gray-800/50 scale-100'
              } ${isCurrent ? 'animate-bounce' : ''}`}
              style={{
                animationDuration: isCurrent ? '0.6s' : undefined,
                animationIterationCount: isCurrent ? '2' : undefined,
              }}
            >
              {/* Neon glow effect */}
              {isActive && (
                <div className="absolute -inset-1 bg-gradient-to-r from-green-400/30 to-cyan-400/30 rounded-lg blur-sm"></div>
              )}
              
              <div className="relative flex items-center space-x-2">
                <Icon className={`w-5 h-5 transition-colors duration-300 ${
                  isActive ? 'text-white' : 'text-gray-400'
                }`} />
                <span className={`font-semibold text-sm transition-colors duration-300 ${
                  isActive ? 'text-white' : 'text-gray-400'
                }`}>
                  {step.title}
                </span>
              </div>

              {/* Pulsing dot indicator */}
              {isCurrent && (
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-ping"></div>
              )}
            </div>

            {/* Arrow Connector */}
            {index < steps.length - 1 && (
              <div className={`transition-all duration-500 ${
                index < activeStep ? 'opacity-100' : 'opacity-30'
              }`}>
                <ArrowRight className={`w-6 h-6 transition-colors duration-500 ${
                  index < activeStep ? 'text-green-400' : 'text-gray-600'
                }`} />
                
                {/* Animated line */}
                {index < activeStep && (
                  <div className="absolute w-6 h-0.5 bg-gradient-to-r from-green-400 to-cyan-400 animate-pulse"></div>
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default BotLogicSequence;

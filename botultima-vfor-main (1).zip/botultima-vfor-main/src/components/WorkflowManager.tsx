
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Edit, Trash2, Play, Workflow, Save } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './AuthenticationManager';
import { useToast } from '@/hooks/use-toast';

interface WorkflowData {
  id: string;
  name: string;
  description: string;
  category: string;
  flow_data: any;
  is_published: boolean;
  created_at: string;
  updated_at: string;
}

const WorkflowManager = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [workflows, setWorkflows] = useState<WorkflowData[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingWorkflow, setEditingWorkflow] = useState<WorkflowData | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'general'
  });

  useEffect(() => {
    if (user) {
      loadWorkflows();
    }
  }, [user]);

  const loadWorkflows = async () => {
    try {
      const { data, error } = await supabase
        .from('workflows')
        .select('*')
        .eq('user_id', user?.id)
        .order('updated_at', { ascending: false });

      if (error) throw error;
      setWorkflows(data || []);
    } catch (error) {
      console.error('Error loading workflows:', error);
      toast({
        title: "Error",
        description: "Failed to load workflows",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateWorkflow = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('workflows')
        .insert({
          user_id: user.id,
          name: formData.name,
          description: formData.description,
          category: formData.category,
          flow_data: { nodes: [], edges: [] },
          is_published: false
        })
        .select()
        .single();

      if (error) throw error;

      setWorkflows([data, ...workflows]);
      setIsDialogOpen(false);
      setFormData({ name: '', description: '', category: 'general' });
      
      toast({
        title: "Workflow Created",
        description: "Your new workflow has been created successfully.",
      });
    } catch (error) {
      console.error('Error creating workflow:', error);
      toast({
        title: "Creation Failed",
        description: "Failed to create workflow. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleUpdateWorkflow = async () => {
    if (!editingWorkflow || !user) return;

    try {
      const { data, error } = await supabase
        .from('workflows')
        .update({
          name: formData.name,
          description: formData.description,
          category: formData.category,
          updated_at: new Date().toISOString()
        })
        .eq('id', editingWorkflow.id)
        .eq('user_id', user.id)
        .select()
        .single();

      if (error) throw error;

      setWorkflows(workflows.map(w => w.id === editingWorkflow.id ? data : w));
      setEditingWorkflow(null);
      setIsDialogOpen(false);
      setFormData({ name: '', description: '', category: 'general' });
      
      toast({
        title: "Workflow Updated",
        description: "Your workflow has been updated successfully.",
      });
    } catch (error) {
      console.error('Error updating workflow:', error);
      toast({
        title: "Update Failed",
        description: "Failed to update workflow. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleDeleteWorkflow = async (workflowId: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('workflows')
        .delete()
        .eq('id', workflowId)
        .eq('user_id', user.id);

      if (error) throw error;

      setWorkflows(workflows.filter(w => w.id !== workflowId));
      
      toast({
        title: "Workflow Deleted",
        description: "Your workflow has been deleted successfully.",
      });
    } catch (error) {
      console.error('Error deleting workflow:', error);
      toast({
        title: "Deletion Failed",
        description: "Failed to delete workflow. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handlePublishWorkflow = async (workflowId: string, isPublished: boolean) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('workflows')
        .update({
          is_published: !isPublished,
          updated_at: new Date().toISOString()
        })
        .eq('id', workflowId)
        .eq('user_id', user.id);

      if (error) throw error;

      setWorkflows(workflows.map(w => 
        w.id === workflowId ? { ...w, is_published: !isPublished } : w
      ));
      
      toast({
        title: isPublished ? "Workflow Unpublished" : "Workflow Published",
        description: `Your workflow has been ${isPublished ? 'unpublished' : 'published'} successfully.`,
      });
    } catch (error) {
      console.error('Error publishing workflow:', error);
      toast({
        title: "Update Failed",
        description: "Failed to update workflow status. Please try again.",
        variant: "destructive",
      });
    }
  };

  const openCreateDialog = () => {
    setEditingWorkflow(null);
    setFormData({ name: '', description: '', category: 'general' });
    setIsDialogOpen(true);
  };

  const openEditDialog = (workflow: WorkflowData) => {
    setEditingWorkflow(workflow);
    setFormData({
      name: workflow.name,
      description: workflow.description || '',
      category: workflow.category
    });
    setIsDialogOpen(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin h-8 w-8 border-2 border-green-400 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">My Workflows</h2>
          <p className="text-gray-400">Create and manage your automation workflows</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openCreateDialog} className="bg-green-600 hover:bg-green-700">
              <Plus className="h-4 w-4 mr-2" />
              Create Workflow
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-gray-800 border-gray-700">
            <DialogHeader>
              <DialogTitle className="text-white">
                {editingWorkflow ? 'Edit Workflow' : 'Create New Workflow'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-300">Name</label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                  placeholder="Enter workflow name"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-300">Description</label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="bg-gray-700 border-gray-600 text-white"
                  placeholder="Describe your workflow"
                  rows={3}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-300">Category</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-white"
                >
                  <option value="general">General</option>
                  <option value="automation">Automation</option>
                  <option value="data-processing">Data Processing</option>
                  <option value="communication">Communication</option>
                  <option value="analytics">Analytics</option>
                </select>
              </div>
              <div className="flex justify-end space-x-2">
                <Button
                  variant="outline"
                  onClick={() => setIsDialogOpen(false)}
                  className="border-gray-600 text-gray-300"
                >
                  Cancel
                </Button>
                <Button
                  onClick={editingWorkflow ? handleUpdateWorkflow : handleCreateWorkflow}
                  className="bg-green-600 hover:bg-green-700"
                  disabled={!formData.name.trim()}
                >
                  <Save className="h-4 w-4 mr-2" />
                  {editingWorkflow ? 'Update' : 'Create'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Workflows Grid */}
      {workflows.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {workflows.map((workflow) => (
            <Card key={workflow.id} className="bg-gray-800/50 border-gray-700 hover:border-green-500/50 transition-colors">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-white text-lg mb-1">{workflow.name}</CardTitle>
                    <p className="text-gray-300 text-sm line-clamp-2">{workflow.description || 'No description'}</p>
                  </div>
                  <Badge className={workflow.is_published ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}>
                    {workflow.is_published ? 'Published' : 'Draft'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-xs text-gray-500">
                  <div>Category: {workflow.category}</div>
                  <div>Created: {new Date(workflow.created_at).toLocaleDateString()}</div>
                  <div>Updated: {new Date(workflow.updated_at).toLocaleDateString()}</div>
                </div>
                
                <div className="flex space-x-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => openEditDialog(workflow)}
                    className="flex-1 border-gray-600 hover:border-blue-500"
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    Edit
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => handlePublishWorkflow(workflow.id, workflow.is_published)}
                    className={`flex-1 ${workflow.is_published ? 'bg-yellow-600 hover:bg-yellow-700' : 'bg-green-600 hover:bg-green-700'}`}
                  >
                    <Play className="h-4 w-4 mr-2" />
                    {workflow.is_published ? 'Unpublish' : 'Publish'}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleDeleteWorkflow(workflow.id)}
                    className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-12 text-center">
            <Workflow className="h-16 w-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-400 mb-4">No Workflows Yet</h3>
            <p className="text-gray-500 mb-6">Create your first workflow to get started with automation.</p>
            <Button onClick={openCreateDialog} className="bg-green-600 hover:bg-green-700">
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Workflow
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default WorkflowManager;

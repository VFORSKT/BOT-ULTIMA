
import { supabase } from "@/integrations/supabase/client";

export class DatabaseService {
  // Generic query builder for safe database operations
  static async executeQuery(table: string, operation: 'select' | 'insert' | 'update' | 'delete', options: any = {}) {
    try {
      let query: any = supabase.from(table as any);

      switch (operation) {
        case 'select':
          query = query.select(options.columns || '*');
          if (options.filters) {
            Object.entries(options.filters).forEach(([key, value]) => {
              query = query.eq(key, value);
            });
          }
          if (options.order) {
            query = query.order(options.order.column, { ascending: options.order.ascending });
          }
          if (options.limit) {
            query = query.limit(options.limit);
          }
          break;

        case 'insert':
          query = query.insert(options.data);
          break;

        case 'update':
          query = query.update(options.data);
          if (options.filters) {
            Object.entries(options.filters).forEach(([key, value]) => {
              query = query.eq(key, value);
            });
          }
          break;

        case 'delete':
          if (options.filters) {
            Object.entries(options.filters).forEach(([key, value]) => {
              query = query.eq(key, value);
            });
          }
          query = query.delete();
          break;
      }

      const { data, error } = await query;

      if (error) {
        console.error(`Database ${operation} error:`, error);
        return { success: false, error: error.message, data: null };
      }

      return { success: true, data, error: null };
    } catch (error) {
      console.error(`Database service error:`, error);
      return { success: false, error: 'Database operation failed', data: null };
    }
  }

  // User-specific data operations
  static async getUserData(userId: string, table: string, columns: string = '*') {
    return this.executeQuery(table, 'select', {
      columns,
      filters: { user_id: userId },
      order: { column: 'created_at', ascending: false }
    });
  }

  static async createUserData(userId: string, table: string, data: any) {
    return this.executeQuery(table, 'insert', {
      data: { ...data, user_id: userId }
    });
  }

  static async updateUserData(userId: string, table: string, id: string, data: any) {
    return this.executeQuery(table, 'update', {
      data: { ...data, updated_at: new Date().toISOString() },
      filters: { id, user_id: userId }
    });
  }

  static async deleteUserData(userId: string, table: string, id: string) {
    return this.executeQuery(table, 'delete', {
      filters: { id, user_id: userId }
    });
  }

  // Analytics and reporting
  static async getTableStats(table: string) {
    try {
      const { count, error } = await supabase
        .from(table as any)
        .select('*', { count: 'exact', head: true });

      if (error) {
        console.error(`Error getting ${table} stats:`, error);
        return { count: 0, error: error.message };
      }

      return { count: count || 0, error: null };
    } catch (error) {
      console.error('Database stats error:', error);
      return { count: 0, error: 'Failed to fetch stats' };
    }
  }

  // Cleanup operations
  static async cleanupExpiredData() {
    try {
      // Clean up expired tokens, sessions, etc.
      const { error } = await supabase.rpc('cleanup_expired_tokens');

      if (error) {
        console.error('Cleanup error:', error);
        return { success: false, error: error.message };
      }

      return { success: true };
    } catch (error) {
      console.error('Cleanup service error:', error);
      return { success: false, error: 'Cleanup operation failed' };
    }
  }

  // API usage logging
  static async logApiUsage(endpoint: string, method: string, statusCode?: number, responseTime?: number) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) return;

      await supabase.rpc('log_api_usage', {
        p_user_id: user.id,
        p_endpoint: endpoint,
        p_method: method,
        p_status_code: statusCode,
        p_response_time_ms: responseTime
      });
    } catch (error) {
      console.error('Error logging API usage:', error);
    }
  }

  // Security audit logging
  static async logSecurityEvent(eventType: string, details: any = {}) {
    try {
      const { data: { user } } = await supabase.auth.getUser();

      await supabase.rpc('log_security_event', {
        p_user_id: user?.id || null,
        p_event_type: eventType,
        p_ip_address: null, // IP detection would need server-side implementation
        p_user_agent: navigator.userAgent,
        p_details: details
      });
    } catch (error) {
      console.error('Error logging security event:', error);
    }
  }

  // Batch operations
  static async batchInsert(table: string, records: any[]) {
    try {
      const { data, error } = await supabase
        .from(table as any)
        .insert(records);

      if (error) {
        console.error(`Batch insert error for ${table}:`, error);
        return { success: false, error: error.message, data: null };
      }

      return { success: true, data, error: null };
    } catch (error) {
      console.error('Batch insert service error:', error);
      return { success: false, error: 'Batch operation failed', data: null };
    }
  }

  static async batchUpdate(table: string, updates: Array<{ id: string; data: any }>) {
    try {
      const promises = updates.map(update =>
        supabase
          .from(table as any)
          .update(update.data)
          .eq('id', update.id)
      );

      const results = await Promise.all(promises);
      const errors = results.filter(result => result.error);

      if (errors.length > 0) {
        console.error(`Batch update errors for ${table}:`, errors);
        return { success: false, error: 'Some updates failed', data: null };
      }

      return { success: true, data: results.map(r => r.data), error: null };
    } catch (error) {
      console.error('Batch update service error:', error);
      return { success: false, error: 'Batch operation failed', data: null };
    }
  }
}

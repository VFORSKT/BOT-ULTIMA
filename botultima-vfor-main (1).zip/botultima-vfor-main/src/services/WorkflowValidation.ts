
import { WorkflowNode, WorkflowEdge, ValidationResult } from '@/types/WorkflowTypes';

export class WorkflowValidator {
  static validateWorkflow(nodes: WorkflowNode[], edges: WorkflowEdge[]): ValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    // Check if workflow has a trigger
    const triggerNodes = nodes.filter(node => 
      node.data.type === 'trigger' || node.data.type === 'webhook'
    );
    
    if (triggerNodes.length === 0) {
      errors.push('Workflow must have at least one trigger or webhook node');
    }

    if (triggerNodes.length > 1) {
      warnings.push('Multiple trigger nodes detected - only the first will execute');
    }

    // Check for orphaned nodes
    const connectedNodeIds = new Set();
    edges.forEach(edge => {
      connectedNodeIds.add(edge.source);
      connectedNodeIds.add(edge.target);
    });

    const orphanedNodes = nodes.filter(node => 
      !connectedNodeIds.has(node.id) && node.data.type !== 'trigger'
    );

    if (orphanedNodes.length > 0) {
      warnings.push(`${orphanedNodes.length} unconnected nodes found`);
    }

    // Check for circular dependencies
    const circularPaths = this.findCircularDependencies(nodes, edges);
    if (circularPaths.length > 0) {
      errors.push('Circular dependencies detected in workflow');
    }

    // Validate individual nodes
    nodes.forEach(node => {
      const nodeErrors = this.validateNode(node);
      errors.push(...nodeErrors);
    });

    // Check for invalid connections
    edges.forEach(edge => {
      const sourceNode = nodes.find(n => n.id === edge.source);
      const targetNode = nodes.find(n => n.id === edge.target);
      
      if (!sourceNode || !targetNode) {
        errors.push(`Invalid connection: ${edge.id}`);
        return;
      }

      const connectionErrors = this.validateConnection(sourceNode, targetNode);
      errors.push(...connectionErrors);
    });

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }

  static validateNode(node: WorkflowNode): string[] {
    const errors: string[] = [];
    const { type, config } = node.data;

    switch (type) {
      case 'gpt':
      case 'qwen':
      case 'deepseek':
      case 'mixtral':
        if (!config?.prompt) {
          errors.push(`${node.data.label}: AI prompt is required`);
        }
        break;

      case 'http-request':
      case 'api':
        if (!config?.apiUrl) {
          errors.push(`${node.data.label}: API URL is required`);
        }
        break;

      case 'gmail':
      case 'telegram':
      case 'slack':
      case 'discord':
        if (!config?.apiKey) {
          errors.push(`${node.data.label}: API key is required`);
        }
        break;

      case 'google-sheets-reader':
        if (!config?.spreadsheetId) {
          errors.push(`${node.data.label}: Spreadsheet ID is required`);
        }
        break;

      case 'discord-webhook':
        if (!config?.webhookUrl) {
          errors.push(`${node.data.label}: Webhook URL is required`);
        }
        break;

      case 'custom-code-runner':
        if (!config?.jsCode) {
          errors.push(`${node.data.label}: JavaScript code is required`);
        }
        break;

      case 'mysql-db':
      case 'postgresql-db':
        if (!config?.connectionString && !config?.host) {
          errors.push(`${node.data.label}: Database connection details are required`);
        }
        if (!config?.query) {
          errors.push(`${node.data.label}: SQL query is required`);
        }
        break;

      case 'email-sender':
        if (!config?.fromEmail || !config?.toEmail) {
          errors.push(`${node.data.label}: Email addresses are required`);
        }
        if (!config?.subject || !config?.emailBody) {
          errors.push(`${node.data.label}: Email subject and body are required`);
        }
        break;

      case 'condition':
        if (!config?.conditions) {
          errors.push(`${node.data.label}: Condition logic is required`);
        }
        break;
    }

    return errors;
  }

  static validateConnection(sourceNode: WorkflowNode, targetNode: WorkflowNode): string[] {
    const errors: string[] = [];

    // End nodes cannot have outgoing connections
    if (sourceNode.data.type === 'end') {
      errors.push(`End node cannot have outgoing connections`);
    }

    // Trigger nodes cannot have incoming connections
    if (targetNode.data.type === 'trigger' || targetNode.data.type === 'webhook') {
      errors.push(`Trigger nodes cannot have incoming connections`);
    }

    // Some nodes require specific input types
    if (targetNode.data.category === 'ai' && sourceNode.data.category === 'database') {
      // This is fine - database can feed into AI
    }

    return errors;
  }

  static findCircularDependencies(nodes: WorkflowNode[], edges: WorkflowEdge[]): string[] {
    const visited = new Set<string>();
    const recStack = new Set<string>();
    const cycles: string[] = [];

    const dfs = (nodeId: string, path: string[]): boolean => {
      if (recStack.has(nodeId)) {
        cycles.push(`Circular dependency: ${path.join(' -> ')} -> ${nodeId}`);
        return true;
      }

      if (visited.has(nodeId)) {
        return false;
      }

      visited.add(nodeId);
      recStack.add(nodeId);

      const outgoingEdges = edges.filter(edge => edge.source === nodeId);
      for (const edge of outgoingEdges) {
        if (dfs(edge.target, [...path, nodeId])) {
          return true;
        }
      }

      recStack.delete(nodeId);
      return false;
    };

    nodes.forEach(node => {
      if (!visited.has(node.id)) {
        dfs(node.id, []);
      }
    });

    return cycles;
  }
}

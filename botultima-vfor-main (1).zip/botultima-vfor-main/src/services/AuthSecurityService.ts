
import { supabase } from "@/integrations/supabase/client";
import { SecurityService } from "./SecurityService";

export interface SecurityContext {
  ipAddress?: string;
  userAgent?: string;
  sessionId?: string;
}

export class AuthSecurityService {
  private static sessionContext: SecurityContext = {};

  // Initialize security context
  static initializeSecurityContext() {
    this.sessionContext = {
      userAgent: navigator.userAgent,
      sessionId: SecurityService.generateSessionId()
    };
  }

  // Enhanced sign in with security features
  static async signIn(email: string, password: string): Promise<{
    success: boolean;
    error?: string;
    requiresTwoFactor?: boolean;
  }> {
    const rateLimitKey = `signin_${email}`;
    
    try {
      // Check rate limiting
      const { data: rateLimitCheck } = await supabase.rpc('check_rate_limit', {
        p_identifier: rateLimitKey,
        p_endpoint: 'signin',
        p_max_attempts: 5
      });

      if (!rateLimitCheck) {
        await this.logSecurityEvent('rate_limit_exceeded', {
          endpoint: 'signin',
          email: email
        });
        return {
          success: false,
          error: 'Too many login attempts. Please try again later.'
        };
      }

      // Attempt sign in
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        // Log failed attempt
        await this.logSecurityEvent('signin_failed', {
          email: email,
          error: error.message
        });

        return {
          success: false,
          error: error.message
        };
      }

      if (data.user) {
        // Log successful sign in
        await this.logSecurityEvent('signin_success', {
          userId: data.user.id,
          email: data.user.email
        }, data.user.id);

        return { success: true };
      }

      return {
        success: false,
        error: 'Sign in failed'
      };

    } catch (error) {
      console.error('Sign in error:', error);
      return {
        success: false,
        error: 'An unexpected error occurred'
      };
    }
  }

  // Enhanced sign up with security features
  static async signUp(email: string, password: string, additionalData?: any): Promise<{
    success: boolean;
    error?: string;
    needsVerification?: boolean;
  }> {
    const rateLimitKey = `signup_${email}`;

    try {
      // Validate password strength
      const passwordValidation = SecurityService.validatePassword(password);
      if (!passwordValidation.isValid) {
        return {
          success: false,
          error: passwordValidation.errors.join('. ')
        };
      }

      // Check rate limiting
      const { data: rateLimitCheck } = await supabase.rpc('check_rate_limit', {
        p_identifier: rateLimitKey,
        p_endpoint: 'signup',
        p_max_attempts: 3
      });

      if (!rateLimitCheck) {
        return {
          success: false,
          error: 'Too many signup attempts. Please try again later.'
        };
      }

      // Attempt sign up
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: additionalData,
          emailRedirectTo: `${window.location.origin}/auth`
        }
      });

      if (error) {
        await this.logSecurityEvent('signup_failed', {
          email: email,
          error: error.message
        });

        return {
          success: false,
          error: error.message
        };
      }

      if (data.user) {
        await this.logSecurityEvent('signup_success', {
          userId: data.user.id,
          email: data.user.email
        }, data.user.id);

        return {
          success: true,
          needsVerification: !data.session
        };
      }

      return {
        success: false,
        error: 'Sign up failed'
      };

    } catch (error) {
      console.error('Sign up error:', error);
      return {
        success: false,
        error: 'An unexpected error occurred'
      };
    }
  }

  // Log security events
  private static async logSecurityEvent(
    eventType: string,
    details: Record<string, any>,
    userId?: string
  ) {
    try {
      await supabase.rpc('log_security_event', {
        p_user_id: userId || null,
        p_event_type: eventType,
        p_ip_address: null, // IP detection would need server-side implementation
        p_user_agent: this.sessionContext.userAgent,
        p_details: details
      });
    } catch (error) {
      console.error('Failed to log security event:', error);
    }
  }

  // Check if user account is locked
  static async checkAccountSecurity(userId: string): Promise<{
    isLocked: boolean;
    lockReason?: string;
  }> {
    try {
      const { data: recentEvents } = await supabase
        .from('security_audit_logs')
        .select('event_type, created_at')
        .eq('user_id', userId)
        .gte('created_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString())
        .order('created_at', { ascending: false });

      if (recentEvents) {
        const failedAttempts = recentEvents.filter(
          event => event.event_type === 'signin_failed'
        ).length;

        if (failedAttempts >= 10) {
          return {
            isLocked: true,
            lockReason: 'Too many failed login attempts in the last 24 hours'
          };
        }
      }

      return { isLocked: false };
    } catch (error) {
      console.error('Failed to check account security:', error);
      return { isLocked: false };
    }
  }

  // Enhanced sign out with security logging
  static async signOut(): Promise<{ success: boolean; error?: string }> {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        await this.logSecurityEvent('signout', {
          userId: user.id
        }, user.id);
      }

      const { error } = await supabase.auth.signOut();
      
      if (error) {
        return {
          success: false,
          error: error.message
        };
      }

      return { success: true };
    } catch (error) {
      console.error('Sign out error:', error);
      return {
        success: false,
        error: 'An unexpected error occurred'
      };
    }
  }

  // Generate secure password reset token
  static async requestPasswordReset(email: string): Promise<{
    success: boolean;
    error?: string;
  }> {
    const rateLimitKey = `password_reset_${email}`;

    try {
      // Check rate limiting
      const { data: rateLimitCheck } = await supabase.rpc('check_rate_limit', {
        p_identifier: rateLimitKey,
        p_endpoint: 'password_reset',
        p_max_attempts: 3,
        p_window_minutes: 60
      });

      if (!rateLimitCheck) {
        return {
          success: false,
          error: 'Too many password reset requests. Please try again later.'
        };
      }

      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/auth?reset=true`
      });

      if (error) {
        await this.logSecurityEvent('password_reset_failed', {
          email: email,
          error: error.message
        });

        return {
          success: false,
          error: error.message
        };
      }

      await this.logSecurityEvent('password_reset_requested', {
        email: email
      });

      return { success: true };
    } catch (error) {
      console.error('Password reset error:', error);
      return {
        success: false,
        error: 'An unexpected error occurred'
      };
    }
  }
}


import { supabase } from "@/integrations/supabase/client";

export interface UserStats {
  totalUsers: number;
  activeUsers: number;
  newUsersToday: number;
  totalLogins: number;
}

export interface UserActivity {
  userId: string;
  username: string;
  email: string;
  lastLogin: string;
  loginCount: number;
  plan: string;
  isActive: boolean;
}

export class UserManagementService {
  // Get user statistics (admin only)
  static async getUserStats(): Promise<UserStats> {
    try {
      // Get total users
      const { count: totalUsers } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true });

      // Get active users (logged in within last 30 days)
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

      const { count: activeUsers } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })
        .gte('last_login_at', thirtyDaysAgo.toISOString());

      // Get new users today
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const { count: newUsersToday } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })
        .gte('created_at', today.toISOString());

      // Get total logins
      const { data: loginData } = await supabase
        .from('profiles')
        .select('login_count');

      const totalLogins = loginData?.reduce((sum, user) => sum + (user.login_count || 0), 0) || 0;

      return {
        totalUsers: totalUsers || 0,
        activeUsers: activeUsers || 0,
        newUsersToday: newUsersToday || 0,
        totalLogins
      };
    } catch (error) {
      console.error('Error fetching user stats:', error);
      return {
        totalUsers: 0,
        activeUsers: 0,
        newUsersToday: 0,
        totalLogins: 0
      };
    }
  }

  // Get user activity data (admin only)
  static async getUserActivity(limit: number = 50): Promise<UserActivity[]> {
    try {
      const { data: users, error } = await supabase
        .from('profiles')
        .select('id, username, email, last_login_at, login_count, plan')
        .order('last_login_at', { ascending: false, nullsFirst: false })
        .limit(limit);

      if (error) {
        console.error('Error fetching user activity:', error);
        return [];
      }

      return users?.map(user => ({
        userId: user.id,
        username: user.username || 'Unknown',
        email: user.email || 'No email',
        lastLogin: user.last_login_at || 'Never',
        loginCount: user.login_count || 0,
        plan: user.plan || 'free',
        isActive: user.last_login_at ? new Date(user.last_login_at) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) : false
      })) || [];
    } catch (error) {
      console.error('Error processing user activity:', error);
      return [];
    }
  }

  // Update user plan
  static async updateUserPlan(userId: string, newPlan: string): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ plan: newPlan })
        .eq('id', userId);

      if (error) {
        return { success: false, error: error.message };
      }

      return { success: true };
    } catch (error) {
      console.error('Error updating user plan:', error);
      return { success: false, error: 'Failed to update user plan' };
    }
  }

  // Deactivate user account
  static async deactivateUser(userId: string): Promise<{ success: boolean; error?: string }> {
    try {
      // Update profile to mark as inactive
      const { error: profileError } = await supabase
        .from('profiles')
        .update({ role: 'inactive' })
        .eq('id', userId);

      if (profileError) {
        return { success: false, error: profileError.message };
      }

      // Deactivate all user's SixMorph keys
      const { error: keysError } = await supabase
        .from('sixmorph_keys')
        .update({ is_active: false })
        .eq('user_id', userId);

      if (keysError) {
        console.error('Error deactivating SixMorph keys:', keysError);
      }

      return { success: true };
    } catch (error) {
      console.error('Error deactivating user:', error);
      return { success: false, error: 'Failed to deactivate user' };
    }
  }

  // Get user's subscription status
  static async getUserSubscription(userId: string) {
    try {
      const { data, error } = await supabase.rpc('get_user_subscription_status', {
        p_user_id: userId
      });

      if (error) {
        console.error('Error fetching subscription status:', error);
        return null;
      }

      return data?.[0] || null;
    } catch (error) {
      console.error('Error processing subscription data:', error);
      return null;
    }
  }

  // Create user session
  static async createUserSession(userId: string, sessionToken: string, expiresAt: string) {
    try {
      const { data, error } = await supabase.rpc('create_user_session', {
        p_user_id: userId,
        p_session_token: sessionToken,
        p_expires_at: expiresAt,
        p_ip_address: null, // IP detection would need server-side implementation
        p_user_agent: navigator.userAgent
      });

      if (error) {
        console.error('Error creating user session:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Error in createUserSession:', error);
      return null;
    }
  }

  // Validate user session
  static async validateUserSession(sessionToken: string) {
    try {
      const { data, error } = await supabase.rpc('validate_user_session', {
        p_session_token: sessionToken
      });

      if (error) {
        console.error('Error validating session:', error);
        return { user_id: null, is_valid: false };
      }

      return data?.[0] || { user_id: null, is_valid: false };
    } catch (error) {
      console.error('Error in validateUserSession:', error);
      return { user_id: null, is_valid: false };
    }
  }
}

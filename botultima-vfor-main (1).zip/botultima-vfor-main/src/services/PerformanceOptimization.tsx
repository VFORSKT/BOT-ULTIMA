
import React from 'react';

// Performance monitoring and optimization utilities
export class PerformanceOptimization {
  private static performanceMetrics: Map<string, number> = new Map();
  private static cache: Map<
    string,
    { data: any; timestamp: number; ttl: number }
  > = new Map();

  // Performance monitoring
  static startMeasure(label: string): void {
    this.performanceMetrics.set(label, performance.now());
  }

  static endMeasure(label: string): number {
    const startTime = this.performanceMetrics.get(label);
    if (!startTime) return 0;

    const duration = performance.now() - startTime;
    console.log(`⚡ Performance: ${label} took ${duration.toFixed(2)}ms`);
    this.performanceMetrics.delete(label);
    return duration;
  }

  // Debounce utility for performance
  static debounce<T extends (...args: any[]) => any>(
    func: T,
    wait: number
  ): (...args: Parameters<T>) => void {
    let timeout: NodeJS.Timeout;
    return (...args: Parameters<T>) => {
      clearTimeout(timeout);
      timeout = setTimeout(() => func(...args), wait);
    };
  }

  // Throttle utility for performance
  static throttle<T extends (...args: any[]) => any>(
    func: T,
    limit: number
  ): (...args: Parameters<T>) => void {
    let inThrottle: boolean;
    return (...args: Parameters<T>) => {
      if (!inThrottle) {
        func(...args);
        inThrottle = true;
        setTimeout(() => (inThrottle = false), limit);
      }
    };
  }

  // Memory-based caching
  static setCache(key: string, data: any, ttlMinutes: number = 5): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl: ttlMinutes * 60 * 1000,
    });
  }

  static getCache(key: string): any | null {
    const cached = this.cache.get(key);
    if (!cached) return null;

    if (Date.now() - cached.timestamp > cached.ttl) {
      this.cache.delete(key);
      return null;
    }

    return cached.data;
  }

  static clearCache(): void {
    this.cache.clear();
  }

  // Lazy loading utility
  static createLazyComponent<T extends React.ComponentType<any>>(
    importFunc: () => Promise<{ default: T }>,
    fallback?: React.ReactNode
  ): React.ComponentType<React.ComponentProps<T>> {
    const LazyComponent = React.lazy(importFunc);

    return (props: React.ComponentProps<T>) => (
      <React.Suspense fallback={fallback ?? <div>Loading...</div>}>
        <LazyComponent {...props} />
      </React.Suspense>
    );
  }

  // Bundle size optimization
  static logBundleSize(): void {
    if (typeof window !== 'undefined' && 'navigator' in window) {
      const connection = (navigator as any).connection;
      if (connection) {
        console.log(
          `📊 Network: ${connection.effectiveType}, Downlink: ${connection.downlink}Mbps`
        );
      }
    }
  }

  // Memory usage monitoring
  static logMemoryUsage(): void {
    if (
      typeof window !== 'undefined' &&
      'performance' in window &&
      'memory' in performance
    ) {
      const memory = (performance as any).memory;
      console.log(
        `🧠 Memory: Used ${(memory.usedJSHeapSize / 1048576).toFixed(2)}MB of ${(memory.totalJSHeapSize / 1048576).toFixed(2)}MB`
      );
    }
  }
}

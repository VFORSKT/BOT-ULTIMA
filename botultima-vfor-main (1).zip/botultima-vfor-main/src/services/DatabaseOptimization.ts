
import { supabase } from '@/integrations/supabase/client';

// Database optimization and performance utilities
export class DatabaseOptimization {
  private static queryCache: Map<string, { data: any; timestamp: number; ttl: number }> = new Map();

  // Query caching
  static setQueryCache(key: string, data: any, ttlMinutes: number = 10): void {
    this.queryCache.set(key, {
      data,
      timestamp: Date.now(),
      ttl: ttlMinutes * 60 * 1000,
    });
  }

  static getQueryCache(key: string): any | null {
    const cached = this.queryCache.get(key);
    if (!cached) return null;

    if (Date.now() - cached.timestamp > cached.ttl) {
      this.queryCache.delete(key);
      return null;
    }

    return cached.data;
  }

  static clearQueryCache(): void {
    this.queryCache.clear();
  }

  // Connection pooling optimization
  static async optimizeConnections(): Promise<void> {
    try {
      // Test connection with a simple query
      const { data, error } = await supabase
        .from('profiles')
        .select('count')
        .limit(1);

      if (error) {
        console.warn('Database connection test failed:', error);
      } else {
        console.log('Database connection optimized');
      }
    } catch (error) {
      console.error('Connection optimization failed:', error);
    }
  }

  // Batch operations for better performance
  static async batchInsert<T extends Record<string, any>>(
    tableName: string,
    records: T[],
    batchSize: number = 100
  ): Promise<{ success: boolean; insertedCount: number; errors: any[] }> {
    const errors: any[] = [];
    let insertedCount = 0;

    try {
      // Process records in batches
      for (let i = 0; i < records.length; i += batchSize) {
        const batch = records.slice(i, i + batchSize);
        
        const { data, error } = await (supabase as any)
          .from(tableName)
          .insert(batch);

        if (error) {
          errors.push(error);
          console.error(`Batch insert error for ${tableName}:`, error);
        } else {
          insertedCount += batch.length;
        }
      }

      return {
        success: errors.length === 0,
        insertedCount,
        errors
      };
    } catch (error) {
      console.error('Batch insert failed:', error);
      return {
        success: false,
        insertedCount,
        errors: [error]
      };
    }
  }

  // Batch updates for better performance
  static async batchUpdate<T extends Record<string, any>>(
    tableName: string,
    updates: Array<{ id: string; data: Partial<T> }>,
    batchSize: number = 50
  ): Promise<{ success: boolean; updatedCount: number; errors: any[] }> {
    const errors: any[] = [];
    let updatedCount = 0;

    try {
      // Process updates in batches
      for (let i = 0; i < updates.length; i += batchSize) {
        const batch = updates.slice(i, i + batchSize);
        
        // Execute updates sequentially within batch for safety
        for (const update of batch) {
          const { data, error } = await (supabase as any)
            .from(tableName)
            .update(update.data)
            .eq('id', update.id);

          if (error) {
            errors.push(error);
            console.error(`Update error for ${tableName} record ${update.id}:`, error);
          } else {
            updatedCount++;
          }
        }
      }

      return {
        success: errors.length === 0,
        updatedCount,
        errors
      };
    } catch (error) {
      console.error('Batch update failed:', error);
      return {
        success: false,
        updatedCount,
        errors: [error]
      };
    }
  }

  // Query optimization with pagination
  static async paginatedQuery(
    tableName: string,
    options: {
      select?: string;
      filter?: Record<string, any>;
      orderBy?: string;
      ascending?: boolean;
      pageSize?: number;
      page?: number;
    } = {}
  ): Promise<{ data: any[]; totalCount: number; hasMore: boolean; error?: any }> {
    const {
      select = '*',
      filter = {},
      orderBy = 'created_at',
      ascending = false,
      pageSize = 50,
      page = 0
    } = options;

    try {
      let query = (supabase as any).from(tableName).select(select, { count: 'exact' });

      // Apply filters
      Object.entries(filter).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          query = query.eq(key, value);
        }
      });

      // Apply ordering and pagination
      query = query
        .order(orderBy, { ascending })
        .range(page * pageSize, (page + 1) * pageSize - 1);

      const { data, error, count } = await query;

      if (error) {
        console.error('Paginated query error:', error);
        return { data: [], totalCount: 0, hasMore: false, error };
      }

      const totalCount = count || 0;
      const hasMore = ((page + 1) * pageSize) < totalCount;

      return {
        data: data || [],
        totalCount,
        hasMore,
      };
    } catch (error) {
      console.error('Paginated query failed:', error);
      return { data: [], totalCount: 0, hasMore: false, error };
    }
  }

  // Index optimization suggestions
  static async analyzeQueryPerformance(tableName: string): Promise<{
    recommendations: string[];
    slowQueries: string[];
  }> {
    const recommendations: string[] = [];
    const slowQueries: string[] = [];

    try {
      // Basic table analysis
      const { data: tableData, error } = await (supabase as any)
        .from(tableName)
        .select('*')
        .limit(1);

      if (error) {
        recommendations.push(`Table ${tableName} may need optimization - access error detected`);
      } else {
        recommendations.push(`Table ${tableName} is accessible and responding`);
      }

      // Suggest common optimizations
      recommendations.push(`Consider adding indexes on frequently queried columns for ${tableName}`);
      recommendations.push(`Implement pagination for large datasets in ${tableName}`);
      recommendations.push(`Use selective field queries instead of SELECT * for ${tableName}`);

    } catch (error) {
      console.error('Performance analysis failed:', error);
      recommendations.push('Unable to analyze performance - check connection');
    }

    return {
      recommendations,
      slowQueries
    };
  }

  // Memory usage optimization
  static optimizeMemoryUsage(): void {
    // Clear query cache if it gets too large
    if (this.queryCache.size > 1000) {
      console.log('Clearing query cache to optimize memory usage');
      this.clearQueryCache();
    }

    // Suggest garbage collection
    if (global.gc) {
      global.gc();
    }
  }

  // Performance monitoring
  static logPerformanceMetrics(): void {
    console.log(`Query cache size: ${this.queryCache.size}`);
    
    if (typeof window !== 'undefined' && 'performance' in window) {
      const navigation = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
      if (navigation) {
        console.log(`Page load time: ${navigation.loadEventEnd - navigation.fetchStart}ms`);
        console.log(`DOM ready time: ${navigation.domContentLoadedEventEnd - navigation.fetchStart}ms`);
      }
    }
  }
}


import { supabase } from "@/integrations/supabase/client";
import { AuthSecurityService } from "./AuthSecurityService";

export interface AuthResponse {
  success: boolean;
  error?: string;
  user?: any;
  session?: any;
}

export class AuthService {
  // Initialize security context on app start
  static initialize() {
    AuthSecurityService.initializeSecurityContext();
  }

  // Enhanced sign in with security features
  static async signIn(email: string, password: string): Promise<AuthResponse> {
    try {
      const result = await AuthSecurityService.signIn(email, password);
      
      if (result.success) {
        // Get the current session
        const { data: { session } } = await supabase.auth.getSession();
        return {
          success: true,
          session: session,
          user: session?.user
        };
      }

      return {
        success: false,
        error: result.error
      };
    } catch (error) {
      console.error('AuthService signIn error:', error);
      return {
        success: false,
        error: 'Authentication failed'
      };
    }
  }

  // Enhanced sign up with security features
  static async signUp(email: string, password: string, userData?: any): Promise<AuthResponse> {
    try {
      const result = await AuthSecurityService.signUp(email, password, userData);
      
      return {
        success: result.success,
        error: result.error
      };
    } catch (error) {
      console.error('AuthService signUp error:', error);
      return {
        success: false,
        error: 'Account creation failed'
      };
    }
  }

  // Enhanced sign out with security logging
  static async signOut(): Promise<AuthResponse> {
    try {
      const result = await AuthSecurityService.signOut();
      
      return {
        success: result.success,
        error: result.error
      };
    } catch (error) {
      console.error('AuthService signOut error:', error);
      return {
        success: false,
        error: 'Sign out failed'
      };
    }
  }

  // Password reset with security features
  static async resetPassword(email: string): Promise<AuthResponse> {
    try {
      const result = await AuthSecurityService.requestPasswordReset(email);
      
      return {
        success: result.success,
        error: result.error
      };
    } catch (error) {
      console.error('AuthService resetPassword error:', error);
      return {
        success: false,
        error: 'Password reset failed'
      };
    }
  }

  // Get current user profile
  static async getCurrentUserProfile() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) return null;

      const { data: profile, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error) {
        console.error('Error fetching user profile:', error);
        return null;
      }

      return profile;
    } catch (error) {
      console.error('AuthService getCurrentUserProfile error:', error);
      return null;
    }
  }

  // Update user profile
  static async updateUserProfile(updates: any) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        return { success: false, error: 'User not authenticated' };
      }

      const { error } = await supabase
        .from('profiles')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id);

      if (error) {
        console.error('Error updating profile:', error);
        return { success: false, error: error.message };
      }

      return { success: true };
    } catch (error) {
      console.error('AuthService updateUserProfile error:', error);
      return { success: false, error: 'Profile update failed' };
    }
  }

  // Check if user has specific role
  static async hasRole(role: string): Promise<boolean> {
    try {
      const profile = await this.getCurrentUserProfile();
      return profile?.role === role;
    } catch (error) {
      console.error('AuthService hasRole error:', error);
      return false;
    }
  }

  // Check user account security status
  static async checkAccountSecurity() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) return { isLocked: false };

      return await AuthSecurityService.checkAccountSecurity(user.id);
    } catch (error) {
      console.error('AuthService checkAccountSecurity error:', error);
      return { isLocked: false };
    }
  }

  // Generate SixMorph key for user
  static async generateSixMorphKey(): Promise<{ success: boolean; key?: string; error?: string }> {
    try {
      const { data, error } = await supabase.rpc('create_sixmorph_key_for_user');

      if (error) {
        console.error('Error generating SixMorph key:', error);
        return { success: false, error: error.message };
      }

      return { success: true, key: data };
    } catch (error) {
      console.error('AuthService generateSixMorphKey error:', error);
      return { success: false, error: 'Key generation failed' };
    }
  }

  // Get user's SixMorph keys
  static async getUserSixMorphKeys() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) return [];

      const { data: keys, error } = await supabase
        .from('sixmorph_keys')
        .select('*')
        .eq('user_id', user.id)
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching SixMorph keys:', error);
        return [];
      }

      return keys || [];
    } catch (error) {
      console.error('AuthService getUserSixMorphKeys error:', error);
      return [];
    }
  }

  // Verify SixMorph key
  static async verifySixMorphKey(keyValue: string): Promise<{ success: boolean; userId?: string; error?: string }> {
    try {
      const { data: keyData, error } = await supabase
        .from('sixmorph_keys')
        .select('user_id, is_active')
        .eq('key_value', keyValue)
        .eq('is_active', true)
        .single();

      if (error || !keyData) {
        return { success: false, error: 'Invalid SixMorph key' };
      }

      // Update key usage - increment usage_count manually
      const { data: currentKey } = await supabase
        .from('sixmorph_keys')
        .select('usage_count')
        .eq('key_value', keyValue)
        .single();

      const newUsageCount = (currentKey?.usage_count || 0) + 1;

      await supabase
        .from('sixmorph_keys')
        .update({
          last_used_at: new Date().toISOString(),
          usage_count: newUsageCount
        })
        .eq('key_value', keyValue);

      return { success: true, userId: keyData.user_id };
    } catch (error) {
      console.error('AuthService verifySixMorphKey error:', error);
      return { success: false, error: 'Key verification failed' };
    }
  }
}

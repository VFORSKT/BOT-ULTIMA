
import { SerializedFlowData, WorkflowNode, WorkflowEdge, WorkflowNodeData } from '@/types/WorkflowTypes';

export interface ExecutionResult {
  success: boolean;
  output?: string;
  error?: string;
  executionTime?: number;
}

export interface ExecutionContext {
  userId: string;
  workflowId: string;
  data: any;
}

export interface ExecutionCallbacks {
  onNodeExecuted?: (nodeId: string, result: ExecutionResult) => void;
  onExecutionUpdate?: (update: any) => void;
}

export class WorkflowExecutionEngine {
  private workflow: SerializedFlowData;
  private context: ExecutionContext;
  private callbacks: ExecutionCallbacks;
  private executionLog: Array<{
    nodeId: string;
    timestamp: Date;
    status: 'success' | 'error' | 'running' | 'info';
    message: string;
    data?: any;
  }> = [];

  constructor(workflow: SerializedFlowData, context: ExecutionContext, callbacks: ExecutionCallbacks = {}) {
    this.workflow = workflow;
    this.context = context;
    this.callbacks = callbacks;
  }

  async execute(): Promise<ExecutionResult> {
    console.log('Starting workflow execution...');
    this.log('workflow-start', 'info', 'Workflow execution started');

    try {
      // Convert serialized nodes back to WorkflowNode format
      const workflowNodes: WorkflowNode[] = this.workflow.nodes.map(node => ({
        id: node.id,
        type: node.type as any,
        position: { x: node.position.x, y: node.position.y },
        data: {
          label: node.data.label,
          type: node.data.type as WorkflowNodeData['type'],
          category: node.data.category as WorkflowNodeData['category'],
          config: node.data.config || {},
          isExecuting: node.data.isExecuting,
          executionResult: node.data.executionResult || null
        }
      }));

      // Find start node (trigger type)
      const startNode = workflowNodes.find(node => node.data.category === 'core' || node.data.type === 'trigger');
      
      if (!startNode) {
        throw new Error('No start node found in workflow');
      }

      // Execute nodes in sequence
      await this.executeNode(startNode, workflowNodes);

      return {
        success: true,
        output: 'Workflow executed successfully',
        executionTime: Date.now()
      };

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('Workflow execution failed:', errorMessage);
      this.log('workflow-error', 'error', `Workflow execution failed: ${errorMessage}`);
      
      return {
        success: false,
        error: errorMessage,
        executionTime: Date.now()
      };
    }
  }

  private async executeNode(
    node: WorkflowNode,
    allNodes: WorkflowNode[]
  ) {
    this.log(node.id, 'running', `Executing node: ${node.data.label}`);

    try {
      // Simulate node execution based on type
      const result = await this.simulateNodeExecution(node);
      
      this.log(node.id, 'success', `Node executed successfully`);
      this.callbacks.onNodeExecuted?.(node.id, result);

      // Find and execute next nodes
      const nextNodes = this.getNextNodes(node.id, allNodes);
      for (const nextNode of nextNodes) {
        await this.executeNode(nextNode, allNodes);
      }

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      this.log(node.id, 'error', `Node execution failed: ${errorMessage}`);
      
      const failureResult: ExecutionResult = {
        success: false,
        error: errorMessage,
        executionTime: Date.now()
      };
      
      this.callbacks.onNodeExecuted?.(node.id, failureResult);
    }
  }

  private async simulateNodeExecution(node: WorkflowNode): Promise<ExecutionResult> {
    // Simulate execution delay
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));

    switch (node.data.category) {
      case 'ai':
        return { 
          success: true, 
          output: 'AI processing completed', 
          executionTime: Date.now()
        };
      
      case 'action':
        return { 
          success: true, 
          output: 'Action executed successfully', 
          executionTime: Date.now()
        };
      
      case 'transformation':
        return { 
          success: true, 
          output: 'Data transformed', 
          executionTime: Date.now()
        };
      
      case 'flow-control':
        return { 
          success: true, 
          output: 'Flow control executed', 
          executionTime: Date.now()
        };
      
      case 'communication':
        return { 
          success: true, 
          output: 'Message sent successfully', 
          executionTime: Date.now()
        };
      
      case 'database':
        return { 
          success: true, 
          output: 'Database operation completed', 
          executionTime: Date.now()
        };
      
      default:
        return { 
          success: true, 
          output: 'Node executed', 
          executionTime: Date.now()
        };
    }
  }

  private getNextNodes(currentNodeId: string, allNodes: WorkflowNode[]): WorkflowNode[] {
    const nextNodeIds = this.workflow.edges
      .filter(edge => edge.source === currentNodeId)
      .map(edge => edge.target);
    
    return allNodes.filter(node => nextNodeIds.includes(node.id));
  }

  private log(nodeId: string, status: 'success' | 'error' | 'running' | 'info', message: string, data?: any) {
    const logEntry = {
      nodeId,
      timestamp: new Date(),
      status,
      message,
      data
    };
    
    this.executionLog.push(logEntry);
    console.log(`[${status.toUpperCase()}] ${nodeId}: ${message}`, data || '');
  }

  getExecutionLog() {
    return [...this.executionLog];
  }

  clearLog() {
    this.executionLog = [];
  }
}

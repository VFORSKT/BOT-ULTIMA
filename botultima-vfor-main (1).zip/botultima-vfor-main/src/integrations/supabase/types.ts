export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instanciate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.3 (519615d)"
  }
  public: {
    Tables: {
      agent_templates: {
        Row: {
          category: string
          created_at: string
          description: string
          difficulty_level: string
          id: string
          name: string
          required_skills: Json | null
          template_data: Json
        }
        Insert: {
          category: string
          created_at?: string
          description: string
          difficulty_level?: string
          id?: string
          name: string
          required_skills?: Json | null
          template_data: Json
        }
        Update: {
          category?: string
          created_at?: string
          description?: string
          difficulty_level?: string
          id?: string
          name?: string
          required_skills?: Json | null
          template_data?: Json
        }
        Relationships: []
      }
      agents: {
        Row: {
          config: Json | null
          created_at: string
          description: string | null
          id: string
          is_active: boolean | null
          max_tokens: number | null
          memory_type: string | null
          model: string | null
          name: string
          system_prompt: string | null
          temperature: number | null
          tools: Json | null
          updated_at: string
          user_id: string
        }
        Insert: {
          config?: Json | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean | null
          max_tokens?: number | null
          memory_type?: string | null
          model?: string | null
          name: string
          system_prompt?: string | null
          temperature?: number | null
          tools?: Json | null
          updated_at?: string
          user_id: string
        }
        Update: {
          config?: Json | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean | null
          max_tokens?: number | null
          memory_type?: string | null
          model?: string | null
          name?: string
          system_prompt?: string | null
          temperature?: number | null
          tools?: Json | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      ai_support_logs: {
        Row: {
          category: string | null
          created_at: string
          id: string
          question: string
          response: string | null
          user_id: string | null
        }
        Insert: {
          category?: string | null
          created_at?: string
          id?: string
          question: string
          response?: string | null
          user_id?: string | null
        }
        Update: {
          category?: string | null
          created_at?: string
          id?: string
          question?: string
          response?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      api_usage: {
        Row: {
          created_at: string | null
          endpoint: string
          id: string
          method: string
          response_time_ms: number | null
          status_code: number | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          endpoint: string
          id?: string
          method: string
          response_time_ms?: number | null
          status_code?: number | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          endpoint?: string
          id?: string
          method?: string
          response_time_ms?: number | null
          status_code?: number | null
          user_id?: string
        }
        Relationships: []
      }
      bots: {
        Row: {
          category: string | null
          created_at: string
          description: string | null
          downloads: number | null
          flow_data: Json | null
          id: string
          installs: number | null
          is_deployed: boolean | null
          is_template: boolean | null
          name: string
          rating: number | null
          updated_at: string
          user_id: string
          webhook_url: string | null
        }
        Insert: {
          category?: string | null
          created_at?: string
          description?: string | null
          downloads?: number | null
          flow_data?: Json | null
          id?: string
          installs?: number | null
          is_deployed?: boolean | null
          is_template?: boolean | null
          name: string
          rating?: number | null
          updated_at?: string
          user_id: string
          webhook_url?: string | null
        }
        Update: {
          category?: string | null
          created_at?: string
          description?: string | null
          downloads?: number | null
          flow_data?: Json | null
          id?: string
          installs?: number | null
          is_deployed?: boolean | null
          is_template?: boolean | null
          name?: string
          rating?: number | null
          updated_at?: string
          user_id?: string
          webhook_url?: string | null
        }
        Relationships: []
      }
      emails: {
        Row: {
          content: string | null
          email_type: string
          id: string
          recipient_email: string
          sent_at: string
          status: string | null
          subject: string | null
          user_id: string | null
        }
        Insert: {
          content?: string | null
          email_type: string
          id?: string
          recipient_email: string
          sent_at?: string
          status?: string | null
          subject?: string | null
          user_id?: string | null
        }
        Update: {
          content?: string | null
          email_type?: string
          id?: string
          recipient_email?: string
          sent_at?: string
          status?: string | null
          subject?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      encrypted_user_data: {
        Row: {
          created_at: string | null
          data_type: string
          encrypted_data: string
          id: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          data_type: string
          encrypted_data: string
          id?: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          data_type?: string
          encrypted_data?: string
          id?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      password_reset_tokens: {
        Row: {
          created_at: string | null
          expires_at: string
          id: string
          token_hash: string
          used: boolean | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          expires_at: string
          id?: string
          token_hash: string
          used?: boolean | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          expires_at?: string
          id?: string
          token_hash?: string
          used?: boolean | null
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          badges: Json | null
          bio: string | null
          company_name: string | null
          cover_image_url: string | null
          created_at: string
          email: string | null
          github_url: string | null
          id: string
          is_verified: boolean | null
          job_title: string | null
          last_login_at: string | null
          location: string | null
          login_count: number | null
          logo_url: string | null
          phone: string | null
          plan: string | null
          preferences: Json | null
          role: string | null
          skills: Json | null
          social_links: Json | null
          subscription_status: string | null
          twitter_url: string | null
          username: string | null
          website_url: string | null
        }
        Insert: {
          avatar_url?: string | null
          badges?: Json | null
          bio?: string | null
          company_name?: string | null
          cover_image_url?: string | null
          created_at?: string
          email?: string | null
          github_url?: string | null
          id: string
          is_verified?: boolean | null
          job_title?: string | null
          last_login_at?: string | null
          location?: string | null
          login_count?: number | null
          logo_url?: string | null
          phone?: string | null
          plan?: string | null
          preferences?: Json | null
          role?: string | null
          skills?: Json | null
          social_links?: Json | null
          subscription_status?: string | null
          twitter_url?: string | null
          username?: string | null
          website_url?: string | null
        }
        Update: {
          avatar_url?: string | null
          badges?: Json | null
          bio?: string | null
          company_name?: string | null
          cover_image_url?: string | null
          created_at?: string
          email?: string | null
          github_url?: string | null
          id?: string
          is_verified?: boolean | null
          job_title?: string | null
          last_login_at?: string | null
          location?: string | null
          login_count?: number | null
          logo_url?: string | null
          phone?: string | null
          plan?: string | null
          preferences?: Json | null
          role?: string | null
          skills?: Json | null
          social_links?: Json | null
          subscription_status?: string | null
          twitter_url?: string | null
          username?: string | null
          website_url?: string | null
        }
        Relationships: []
      }
      purchases: {
        Row: {
          amount: number
          created_at: string | null
          currency: string | null
          id: string
          item_id: string | null
          item_type: string
          status: string | null
          stripe_payment_intent_id: string | null
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string | null
          currency?: string | null
          id?: string
          item_id?: string | null
          item_type: string
          status?: string | null
          stripe_payment_intent_id?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string | null
          currency?: string | null
          id?: string
          item_id?: string | null
          item_type?: string
          status?: string | null
          stripe_payment_intent_id?: string | null
          user_id?: string
        }
        Relationships: []
      }
      quiz_questions: {
        Row: {
          category: string
          created_at: string
          id: string
          options: Json
          question: string
          weight: number | null
        }
        Insert: {
          category: string
          created_at?: string
          id?: string
          options: Json
          question: string
          weight?: number | null
        }
        Update: {
          category?: string
          created_at?: string
          id?: string
          options?: Json
          question?: string
          weight?: number | null
        }
        Relationships: []
      }
      quiz_results: {
        Row: {
          analysis_result: Json
          answers: Json
          created_at: string
          id: string
          recommended_agents: Json | null
          recommended_workflows: Json | null
          user_id: string | null
        }
        Insert: {
          analysis_result: Json
          answers: Json
          created_at?: string
          id?: string
          recommended_agents?: Json | null
          recommended_workflows?: Json | null
          user_id?: string | null
        }
        Update: {
          analysis_result?: Json
          answers?: Json
          created_at?: string
          id?: string
          recommended_agents?: Json | null
          recommended_workflows?: Json | null
          user_id?: string | null
        }
        Relationships: []
      }
      rate_limits: {
        Row: {
          attempts: number | null
          blocked_until: string | null
          created_at: string | null
          endpoint: string
          id: string
          identifier: string
          updated_at: string | null
        }
        Insert: {
          attempts?: number | null
          blocked_until?: string | null
          created_at?: string | null
          endpoint: string
          id?: string
          identifier: string
          updated_at?: string | null
        }
        Update: {
          attempts?: number | null
          blocked_until?: string | null
          created_at?: string | null
          endpoint?: string
          id?: string
          identifier?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      security_audit_logs: {
        Row: {
          created_at: string | null
          details: Json | null
          event_type: string
          id: string
          ip_address: unknown | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          details?: Json | null
          event_type: string
          id?: string
          ip_address?: unknown | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          details?: Json | null
          event_type?: string
          id?: string
          ip_address?: unknown | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      sixmorph_keys: {
        Row: {
          created_at: string
          id: string
          is_active: boolean
          key_name: string
          key_value: string
          last_used_at: string | null
          usage_count: number | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean
          key_name?: string
          key_value: string
          last_used_at?: string | null
          usage_count?: number | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean
          key_name?: string
          key_value?: string
          last_used_at?: string | null
          usage_count?: number | null
          user_id?: string
        }
        Relationships: []
      }
      subscription_plans: {
        Row: {
          created_at: string | null
          currency: string | null
          features: Json | null
          id: string
          interval_type: string
          is_active: boolean | null
          name: string
          price: number
        }
        Insert: {
          created_at?: string | null
          currency?: string | null
          features?: Json | null
          id?: string
          interval_type: string
          is_active?: boolean | null
          name: string
          price: number
        }
        Update: {
          created_at?: string | null
          currency?: string | null
          features?: Json | null
          id?: string
          interval_type?: string
          is_active?: boolean | null
          name?: string
          price?: number
        }
        Relationships: []
      }
      support_requests: {
        Row: {
          ai_response: string | null
          created_at: string
          id: string
          question: string
          resolved: boolean
          user_id: string
        }
        Insert: {
          ai_response?: string | null
          created_at?: string
          id?: string
          question: string
          resolved?: boolean
          user_id: string
        }
        Update: {
          ai_response?: string | null
          created_at?: string
          id?: string
          question?: string
          resolved?: boolean
          user_id?: string
        }
        Relationships: []
      }
      two_factor_tokens: {
        Row: {
          created_at: string | null
          expires_at: string
          id: string
          token_hash: string
          user_id: string
          verified: boolean | null
        }
        Insert: {
          created_at?: string | null
          expires_at: string
          id?: string
          token_hash: string
          user_id: string
          verified?: boolean | null
        }
        Update: {
          created_at?: string | null
          expires_at?: string
          id?: string
          token_hash?: string
          user_id?: string
          verified?: boolean | null
        }
        Relationships: []
      }
      user_api_keys: {
        Row: {
          created_at: string
          encrypted_key: string
          id: string
          service_name: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          encrypted_key: string
          id?: string
          service_name: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          encrypted_key?: string
          id?: string
          service_name?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_preferences: {
        Row: {
          ai_assistant_auto_open: boolean | null
          created_at: string
          has_seen_tutorial: boolean | null
          has_seen_welcome: boolean | null
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          ai_assistant_auto_open?: boolean | null
          created_at?: string
          has_seen_tutorial?: boolean | null
          has_seen_welcome?: boolean | null
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          ai_assistant_auto_open?: boolean | null
          created_at?: string
          has_seen_tutorial?: boolean | null
          has_seen_welcome?: boolean | null
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_sessions: {
        Row: {
          created_at: string | null
          expires_at: string
          id: string
          ip_address: unknown | null
          is_active: boolean | null
          session_token: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          expires_at: string
          id?: string
          ip_address?: unknown | null
          is_active?: boolean | null
          session_token: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          expires_at?: string
          id?: string
          ip_address?: unknown | null
          is_active?: boolean | null
          session_token?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_subscriptions: {
        Row: {
          created_at: string | null
          current_period_end: string | null
          current_period_start: string | null
          id: string
          plan_id: string
          status: string | null
          stripe_subscription_id: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          current_period_end?: string | null
          current_period_start?: string | null
          id?: string
          plan_id: string
          status?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          current_period_end?: string | null
          current_period_start?: string | null
          id?: string
          plan_id?: string
          status?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_subscriptions_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "subscription_plans"
            referencedColumns: ["id"]
          },
        ]
      }
      workflow_executions: {
        Row: {
          completed_at: string | null
          error_message: string | null
          execution_data: Json | null
          id: string
          nodes_executed: number | null
          started_at: string
          status: string
          total_nodes: number | null
          user_id: string
          workflow_id: string | null
        }
        Insert: {
          completed_at?: string | null
          error_message?: string | null
          execution_data?: Json | null
          id?: string
          nodes_executed?: number | null
          started_at?: string
          status?: string
          total_nodes?: number | null
          user_id: string
          workflow_id?: string | null
        }
        Update: {
          completed_at?: string | null
          error_message?: string | null
          execution_data?: Json | null
          id?: string
          nodes_executed?: number | null
          started_at?: string
          status?: string
          total_nodes?: number | null
          user_id?: string
          workflow_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "workflow_executions_workflow_id_fkey"
            columns: ["workflow_id"]
            isOneToOne: false
            referencedRelation: "bots"
            referencedColumns: ["id"]
          },
        ]
      }
      workflow_templates: {
        Row: {
          category: string
          created_at: string
          description: string
          difficulty_level: string
          id: string
          name: string
          required_skills: Json | null
          template_data: Json
        }
        Insert: {
          category: string
          created_at?: string
          description: string
          difficulty_level?: string
          id?: string
          name: string
          required_skills?: Json | null
          template_data: Json
        }
        Update: {
          category?: string
          created_at?: string
          description?: string
          difficulty_level?: string
          id?: string
          name?: string
          required_skills?: Json | null
          template_data?: Json
        }
        Relationships: []
      }
      workflows: {
        Row: {
          category: string | null
          created_at: string | null
          description: string | null
          flow_data: Json | null
          id: string
          is_published: boolean | null
          is_template: boolean | null
          name: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          category?: string | null
          created_at?: string | null
          description?: string | null
          flow_data?: Json | null
          id?: string
          is_published?: boolean | null
          is_template?: boolean | null
          name: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          category?: string | null
          created_at?: string | null
          description?: string | null
          flow_data?: Json | null
          id?: string
          is_published?: boolean | null
          is_template?: boolean | null
          name?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      analyze_quiz_results: {
        Args: { answers: Json }
        Returns: Json
      }
      check_rate_limit: {
        Args: {
          p_identifier: string
          p_endpoint: string
          p_max_attempts?: number
          p_window_minutes?: number
        }
        Returns: boolean
      }
      cleanup_expired_tokens: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      create_sixmorph_key_for_user: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      create_user_session: {
        Args: {
          p_user_id: string
          p_session_token: string
          p_expires_at: string
          p_ip_address?: unknown
          p_user_agent?: string
        }
        Returns: string
      }
      generate_sixmorph_key: {
        Args: { user_uuid: string }
        Returns: string
      }
      get_user_subscription_status: {
        Args: { p_user_id: string }
        Returns: {
          plan_name: string
          status: string
          expires_at: string
          features: Json
        }[]
      }
      log_api_usage: {
        Args: {
          p_user_id: string
          p_endpoint: string
          p_method: string
          p_status_code?: number
          p_response_time_ms?: number
        }
        Returns: undefined
      }
      log_security_event: {
        Args: {
          p_user_id: string
          p_event_type: string
          p_ip_address: unknown
          p_user_agent: string
          p_details?: Json
        }
        Returns: undefined
      }
      validate_user_session: {
        Args: { p_session_token: string }
        Returns: {
          user_id: string
          is_valid: boolean
        }[]
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const

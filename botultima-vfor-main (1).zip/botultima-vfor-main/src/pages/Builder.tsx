import { useState, useCallback, useEffect, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Bot, 
  Settings, 
  Plus,
  ChevronLeft,
  Send,
  History,
  Lightbulb,
  ChevronRight,
  MessageSquare,
  Brain,
  Zap,
  Bug,
  AlertTriangle
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { ReactFlowProvider } from '@xyflow/react';
import {
  WorkflowCanvasLazy,
  NodePaletteLazy,
  InspectorPanelLazy,
  EnhancedIntegrationsPanelLazy,
  WorkflowSimulatorLazy,
  DebuggingConsoleLazy,
  AIAgentBuilderLazy
} from "@/components/LazyComponents";
import TelegramSimulator from "@/components/workflow/TelegramSimulator";
import TutorialPopup from "@/components/workflow/TutorialPopup";
import BuilderSidebar from "@/components/builder/BuilderSidebar";
import BuilderHeader from "@/components/builder/BuilderHeader";
import BuilderModeToggle from "@/components/builder/BuilderModeToggle";
import { WorkflowNode, WorkflowEdge, WorkflowNodeData } from "@/types/WorkflowTypes";
import { WorkflowValidator } from "@/services/WorkflowValidation";
import { PerformanceOptimization } from "@/services/PerformanceOptimization";
import { SecurityService } from "@/services/SecurityService";

type BuilderMode = 'visual' | 'agent';

const Builder = () => {
  const [selectedNode, setSelectedNode] = useState<WorkflowNode | null>(null);
  const [chatMessage, setChatMessage] = useState("");
  const [nodes, setNodes] = useState<WorkflowNode[]>([]);
  const [edges, setEdges] = useState<WorkflowEdge[]>([]);
  const [showTutorial, setShowTutorial] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [builderMode, setBuilderMode] = useState<BuilderMode>('visual');
  const [workflowRunning, setWorkflowRunning] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [validationWarnings, setValidationWarnings] = useState<string[]>([]);
  const navigate = useNavigate();

  // Performance optimization: Memoize chat messages
  const chatMessages = useMemo(() => [
    { type: "assistant", message: "Hello! I'm here to help you build your bot. What would you like to create?" },
    { type: "user", message: "I want to create a customer support bot with sentiment analysis" },
    { type: "assistant", message: "Great! Start with a Trigger node, then add GPT for analysis, Sentiment Analysis for classification, and conditional routing based on sentiment." },
  ], []);

  // Performance optimization: Memoize AI suggestions
  const aiSuggestions = useMemo(() => [
    "Add sentiment analysis after GPT to classify customer emotions",
    "Use condition nodes to route angry customers to human agents",
    "Connect to Gmail to automatically respond to support emails",
    "Add a human approval step for complex decisions",
    "Use Notion to log all conversations with sentiment scores"
  ], []);

  // Security: Initialize security monitoring
  useEffect(() => {
    PerformanceOptimization.logBundleSize();
    PerformanceOptimization.logMemoryUsage();
    SecurityService.logSecurityEvent('Builder page loaded');
    
    const hasSeenTutorial = localStorage.getItem('botultima_tutorial_seen');
    if (!hasSeenTutorial) {
      setShowTutorial(true);
    }
  }, []);

  // Performance optimization: Debounced validation
  const debouncedValidation = useMemo(
    () => PerformanceOptimization.debounce((nodes: WorkflowNode[], edges: WorkflowEdge[]) => {
      PerformanceOptimization.startMeasure('workflow-validation');
      const validation = WorkflowValidator.validateWorkflow(nodes, edges);
      setValidationErrors(validation.errors);
      setValidationWarnings(validation.warnings);
      
      // Update node validation states
      nodes.forEach(node => {
        const nodeErrors = WorkflowValidator.validateNode(node);
        handleUpdateNode(node.id, {
          validationErrors: nodeErrors,
          isValid: nodeErrors.length === 0
        });
      });
      PerformanceOptimization.endMeasure('workflow-validation');
    }, 300),
    []
  );

  // Performance optimization: Memoized drag start handler
  const onDragStart = useCallback((event: React.DragEvent, nodeType: string, category: string) => {
    // Security: Sanitize drag data
    const sanitizedNodeType = SecurityService.sanitizeInput(nodeType);
    const sanitizedCategory = SecurityService.sanitizeInput(category);
    
    event.dataTransfer.setData('application/reactflow', sanitizedNodeType);
    event.dataTransfer.setData('node-category', sanitizedCategory);
    event.dataTransfer.effectAllowed = 'move';
    
    SecurityService.logSecurityEvent('Node drag started', { nodeType: sanitizedNodeType, category: sanitizedCategory });
  }, []);

  // Performance optimization: Memoized save handler with caching
  const handleSaveWorkflow = useCallback((nodes: WorkflowNode[], edges: WorkflowEdge[]) => {
    PerformanceOptimization.startMeasure('save-workflow');
    
    setNodes(nodes);
    setEdges(edges);
    
    // Cache workflow data
    const workflowData = { nodes, edges, timestamp: Date.now() };
    PerformanceOptimization.setCache('current-workflow', workflowData, 10);
    
    console.log('Saving workflow:', workflowData);
    SecurityService.logSecurityEvent('Workflow saved', { nodeCount: nodes.length, edgeCount: edges.length });
    
    PerformanceOptimization.endMeasure('save-workflow');
  }, []);

  const handleNodeSelect = useCallback((node: WorkflowNode | null) => {
    setSelectedNode(node);
    if (node) {
      SecurityService.logSecurityEvent('Node selected', { nodeId: node.id, nodeType: node.data.type });
    }
  }, []);

  const handleUpdateNode = useCallback((nodeId: string, updates: Partial<WorkflowNodeData>) => {
    setNodes(prev => prev.map(node => 
      node.id === nodeId 
        ? { ...node, data: { ...node.data, ...updates } }
        : node
    ));
    SecurityService.logSecurityEvent('Node updated', { nodeId, updates: Object.keys(updates) });
  }, []);

  const handleTutorialClose = () => {
    setShowTutorial(false);
    localStorage.setItem('botultima_tutorial_seen', 'true');
    SecurityService.logSecurityEvent('Tutorial completed');
  };

  const handleTryFlow = () => {
    // ... keep existing code (example nodes and edges creation)
    const exampleNodes: WorkflowNode[] = [
      {
        id: 'trigger-demo',
        type: 'workflowNode',
        position: { x: 250, y: 50 },
        data: {
          label: 'Trigger',
          type: 'trigger',
          category: 'ai',
          config: {},
        },
      },
      {
        id: 'gpt-demo',
        type: 'workflowNode',
        position: { x: 250, y: 180 },
        data: {
          label: 'GPT Analysis',
          type: 'gpt',
          category: 'ai',
          config: {
            prompt: 'Analyze the customer message and provide helpful response.',
            model: 'gpt-4o-mini',
          },
        },
      },
      {
        id: 'sentiment-demo',
        type: 'workflowNode',
        position: { x: 250, y: 310 },
        data: {
          label: 'Sentiment Analysis',
          type: 'sentiment-analysis',
          category: 'ai',
          config: {},
        },
      },
      {
        id: 'condition-demo',
        type: 'workflowNode',
        position: { x: 250, y: 440 },
        data: {
          label: 'Route by Sentiment',
          type: 'condition',
          category: 'flow-control',
          config: {
            conditions: 'if sentiment == "negative" then route to human agent',
          },
        },
      },
    ];

    const exampleEdges: WorkflowEdge[] = [
      { id: 'e1', source: 'trigger-demo', target: 'gpt-demo', animated: true },
      { id: 'e2', source: 'gpt-demo', target: 'sentiment-demo', animated: true },
      { id: 'e3', source: 'sentiment-demo', target: 'condition-demo', animated: true },
    ];

    setNodes(exampleNodes);
    setEdges(exampleEdges);
    setShowTutorial(false);
    localStorage.setItem('botultima_tutorial_seen', 'true');
    SecurityService.logSecurityEvent('Example workflow loaded');
  };

  const handleModeChange = (mode: BuilderMode) => {
    setBuilderMode(mode);
    SecurityService.logSecurityEvent('Builder mode changed', { mode });
  };

  const handleRunWorkflow = () => {
    setWorkflowRunning(true);
    SecurityService.logSecurityEvent('Workflow execution started');
    
    // Simulate workflow completion
    setTimeout(() => {
      setWorkflowRunning(false);
      SecurityService.logSecurityEvent('Workflow execution completed');
    }, 10000);
  };

  // Performance optimization: Throttled chat message handler
  const handleChatSubmit = useMemo(
    () => PerformanceOptimization.throttle(() => {
      if (!chatMessage.trim()) return;
      
      // Security: Validate and sanitize chat input
      const sanitizedMessage = SecurityService.sanitizeInput(chatMessage);
      console.log('Chat message:', sanitizedMessage);
      setChatMessage('');
      SecurityService.logSecurityEvent('Chat message sent', { messageLength: sanitizedMessage.length });
    }, 1000),
    [chatMessage]
  );

  // Performance optimization: Effect with cleanup for validation
  useEffect(() => {
    if (nodes.length > 0 || edges.length > 0) {
      debouncedValidation(nodes, edges);
    }
    
    return () => {
      // Cleanup on unmount
      PerformanceOptimization.clearCache();
    };
  }, [nodes, edges, debouncedValidation]);

  if (builderMode === 'agent') {
    return (
      <div className="min-h-screen bg-gray-950 text-white flex">
        <TutorialPopup 
          isOpen={showTutorial}
          onClose={handleTutorialClose}
          onTryFlow={handleTryFlow}
        />

        <BuilderSidebar
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
          onBack={() => navigate('/dashboard')}
          title="AI Agent Builder"
          subtitle="Create intelligent AI agents"
        >
          <BuilderModeToggle
            currentMode={builderMode}
            onModeChange={handleModeChange}
          />
        </BuilderSidebar>

        <div className="flex-1">
          <BuilderHeader mode="agent" />
          <AIAgentBuilderLazy />
        </div>
      </div>
    );
  }

  return (
    <ReactFlowProvider>
      <div className="min-h-screen bg-gray-950 text-white flex">
        <TutorialPopup 
          isOpen={showTutorial}
          onClose={handleTutorialClose}
          onTryFlow={handleTryFlow}
        />

        <BuilderSidebar
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
          onBack={() => navigate('/dashboard')}
          title="Bot Builder"
          subtitle="Advanced Workflow Designer"
        >
          <BuilderModeToggle
            currentMode={builderMode}
            onModeChange={handleModeChange}
          />

          {!sidebarCollapsed && (
            <Tabs defaultValue="nodes" className="flex-1 flex flex-col">
              <TabsList className="grid w-full grid-cols-5 bg-gray-700/50 m-4">
                <TabsTrigger value="nodes">Blocks</TabsTrigger>
                <TabsTrigger value="integrations">Connect</TabsTrigger>
                <TabsTrigger value="simulator">Simulate</TabsTrigger>
                <TabsTrigger value="debug">Debug</TabsTrigger>
                <TabsTrigger value="chat">AI Help</TabsTrigger>
              </TabsList>

              <TabsContent value="nodes" className="flex-1 p-4 space-y-4">
                <NodePaletteLazy onDragStart={onDragStart} />

                {/* Validation Status */}
                {(validationErrors.length > 0 || validationWarnings.length > 0) && (
                  <div className="border-t border-gray-700 pt-4">
                    <h3 className="text-sm font-semibold mb-3 text-gray-300 flex items-center">
                      <AlertTriangle className="h-4 w-4 mr-2" />
                      Validation Issues
                    </h3>
                    <div className="space-y-2">
                      {validationErrors.map((error, index) => (
                        <div 
                          key={index}
                          className="p-2 bg-red-500/10 border border-red-500/20 rounded text-xs text-red-300"
                        >
                          ❌ {error}
                        </div>
                      ))}
                      {validationWarnings.map((warning, index) => (
                        <div 
                          key={index}
                          className="p-2 bg-yellow-500/10 border border-yellow-500/20 rounded text-xs text-yellow-300"
                        >
                          ⚠️ {warning}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="border-t border-gray-700 pt-4">
                  <h3 className="text-sm font-semibold mb-3 text-gray-300 flex items-center">
                    <Lightbulb className="h-4 w-4 mr-2" />
                    AI Suggestions
                  </h3>
                  <div className="space-y-2">
                    {aiSuggestions.map((suggestion, index) => (
                      <div 
                        key={index}
                        className="p-2 bg-purple-500/10 border border-purple-500/20 rounded text-xs text-purple-300 cursor-pointer hover:bg-purple-500/20 transition-colors"
                      >
                        💡 {suggestion}
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="integrations" className="flex-1 p-4">
                <EnhancedIntegrationsPanelLazy />
              </TabsContent>

              <TabsContent value="simulator" className="flex-1 p-4">
                <WorkflowSimulatorLazy 
                  nodes={nodes}
                  edges={edges}
                  onUpdateNode={handleUpdateNode}
                />
              </TabsContent>

              <TabsContent value="debug" className="flex-1 p-4">
                <DebuggingConsoleLazy 
                  isRunning={workflowRunning}
                  onToggleLogging={() => setWorkflowRunning(!workflowRunning)}
                />
              </TabsContent>

              <TabsContent value="chat" className="flex-1 flex flex-col p-4">
                <div className="flex-1 space-y-3 mb-4 overflow-y-auto">
                  {chatMessages.map((msg, index) => (
                    <div
                      key={index}
                      className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[80%] p-3 rounded-lg text-sm ${
                          msg.type === 'user'
                            ? 'bg-green-600 text-white'
                            : 'bg-gray-700 text-gray-100'
                        }`}
                      >
                        {msg.message}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={chatMessage}
                    onChange={(e) => setChatMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleChatSubmit()}
                    placeholder="Ask about workflow patterns..."
                    className="flex-1 bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-sm"
                    maxLength={500}
                  />
                  <Button size="sm" className="bg-green-600 hover:bg-green-700" onClick={handleChatSubmit}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          )}
        </BuilderSidebar>

        <div className="flex-1 flex flex-col">
          <div className="flex-1 flex">
            <div className="flex-1">
              <WorkflowCanvasLazy 
                onSave={handleSaveWorkflow}
                initialNodes={nodes}
                initialEdges={edges}
                onNodeSelect={handleNodeSelect}
                selectedNode={selectedNode}
                onUpdateNode={handleUpdateNode}
              />
            </div>
            
            <div className="w-80 border-l border-gray-700/50 bg-gray-900/50 backdrop-blur-sm">
              <InspectorPanelLazy 
                selectedNode={selectedNode}
                onUpdateNode={handleUpdateNode}
              />
            </div>
          </div>
        </div>
      </div>
    </ReactFlowProvider>
  );
};

export default Builder;

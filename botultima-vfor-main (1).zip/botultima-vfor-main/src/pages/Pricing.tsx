
import VFORPricing from "@/components/VFORPricing";
import Navigation from "@/components/Navigation";

const Pricing = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900">
      <Navigation />
      <VFORPricing />
    </div>
  );
};

export default Pricing;


import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Navigation from "@/components/Navigation";
import Analytics from "@/components/Analytics";
import UserManagement from "@/components/UserManagement";
import QuizSetupWizard from "@/components/QuizSetupWizard";
import AdminGuard from "@/components/AdminGuard";
import SixMorphKeyGenerator from "@/components/SixMorphKeyGenerator";
import { Shield, Users, BarChart3, Settings, HelpCircle, Key } from "lucide-react";

const Admin = () => {
  return (
    <AdminGuard>
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900">
        <Navigation />
        
        <div className="pt-20 px-6">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-white mb-2">Admin Dashboard</h1>
              <p className="text-gray-400">Manage your platform and users</p>
            </div>

            <Tabs defaultValue="analytics" className="space-y-6">
              <TabsList className="grid w-full grid-cols-5 bg-gray-800/50">
                <TabsTrigger value="analytics" className="flex items-center space-x-2">
                  <BarChart3 className="h-4 w-4" />
                  <span>Analytics</span>
                </TabsTrigger>
                <TabsTrigger value="users" className="flex items-center space-x-2">
                  <Users className="h-4 w-4" />
                  <span>Users</span>
                </TabsTrigger>
                <TabsTrigger value="keys" className="flex items-center space-x-2">
                  <Key className="h-4 w-4" />
                  <span>SixMorph Keys</span>
                </TabsTrigger>
                <TabsTrigger value="quiz" className="flex items-center space-x-2">
                  <HelpCircle className="h-4 w-4" />
                  <span>Quiz Setup</span>
                </TabsTrigger>
                <TabsTrigger value="settings" className="flex items-center space-x-2">
                  <Settings className="h-4 w-4" />
                  <span>Settings</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="analytics">
                <Analytics />
              </TabsContent>

              <TabsContent value="users">
                <UserManagement />
              </TabsContent>

              <TabsContent value="keys">
                <SixMorphKeyGenerator />
              </TabsContent>

              <TabsContent value="quiz">
                <QuizSetupWizard />
              </TabsContent>

              <TabsContent value="settings">
                <div className="text-center py-12">
                  <Shield className="h-16 w-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-400 mb-4">System Settings</h3>
                  <p className="text-gray-500">Advanced configuration options coming soon</p>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </AdminGuard>
  );
};

export default Admin;

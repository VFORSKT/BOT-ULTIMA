
import Navigation from "@/components/Navigation";
import HelpCenter from "@/components/HelpCenter";

const Help = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900 text-white">
      <Navigation />
      
      <main className="pt-24 pb-12 px-4">
        <HelpCenter />
      </main>
    </div>
  );
};

export default Help;

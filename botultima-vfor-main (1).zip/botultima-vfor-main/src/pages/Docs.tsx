
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Book, ChevronRight, FileText, Video, Code, Zap, Brain, Bot } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Navigation from "@/components/Navigation";

const Docs = () => {
  const [selectedSection, setSelectedSection] = useState("getting-started");
  const navigate = useNavigate();

  const sections = [
    {
      id: "getting-started",
      title: "Getting Started",
      icon: Zap,
      articles: [
        { title: "Quick Start Guide", type: "text" },
        { title: "Your First Bot in 5 Minutes", type: "video" },
        { title: "Understanding Workflow Blocks", type: "text" },
      ]
    },
    {
      id: "building-bots",
      title: "Building Bots",
      icon: Bot,
      articles: [
        { title: "Visual Flow Designer", type: "text" },
        { title: "Adding AI Logic", type: "text" },
        { title: "Connecting Integrations", type: "text" },
        { title: "Testing Your Bot", type: "video" },
      ]
    },
    {
      id: "ai-features",
      title: "AI Features",
      icon: Brain,
      articles: [
        { title: "GPT-4 Integration", type: "text" },
        { title: "Custom AI Prompts", type: "text" },
        { title: "AI Agent Studio", type: "video" },
        { title: "Advanced AI Workflows", type: "text" },
      ]
    },
    {
      id: "integrations",
      title: "Integrations",
      icon: Code,
      articles: [
        { title: "Telegram Bot Setup", type: "text" },
        { title: "Gmail Integration", type: "text" },
        { title: "Google Docs & Sheets", type: "text" },
        { title: "Notion Database", type: "text" },
        { title: "API Connections", type: "text" },
      ]
    },
    {
      id: "deployment",
      title: "Deployment",
      icon: FileText,
      articles: [
        { title: "Publishing Your Bot", type: "text" },
        { title: "Multi-Platform Deployment", type: "text" },
        { title: "Custom Domains", type: "text" },
        { title: "Analytics & Monitoring", type: "video" },
      ]
    },
  ];

  const currentSection = sections.find(s => s.id === selectedSection);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900 text-white">
      <Navigation />
      
      <main className="pt-24 pb-12 px-4">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-green-400 to-emerald-300 bg-clip-text text-transparent">
              Documentation
            </h1>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Everything you need to master BOTultima and build amazing AI bots
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Sidebar */}
            <div className="lg:col-span-1">
              <Card className="bg-gray-800/50 border-gray-700 sticky top-24">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Book className="w-5 h-5 mr-2 text-green-400" />
                    Documentation
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {sections.map((section) => {
                    const Icon = section.icon;
                    return (
                      <Button
                        key={section.id}
                        variant={selectedSection === section.id ? "default" : "ghost"}
                        className={`w-full justify-start ${
                          selectedSection === section.id 
                            ? "bg-green-500 hover:bg-green-600" 
                            : "text-gray-300 hover:text-green-400 hover:bg-green-500/10"
                        }`}
                        onClick={() => setSelectedSection(section.id)}
                      >
                        <Icon className="w-4 h-4 mr-2" />
                        {section.title}
                      </Button>
                    );
                  })}
                </CardContent>
              </Card>
            </div>

            {/* Content */}
            <div className="lg:col-span-3">
              {currentSection && (
                <div>
                  <div className="mb-8">
                    <h2 className="text-3xl font-bold text-white mb-4 flex items-center">
                      <currentSection.icon className="w-8 h-8 mr-3 text-green-400" />
                      {currentSection.title}
                    </h2>
                  </div>

                  <div className="grid gap-6">
                    {currentSection.articles.map((article, index) => (
                      <Card key={index} className="bg-gray-800/50 border-gray-700 hover:border-green-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-green-500/10 cursor-pointer">
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4">
                              {article.type === "video" ? (
                                <Video className="w-6 h-6 text-green-400" />
                              ) : (
                                <FileText className="w-6 h-6 text-green-400" />
                              )}
                              <div>
                                <h3 className="text-lg font-semibold text-white">{article.title}</h3>
                                <div className="flex items-center space-x-2 mt-1">
                                  <Badge variant="outline" className="text-xs">
                                    {article.type === "video" ? "Video Guide" : "Written Guide"}
                                  </Badge>
                                  <span className="text-xs text-gray-400">5 min read</span>
                                </div>
                              </div>
                            </div>
                            <ChevronRight className="w-5 h-5 text-gray-400" />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  {/* Quick Start Section */}
                  {selectedSection === "getting-started" && (
                    <div className="mt-12">
                      <Card className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border-green-500/30">
                        <CardHeader>
                          <CardTitle className="text-white flex items-center">
                            <Zap className="w-5 h-5 mr-2 text-green-400" />
                            Quick Start
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-gray-300 mb-4">
                            Ready to build your first bot? Follow our interactive quick start guide and have a working bot in under 5 minutes.
                          </p>
                          <Button 
                            className="bg-green-500 hover:bg-green-600"
                            onClick={() => navigate('/builder')}
                          >
                            Start Building Now
                            <ChevronRight className="w-4 h-4 ml-2" />
                          </Button>
                        </CardContent>
                      </Card>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Docs;


import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { User, CreditCard, Shield, Settings as SettingsIcon } from "lucide-react";
import Navigation from "@/components/Navigation";
import ProfileBuilder from "@/components/ProfileBuilder";
import SubscriptionManager from "@/components/SubscriptionManager";
import SecurityDashboard from "@/components/SecurityDashboard";
import WorkflowManager from "@/components/WorkflowManager";

const Settings = () => {
  const [activeTab, setActiveTab] = useState("profile");

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900">
      <Navigation />
      
      <div className="pt-20 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-white mb-2 flex items-center">
              <SettingsIcon className="h-8 w-8 mr-3 text-green-400" />
              Settings & Management
            </h1>
            <p className="text-gray-400">Manage your account, subscriptions, and security settings</p>
          </div>

          {/* Settings Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800/50">
              <TabsTrigger value="profile" className="flex items-center space-x-2">
                <User className="h-4 w-4" />
                <span>Profile</span>
              </TabsTrigger>
              <TabsTrigger value="workflows" className="flex items-center space-x-2">
                <SettingsIcon className="h-4 w-4" />
                <span>Workflows</span>
              </TabsTrigger>
              <TabsTrigger value="subscription" className="flex items-center space-x-2">
                <CreditCard className="h-4 w-4" />
                <span>Subscription</span>
              </TabsTrigger>
              <TabsTrigger value="security" className="flex items-center space-x-2">
                <Shield className="h-4 w-4" />
                <span>Security</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="profile">
              <ProfileBuilder />
            </TabsContent>

            <TabsContent value="workflows">
              <WorkflowManager />
            </TabsContent>

            <TabsContent value="subscription">
              <SubscriptionManager />
            </TabsContent>

            <TabsContent value="security">
              <SecurityDashboard />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default Settings;

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Key } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/components/AuthenticationManager";
import { useAuth as useClerkAuth, SignInButton, SignUpButton } from "@clerk/clerk-react";
import { useToast } from "@/hooks/use-toast";
import BotKeyLogin from "@/components/BotKeyLogin";
import SecureAuthForm from "@/components/SecureAuthForm";

const Auth = () => {
  const [showBotKeyLogin, setShowBotKeyLogin] = useState(false);
  const [currentMode, setCurrentMode] = useState<'login' | 'signup'>('login');
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user, loading } = useAuth();
  const clerkAuth = useClerkAuth();

  // Redirect if already signed in (either Clerk or Supabase)
  useEffect(() => {
    if (!loading && (user || clerkAuth.isSignedIn)) {
      navigate('/dashboard');
    }
  }, [user, loading, clerkAuth.isSignedIn, navigate]);

  // Particle animation effect
  useEffect(() => {
    const container = document.getElementById('particles-container');
    if (!container) return;
    
    const particleCount = 100;
    
    for (let i = 0; i < particleCount; i++) {
      const particle = document.createElement('div');
      particle.className = 'absolute w-0.5 h-0.5 bg-white/50 rounded-full';
      
      // Random position
      particle.style.left = `${Math.random() * 100}%`;
      particle.style.top = `${Math.random() * 100}%`;
      
      // Random size
      const size = Math.random() * 3 + 1;
      particle.style.width = `${size}px`;
      particle.style.height = `${size}px`;
      
      // Random opacity
      particle.style.opacity = `${Math.random() * 0.5 + 0.1}`;
      
      // Random animation
      const duration = Math.random() * 20 + 10;
      particle.style.animation = `float ${duration}s ease-in-out infinite`;
      particle.style.animationDelay = `${Math.random() * 10}s`;
      
      container.appendChild(particle);
    }

    return () => {
      if (container) {
        container.innerHTML = '';
      }
    };
  }, []);

  const handleAuthSuccess = () => {
    toast({
      title: "Authentication Successful",
      description: currentMode === 'signup' ? "Welcome to SixMorph! Please take the quiz to get started." : "Welcome back to SixMorph!",
    });
    
    if (currentMode === 'signup') {
      navigate('/quiz');
    } else {
      navigate('/dashboard');
    }
  };

  if (loading || !clerkAuth.isLoaded) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/10 to-gray-900 flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  if (showBotKeyLogin) {
    return (
      <div className="min-h-screen overflow-hidden relative" style={{
        background: 'linear-gradient(135deg, #001a33 0%, #004d66 50%, #003344 100%)'
      }}>
        {/* Animated Background Elements */}
        <div id="particles-container" className="absolute inset-0 z-0"></div>
        
        {/* Data Streams */}
        <div className="absolute inset-0 flex justify-around opacity-20 z-0">
          {[...Array(7)].map((_, i) => (
            <div 
              key={i}
              className="h-full w-px animate-pulse"
              style={{
                background: 'linear-gradient(to bottom, rgba(0,0,0,0) 0%, rgba(87,181,231,0.2) 40%, rgba(87,181,231,0.8) 50%, rgba(87,181,231,0.2) 60%, rgba(0,0,0,0) 100%)',
                animation: `dataFlow 8s linear infinite ${i * 1}s`
              }}
            />
          ))}
        </div>

        <div className="min-h-screen flex items-center justify-center p-4 relative z-10">
          <div className="w-full max-w-md">
            <BotKeyLogin onClose={() => setShowBotKeyLogin(false)} />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen overflow-hidden relative" style={{
      background: 'linear-gradient(135deg, #001a33 0%, #004d66 50%, #003344 100%)'
    }}>
      {/* Animated Background Elements */}
      <div id="particles-container" className="absolute inset-0 z-0"></div>
      
      {/* Data Streams */}
      <div className="absolute inset-0 flex justify-around opacity-20 z-0">
        {[...Array(7)].map((_, i) => (
          <div 
            key={i}
            className="h-full w-px"
            style={{
              background: 'linear-gradient(to bottom, rgba(0,0,0,0) 0%, rgba(87,181,231,0.2) 40%, rgba(87,181,231,0.8) 50%, rgba(87,181,231,0.2) 60%, rgba(0,0,0,0) 100%)',
              animation: `dataFlow 8s linear infinite ${i * 1}s`
            }}
          />
        ))}
      </div>
      
      {/* Holographic City */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-blue-500/10 to-transparent opacity-30"></div>

      <div className="relative z-10 w-full max-w-4xl mx-auto px-4 min-h-screen flex flex-col items-center justify-center">
        <div className="flex flex-col items-center w-full">
          {/* Back Button */}
          <div className="w-full max-w-md mb-8">
            <Button 
              variant="ghost" 
              onClick={() => navigate('/')} 
              className="text-gray-300 hover:text-green-400 mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </div>

          {/* Logo */}
          <div className="mb-8" style={{ animation: 'float 6s ease-in-out infinite' }}>
            <div className="flex items-center justify-center space-x-2">
              <div className="w-12 h-12 flex items-center justify-center">
                <img 
                  src="/lovable-uploads/f2491956-759e-4c19-9f30-9178527e8e54.png" 
                  alt="SixMorph Logo" 
                  className="w-12 h-12 object-contain" 
                />
              </div>
              <span 
                className="text-5xl font-bold bg-gradient-to-r from-blue-400 to-green-400 bg-clip-text text-transparent"
                style={{ fontFamily: 'cursive' }}
              >
                SixMorph
              </span>
            </div>
          </div>

          {/* Clerk Authentication - Primary */}
          <div className="bg-gradient-to-r from-blue-800/20 to-purple-800/20 border border-blue-500/30 rounded-lg p-6 mb-6 w-full max-w-md">
            <div className="text-center">
              <h3 className="text-white font-medium mb-4">Quick & Secure Authentication</h3>
              <div className="space-y-3">
                <SignInButton mode="modal">
                  <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                    Sign In with Clerk
                  </Button>
                </SignInButton>
                <SignUpButton mode="modal">
                  <Button variant="outline" className="w-full border-blue-500 text-blue-400 hover:bg-blue-500/10">
                    Sign Up with Clerk
                  </Button>
                </SignUpButton>
              </div>
            </div>
          </div>
          
          {/* SixMorph Key Quick Login */}
          <div className="bg-gradient-to-r from-green-800/20 to-emerald-800/20 border border-green-500/30 rounded-lg p-4 mb-6 w-full max-w-md">
            <div className="text-center">
              <Key className="h-8 w-8 text-green-400 mx-auto mb-2" />
              <h3 className="text-white font-medium mb-2">Quick Access</h3>
              <p className="text-gray-400 text-sm mb-3">Already have a SixMorph Key?</p>
              <Button 
                onClick={() => setShowBotKeyLogin(true)} 
                className="w-full bg-green-600 hover:bg-green-700 text-white"
              >
                <Key className="h-4 w-4 mr-2" />
                Use SixMorph Key
              </Button>
            </div>
          </div>

          {/* Traditional Email/Password Authentication */}
          <div className="w-full max-w-md">
            <div className="text-center mb-4">
              <p className="text-gray-400 text-sm">Or use traditional email/password</p>
            </div>
            <SecureAuthForm
              mode={currentMode}
              onSuccess={handleAuthSuccess}
              onModeChange={setCurrentMode}
            />
          </div>
          
          {/* Floating Elements */}
          <div 
            className="absolute top-1/4 left-1/4 w-8 h-8 border border-blue-400/30 rounded-full"
            style={{ animation: 'pulse 4s ease-in-out infinite' }}
          ></div>
          <div 
            className="absolute bottom-1/3 right-1/4 w-4 h-4 bg-green-400/20 rounded-full"
            style={{ animation: 'pulse 3s ease-in-out infinite' }}
          ></div>
        </div>
      </div>
    </div>
  );
};

export default Auth;

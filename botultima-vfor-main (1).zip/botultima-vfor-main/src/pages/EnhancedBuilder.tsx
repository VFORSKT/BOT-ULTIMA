import { useState, useCallback, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { ReactFlowProvider } from '@xyflow/react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Workflow, 
  Shield, 
  Zap, 
  MessageSquare,
  Layers,
  Settings,
  Bug
} from "lucide-react";
import N8nStyleCanvas from "@/components/workflow/N8nStyleCanvas";
import EnhancedNodePalette from "@/components/workflow/EnhancedNodePalette";
import SecurityValidation from "@/components/workflow/SecurityValidation";
import BuilderSidebar from "@/components/builder/BuilderSidebar";
import BuilderHeader from "@/components/builder/BuilderHeader";
import { InspectorPanelLazy, WorkflowSimulatorLazy, DebuggingConsoleLazy } from "@/components/LazyComponents";
import { WorkflowNode, WorkflowEdge, WorkflowNodeData } from "@/types/WorkflowTypes";
import { WorkflowValidator } from "@/services/WorkflowValidation";
import { SecurityService } from "@/services/SecurityService";
import { toast } from 'sonner';

const EnhancedBuilder = () => {
  const [selectedNode, setSelectedNode] = useState<WorkflowNode | null>(null);
  const [nodes, setNodes] = useState<WorkflowNode[]>([]);
  const [edges, setEdges] = useState<WorkflowEdge[]>([]);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [workflowRunning, setWorkflowRunning] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const navigate = useNavigate();

  // Security monitoring
  useEffect(() => {
    SecurityService.logSecurityEvent('Enhanced Builder loaded');
  }, []);

  // Enhanced drag start handler with security validation
  const onDragStart = useCallback((event: React.DragEvent, nodeType: string, category: string) => {
    const sanitizedNodeType = SecurityService.sanitizeInput(nodeType);
    const sanitizedCategory = SecurityService.sanitizeInput(category);
    
    event.dataTransfer.setData('application/reactflow', sanitizedNodeType);
    event.dataTransfer.setData('node-category', sanitizedCategory);
    event.dataTransfer.effectAllowed = 'move';
    
    SecurityService.logSecurityEvent('Node drag started', { 
      nodeType: sanitizedNodeType, 
      category: sanitizedCategory 
    });
  }, []);

  const handleSaveWorkflow = useCallback((nodes: WorkflowNode[], edges: WorkflowEdge[]) => {
    // Validate workflow before saving
    const validation = WorkflowValidator.validateWorkflow(nodes, edges);
    setValidationErrors(validation.errors);
    
    if (validation.errors.length > 0) {
      toast.error(`Cannot save workflow: ${validation.errors.length} validation errors found`);
      return;
    }
    
    setNodes(nodes);
    setEdges(edges);
    
    // Security audit
    SecurityService.logSecurityEvent('Workflow saved', { 
      nodeCount: nodes.length, 
      edgeCount: edges.length,
      hasSecurityNodes: nodes.some(n => ['condition', 'throw-error'].includes(n.data.type))
    });
    
    toast.success('Workflow saved successfully');
  }, []);

  const handleNodeSelect = useCallback((node: WorkflowNode | null) => {
    setSelectedNode(node);
    if (node) {
      SecurityService.logSecurityEvent('Node selected', { 
        nodeId: node.id, 
        nodeType: node.data.type 
      });
    }
  }, []);

  const handleUpdateNode = useCallback((nodeId: string, updates: Partial<WorkflowNodeData>) => {
    setNodes(prev => prev.map(node => 
      node.id === nodeId 
        ? { ...node, data: { ...node.data, ...updates } }
        : node
    ));
    
    SecurityService.logSecurityEvent('Node updated', { 
      nodeId, 
      updates: Object.keys(updates),
      hasSecurityConfig: updates.config && Object.keys(updates.config || {}).some(key => 
        ['apiKey', 'authentication', 'security'].includes(key)
      )
    });
  }, []);

  const handleFixSecurityIssue = useCallback((issueId: string) => {
    // Auto-fix common security issues
    const nodeId = issueId.split('-').pop();
    const node = nodes.find(n => n.id === nodeId);
    
    if (!node) return;

    if (issueId.includes('insecure')) {
      // Fix HTTP to HTTPS
      const apiUrl = node.data.config?.apiUrl;
      if (apiUrl && apiUrl.startsWith('http://')) {
        handleUpdateNode(nodeId!, {
          config: {
            ...node.data.config,
            apiUrl: apiUrl.replace('http://', 'https://')
          }
        });
        toast.success('Fixed insecure connection');
      }
    } else if (issueId.includes('webhook-auth')) {
      // Add basic authentication to webhook
      handleUpdateNode(nodeId!, {
        config: {
          ...node.data.config,
          authentication: 'api-key',
          apiKey: 'your-api-key-here'
        }
      });
      toast.success('Added authentication to webhook');
    }
    
SecurityService.logSecurityEvent('Security issue auto-fixed', { issueId, nodeId });
  }, [nodes, handleUpdateNode]);

  return (
    <ReactFlowProvider>
      <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 text-white flex">
        <BuilderSidebar
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
          onBack={() => navigate('/dashboard')}
          title="Enhanced Workflow Builder"
          subtitle="n8n-inspired with Security & AI"
        >
          {!sidebarCollapsed && (
            <Tabs defaultValue="nodes" className="flex-1 flex flex-col">
              <TabsList className="grid grid-cols-4 bg-gray-700/50 m-4">
                <TabsTrigger value="nodes" className="flex items-center space-x-1">
                  <Layers className="h-3 w-3" />
                  <span className="text-xs">Nodes</span>
                </TabsTrigger>
                <TabsTrigger value="security" className="flex items-center space-x-1">
                  <Shield className="h-3 w-3" />
                  <span className="text-xs">Security</span>
                </TabsTrigger>
                <TabsTrigger value="simulate" className="flex items-center space-x-1">
                  <Zap className="h-3 w-3" />
                  <span className="text-xs">Test</span>
                </TabsTrigger>
                <TabsTrigger value="debug" className="flex items-center space-x-1">
                  <Bug className="h-3 w-3" />
                  <span className="text-xs">Debug</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="nodes" className="flex-1 p-0">
                <EnhancedNodePalette onDragStart={onDragStart} />
              </TabsContent>

              <TabsContent value="security" className="flex-1 p-4 space-y-4">
                <SecurityValidation 
                  nodes={nodes}
                  edges={edges}
                  onFixIssue={handleFixSecurityIssue}
                />
              </TabsContent>

              <TabsContent value="simulate" className="flex-1 p-4">
                <WorkflowSimulatorLazy 
                  nodes={nodes}
                  edges={edges}
                  onUpdateNode={handleUpdateNode}
                />
              </TabsContent>

              <TabsContent value="debug" className="flex-1 p-4">
                <DebuggingConsoleLazy 
                  isRunning={workflowRunning}
                  onToggleLogging={() => setWorkflowRunning(!workflowRunning)}
                />
              </TabsContent>
            </Tabs>
          )}
        </BuilderSidebar>

        <div className="flex-1 flex flex-col">
          <BuilderHeader mode="visual" />
          
          <div className="flex-1 flex">
            <div className="flex-1">
              <N8nStyleCanvas 
                onSave={handleSaveWorkflow}
                initialNodes={nodes}
                initialEdges={edges}
                onNodeSelect={handleNodeSelect}
                selectedNode={selectedNode}
                onUpdateNode={handleUpdateNode}
              />
            </div>
            
            <div className="w-80 border-l border-gray-700/50 bg-gray-900/50 backdrop-blur-sm">
              <InspectorPanelLazy 
                selectedNode={selectedNode}
                onUpdateNode={handleUpdateNode}
              />
            </div>
          </div>
        </div>
      </div>
    </ReactFlowProvider>
  );
};

export default EnhancedBuilder;

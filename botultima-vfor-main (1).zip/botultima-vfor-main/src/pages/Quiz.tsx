
import OnboardingQuiz from "@/components/OnboardingQuiz";

const Quiz = () => {
  return <OnboardingQuiz />;
};

export default Quiz;

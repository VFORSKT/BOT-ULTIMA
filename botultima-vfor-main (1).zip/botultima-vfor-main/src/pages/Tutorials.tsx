
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Play, Clock, Star, BookOpen, Video, Code, Bot, Zap, Brain } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Navigation from "@/components/Navigation";

const Tutorials = () => {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const navigate = useNavigate();

  const categories = [
    { id: "all", name: "All Tutorials" },
    { id: "beginner", name: "Beginner" },
    { id: "intermediate", name: "Intermediate" },
    { id: "advanced", name: "Advanced" },
    { id: "integrations", name: "Integrations" },
  ];

  const tutorials = [
    {
      id: 1,
      title: "Building Your First Chatbot",
      description: "Complete walkthrough of creating a simple customer service bot",
      category: "beginner",
      duration: "15 min",
      rating: 4.9,
      type: "video",
      thumbnail: "/placeholder.svg",
      difficulty: "Beginner",
      tags: ["Chatbot", "Customer Service", "Basics"],
      instructor: "Sarah Chen",
      lessons: 5
    },
    {
      id: 2,
      title: "Advanced AI Workflows",
      description: "Learn to create complex multi-step AI automation workflows",
      category: "advanced",
      duration: "45 min",
      rating: 4.8,
      type: "video",
      thumbnail: "/placeholder.svg",
      difficulty: "Advanced",
      tags: ["AI", "Workflows", "Automation"],
      instructor: "Mike Rodriguez",
      lessons: 8
    },
    {
      id: 3,
      title: "Telegram Bot Integration",
      description: "Step-by-step guide to deploying bots on Telegram",
      category: "integrations",
      duration: "25 min",
      rating: 4.7,
      type: "text",
      thumbnail: "/placeholder.svg",
      difficulty: "Intermediate",
      tags: ["Telegram", "Deployment", "Integration"],
      instructor: "Alex Kumar",
      lessons: 6
    },
    {
      id: 4,
      title: "Custom AI Prompt Engineering",
      description: "Master the art of crafting effective AI prompts for your bots",
      category: "intermediate",
      duration: "30 min",
      rating: 4.9,
      type: "video",
      thumbnail: "/placeholder.svg",
      difficulty: "Intermediate",
      tags: ["AI", "Prompts", "GPT-4"],
      instructor: "Dr. Emma Wilson",
      lessons: 7
    },
    {
      id: 5,
      title: "Bot Analytics & Optimization",
      description: "Learn to analyze bot performance and optimize for better results",
      category: "advanced",
      duration: "35 min",
      rating: 4.6,
      type: "video",
      thumbnail: "/placeholder.svg",
      difficulty: "Advanced",
      tags: ["Analytics", "Optimization", "Performance"],
      instructor: "John Park",
      lessons: 9
    },
    {
      id: 6,
      title: "No-Code Introduction",
      description: "Perfect starting point for complete beginners to bot building",
      category: "beginner",
      duration: "20 min",
      rating: 4.8,
      type: "text",
      thumbnail: "/placeholder.svg",
      difficulty: "Beginner",
      tags: ["No-Code", "Basics", "Introduction"],
      instructor: "Lisa Thompson",
      lessons: 4
    },
  ];

  const filteredTutorials = tutorials.filter(tutorial => 
    selectedCategory === "all" || tutorial.category === selectedCategory
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900 text-white">
      <Navigation />
      
      <main className="pt-24 pb-12 px-4">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-green-400 to-emerald-300 bg-clip-text text-transparent">
              Learn Bot Building
            </h1>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Master AI bot creation with our comprehensive tutorials and courses
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category.id)}
                className={selectedCategory === category.id 
                  ? "bg-green-500 hover:bg-green-600" 
                  : "border-gray-600 text-gray-300 hover:text-green-400"
                }
              >
                {category.name}
              </Button>
            ))}
          </div>

          {/* Featured Tutorial */}
          <Card className="mb-12 bg-gradient-to-r from-green-500/10 to-emerald-500/10 border-green-500/30">
            <CardContent className="p-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                <div>
                  <Badge className="bg-green-500 text-white mb-4">Featured Course</Badge>
                  <h2 className="text-3xl font-bold text-white mb-4">
                    Complete Bot Building Masterclass
                  </h2>
                  <p className="text-gray-300 mb-6">
                    A comprehensive 3-hour course covering everything from basic chatbots to advanced AI workflows. Perfect for beginners and experienced users alike.
                  </p>
                  <div className="flex items-center space-x-6 mb-6">
                    <div className="flex items-center space-x-2">
                      <Clock className="w-4 h-4 text-green-400" />
                      <span className="text-gray-300">3 hours</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <BookOpen className="w-4 h-4 text-green-400" />
                      <span className="text-gray-300">25 lessons</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <span className="text-gray-300">4.9 rating</span>
                    </div>
                  </div>
                  <Button 
                    size="lg" 
                    className="bg-green-500 hover:bg-green-600"
                    onClick={() => navigate('/builder')}
                  >
                    <Play className="w-5 h-5 mr-2" />
                    Start Learning
                  </Button>
                </div>
                <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
                  <div className="aspect-video bg-gray-700 rounded-lg flex items-center justify-center mb-4">
                    <Play className="w-16 h-16 text-green-400" />
                  </div>
                  <p className="text-gray-400 text-sm">Preview: Introduction to Bot Building</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Tutorials Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTutorials.map((tutorial) => (
              <Card key={tutorial.id} className="bg-gray-800/50 border-gray-700 hover:border-green-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-green-500/10 cursor-pointer">
                <CardHeader className="pb-3">
                  <div className="aspect-video bg-gray-700 rounded-lg flex items-center justify-center mb-4 relative">
                    {tutorial.type === "video" ? (
                      <Video className="w-12 h-12 text-green-400" />
                    ) : (
                      <BookOpen className="w-12 h-12 text-green-400" />
                    )}
                    <Badge className="absolute top-2 right-2 bg-green-500 text-white text-xs">
                      {tutorial.difficulty}
                    </Badge>
                  </div>
                  <CardTitle className="text-white text-lg line-clamp-2">
                    {tutorial.title}
                  </CardTitle>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <p className="text-gray-400 text-sm line-clamp-2">
                    {tutorial.description}
                  </p>
                  
                  <div className="flex flex-wrap gap-1">
                    {tutorial.tags.slice(0, 2).map((tag, index) => (
                      <Badge key={index} variant="secondary" className="text-xs bg-gray-700 text-gray-300">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex items-center justify-between text-sm text-gray-400">
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>{tutorial.duration}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <span>{tutorial.rating}</span>
                    </div>
                  </div>
                  
                  <div className="text-xs text-gray-500">
                    by {tutorial.instructor} • {tutorial.lessons} lessons
                  </div>
                  
                  <Button size="sm" className="w-full bg-green-500 hover:bg-green-600">
                    <Play className="w-4 h-4 mr-2" />
                    Start Tutorial
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Learning Path Section */}
          <div className="mt-16">
            <h2 className="text-3xl font-bold text-white mb-8 text-center">
              Recommended Learning Path
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-gray-800/50 border-gray-700 text-center">
                <CardHeader>
                  <Bot className="w-12 h-12 text-green-400 mx-auto mb-4" />
                  <CardTitle className="text-white">1. Fundamentals</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400 mb-4">
                    Learn the basics of no-code bot building and understand workflow concepts.
                  </p>
                  <Badge variant="outline" className="text-green-400 border-green-500">
                    2-3 hours
                  </Badge>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/50 border-gray-700 text-center">
                <CardHeader>
                  <Brain className="w-12 h-12 text-green-400 mx-auto mb-4" />
                  <CardTitle className="text-white">2. AI Integration</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400 mb-4">
                    Master AI features, prompt engineering, and advanced conversational flows.
                  </p>
                  <Badge variant="outline" className="text-green-400 border-green-500">
                    4-5 hours
                  </Badge>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/50 border-gray-700 text-center">
                <CardHeader>
                  <Zap className="w-12 h-12 text-green-400 mx-auto mb-4" />
                  <CardTitle className="text-white">3. Advanced Features</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400 mb-4">
                    Explore integrations, analytics, and optimization techniques for production bots.
                  </p>
                  <Badge variant="outline" className="text-green-400 border-green-500">
                    3-4 hours
                  </Badge>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Tutorials;

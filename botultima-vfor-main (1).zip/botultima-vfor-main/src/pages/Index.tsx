
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useHybridAuth } from "@/components/HybridAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Bot, 
  Zap, 
  Shield, 
  Users, 
  ArrowRight, 
  Star,
  CheckCircle,
  Sparkles,
  Brain,
  Workflow,
  Key
} from "lucide-react";
import Navigation from "@/components/Navigation";

const Index = () => {
  const navigate = useNavigate();
  const { user, loading, isAuthenticated } = useHybridAuth();

  // Don't redirect authenticated users - let them see the homepage
  useEffect(() => {
    // Only show loading, don't auto-redirect
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/10 to-gray-900 flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-2 border-green-400 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/10 to-gray-900">
      <Navigation />
      
      {/* Hero Section */}
      <div className="relative overflow-hidden pt-16">
        {/* Animated Background */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-r from-green-400/10 to-blue-400/10 animate-pulse"></div>
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-green-400/30 rounded-full animate-bounce"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${2 + Math.random() * 2}s`
              }}
            />
          ))}
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16">
          <div className="text-center">
            {/* Logo and Title */}
            <div className="flex items-center justify-center mb-8">
              <img 
                src="/lovable-uploads/f2491956-759e-4c19-9f30-9178527e8e54.png" 
                alt="SixMorph Logo" 
                className="w-16 h-16 mr-4" 
              />
              <h1 className="text-6xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
                SixMorph
              </h1>
            </div>

            <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
              Transform your ideas into intelligent AI workflows. Build, deploy, and scale automated solutions 
              with the power of advanced AI agents and workflow automation.
            </p>

            {/* Authentication Status and CTA */}
            {isAuthenticated ? (
              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
                <Button 
                  onClick={() => navigate('/dashboard')}
                  size="lg"
                  className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white px-8 py-4 text-lg"
                >
                  Go to Dashboard
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button 
                  onClick={() => navigate('/workflows')}
                  variant="outline"
                  size="lg"
                  className="border-green-500/50 text-green-400 hover:bg-green-500/10 px-8 py-4 text-lg"
                >
                  Build Workflows
                </Button>
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
                <Button 
                  onClick={() => navigate('/auth')}
                  size="lg"
                  className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white px-8 py-4 text-lg"
                >
                  Get Started Free
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button 
                  onClick={() => navigate('/pricing')}
                  variant="outline"
                  size="lg"
                  className="border-green-500/50 text-green-400 hover:bg-green-500/10 px-8 py-4 text-lg"
                >
                  View Pricing
                </Button>
              </div>
            )}

            {/* Features Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
              <Card className="bg-gray-800/50 border-green-500/30 backdrop-blur-sm">
                <CardHeader>
                  <Bot className="h-12 w-12 text-green-400 mb-4" />
                  <CardTitle className="text-white">AI Agents</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300">
                    Create intelligent AI agents that can handle complex tasks, make decisions, and learn from interactions.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/50 border-blue-500/30 backdrop-blur-sm">
                <CardHeader>
                  <Workflow className="h-12 w-12 text-blue-400 mb-4" />
                  <CardTitle className="text-white">Workflow Builder</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300">
                    Design sophisticated workflows with our visual builder. Connect APIs, automate processes, and scale your operations.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-gray-800/50 border-purple-500/30 backdrop-blur-sm">
                <CardHeader>
                  <Shield className="h-12 w-12 text-purple-400 mb-4" />
                  <CardTitle className="text-white">Enterprise Security</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300">
                    Built with enterprise-grade security, encryption, and compliance features to protect your data and workflows.
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Advanced Login Options */}
            {!isAuthenticated && (
              <div className="bg-gray-800/30 rounded-2xl p-8 mb-16">
                <h2 className="text-2xl font-bold text-white mb-6">Multiple Login Options</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card className="bg-gray-700/50 border-blue-500/30">
                    <CardHeader>
                      <Users className="h-8 w-8 text-blue-400 mb-2" />
                      <CardTitle className="text-white text-lg">Quick Signup</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-300 text-sm mb-4">New to SixMorph? Create your account and take our personalized quiz.</p>
                      <Button onClick={() => navigate('/auth')} className="w-full bg-blue-600 hover:bg-blue-700">
                        Sign Up & Take Quiz
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-700/50 border-green-500/30">
                    <CardHeader>
                      <Zap className="h-8 w-8 text-green-400 mb-2" />
                      <CardTitle className="text-white text-lg">Quick Login</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-300 text-sm mb-4">Already have an account? Sign in to access your dashboard.</p>
                      <Button onClick={() => navigate('/auth')} className="w-full bg-green-600 hover:bg-green-700">
                        Sign In
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-700/50 border-purple-500/30">
                    <CardHeader>
                      <Key className="h-8 w-8 text-purple-400 mb-2" />
                      <CardTitle className="text-white text-lg">SixMorph Key</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-300 text-sm mb-4">Have a SixMorph key? Access your projects instantly.</p>
                      <Button onClick={() => navigate('/auth')} className="w-full bg-purple-600 hover:bg-purple-700">
                        Use Key Login
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}

            {/* Why Choose SixMorph */}
            <div className="bg-gray-800/30 rounded-2xl p-8 mb-16">
              <h2 className="text-3xl font-bold text-white mb-8">Why Choose SixMorph?</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[
                  { icon: Brain, title: "Intelligent Quiz System", desc: "Take our quiz to get personalized recommendations for your automation needs" },
                  { icon: Zap, title: "Quick Setup", desc: "Get started in minutes with our intuitive interface and pre-built templates" },
                  { icon: Users, title: "Community Driven", desc: "Join thousands of users building the future of AI automation" },
                  { icon: Sparkles, title: "Continuous Innovation", desc: "Regular updates with new features and AI capabilities" }
                ].map((feature, index) => (
                  <div key={index} className="flex items-start space-x-4 text-left">
                    <feature.icon className="h-6 w-6 text-green-400 mt-1" />
                    <div>
                      <h3 className="text-white font-semibold">{feature.title}</h3>
                      <p className="text-gray-300 text-sm">{feature.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Social Proof */}
            <div className="text-center">
              <div className="flex items-center justify-center space-x-2 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                ))}
                <span className="text-gray-300 ml-2">4.9/5 from 1000+ users</span>
              </div>
              <p className="text-gray-400">
                Trusted by developers, entrepreneurs, and enterprises worldwide
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900/50 border-t border-gray-700 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <img 
                  src="/lovable-uploads/f2491956-759e-4c19-9f30-9178527e8e54.png" 
                  alt="SixMorph Logo" 
                  className="w-8 h-8 mr-2" 
                />
                <span className="text-xl font-bold text-white">SixMorph</span>
              </div>
              <p className="text-gray-400">
                Build the future of AI automation with intelligent workflows and agents.
              </p>
            </div>
            
            <div>
              <h3 className="text-white font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-gray-400">
                <li><button onClick={() => navigate('/dashboard')} className="hover:text-green-400 transition-colors">Dashboard</button></li>
                <li><button onClick={() => navigate('/workflows')} className="hover:text-green-400 transition-colors">Workflows</button></li>
                <li><button onClick={() => navigate('/pricing')} className="hover:text-green-400 transition-colors">Pricing</button></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-white font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-green-400 transition-colors">About</a></li>
                <li><a href="#" className="hover:text-green-400 transition-colors">Contact</a></li>
                <li><a href="#" className="hover:text-green-400 transition-colors">Support</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-white font-semibold mb-4">Get Started</h3>
              <Button 
                onClick={() => navigate('/auth')} 
                className="w-full bg-green-600 hover:bg-green-700"
              >
                Start Building
              </Button>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 SixMorph. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;

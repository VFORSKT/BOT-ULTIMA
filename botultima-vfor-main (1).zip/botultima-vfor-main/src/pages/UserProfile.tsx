
import { useState } from "react";
import { useParams } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  User, 
  Bot, 
  Zap, 
  Calendar,
  Activity,
  Crown,
  Star,
  Brain,
  UserPlus,
  MessageSquare,
  Share2
} from "lucide-react";
import Navigation from "@/components/Navigation";

const UserProfile = () => {
  const { username } = useParams();
  const [isFollowing, setIsFollowing] = useState(false);

  // Mock user data - in real app, fetch from Supabase
  const userData = {
    username: username || "john_doe",
    displayName: "John Doe",
    bio: "AI automation enthusiast building the future with bots and agents. Creator of 50+ workflows.",
    avatar: null,
    joinDate: "January 2024",
    followers: 1250,
    following: 340,
    totalBots: 23,
    totalAgents: 12,
    totalInteractions: 15600,
    plan: "Maker",
    badges: ["Early Adopter", "Bot Master", "Community Helper"],
    isVerified: true,
  };

  const publicBots = [
    {
      id: 1,
      name: "Customer Support Bot",
      description: "Automated customer service with AI responses",
      interactions: 2500,
      rating: 4.8,
      category: "Customer Service",
      isPublic: true,
    },
    {
      id: 2,
      name: "Content Moderator",
      description: "Auto-moderate user content with ML",
      interactions: 890,
      rating: 4.6,
      category: "Moderation",
      isPublic: true,
    },
  ];

  const publicAgents = [
    {
      id: 1,
      name: "Data Processor Agent",
      description: "Automatically process and analyze incoming data streams",
      executions: 450,
      rating: 4.9,
      category: "Data Processing",
      isPublic: true,
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900 text-white">
      <Navigation />
      
      <div className="pt-24 pb-12 px-4">
        <div className="max-w-6xl mx-auto">
          {/* Profile Header */}
          <Card className="bg-gray-800/50 border-gray-700 mb-8">
            <CardContent className="p-8">
              <div className="flex flex-col md:flex-row items-start md:items-center space-y-6 md:space-y-0 md:space-x-8">
                {/* Avatar */}
                <div className="relative">
                  <div className="w-24 h-24 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center text-3xl font-bold">
                    {userData.displayName.split(' ').map(n => n[0]).join('')}
                  </div>
                  {userData.isVerified && (
                    <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                      <Crown className="h-4 w-4 text-white" />
                    </div>
                  )}
                </div>

                {/* Profile Info */}
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h1 className="text-3xl font-bold">{userData.displayName}</h1>
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                      {userData.plan}
                    </Badge>
                  </div>
                  <p className="text-gray-400 mb-1">@{userData.username}</p>
                  <p className="text-gray-300 mb-4 max-w-2xl">{userData.bio}</p>
                  
                  {/* Stats */}
                  <div className="flex flex-wrap gap-6 text-sm">
                    <div className="flex items-center space-x-1">
                      <Calendar className="h-4 w-4 text-gray-400" />
                      <span className="text-gray-400">Joined {userData.joinDate}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <UserPlus className="h-4 w-4 text-gray-400" />
                      <span className="text-white font-medium">{userData.followers}</span>
                      <span className="text-gray-400">followers</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <span className="text-white font-medium">{userData.following}</span>
                      <span className="text-gray-400">following</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Activity className="h-4 w-4 text-gray-400" />
                      <span className="text-white font-medium">{userData.totalInteractions.toLocaleString()}</span>
                      <span className="text-gray-400">interactions</span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex space-x-3">
                  <Button
                    onClick={() => setIsFollowing(!isFollowing)}
                    className={isFollowing 
                      ? "bg-gray-600 hover:bg-gray-700 text-white" 
                      : "bg-green-600 hover:bg-green-700 text-white"
                    }
                  >
                    <UserPlus className="h-4 w-4 mr-2" />
                    {isFollowing ? "Following" : "Follow"}
                  </Button>
                  <Button variant="outline" className="border-gray-600 hover:bg-gray-700">
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Message
                  </Button>
                  <Button variant="outline" className="border-gray-600 hover:bg-gray-700">
                    <Share2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Badges */}
              <div className="mt-6 pt-6 border-t border-gray-700">
                <h3 className="text-sm font-medium text-gray-400 mb-3">Achievements</h3>
                <div className="flex flex-wrap gap-2">
                  {userData.badges.map((badge, index) => (
                    <Badge key={index} variant="secondary" className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                      <Star className="h-3 w-3 mr-1" />
                      {badge}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Profile Tabs */}
          <Tabs defaultValue="overview">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800/50 border border-gray-700">
              <TabsTrigger value="overview" className="data-[state=active]:bg-green-600">Overview</TabsTrigger>
              <TabsTrigger value="bots" className="data-[state=active]:bg-green-600">Bots ({userData.totalBots})</TabsTrigger>
              <TabsTrigger value="agents" className="data-[state=active]:bg-green-600">Agents ({userData.totalAgents})</TabsTrigger>
              <TabsTrigger value="usage" className="data-[state=active]:bg-green-600">Usage</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="bg-gray-800/50 border-gray-700">
                  <CardContent className="p-6 text-center">
                    <Bot className="h-12 w-12 text-green-400 mx-auto mb-3" />
                    <div className="text-2xl font-bold text-white">{userData.totalBots}</div>
                    <div className="text-sm text-gray-400">Active Bots</div>
                  </CardContent>
                </Card>
                <Card className="bg-gray-800/50 border-gray-700">
                  <CardContent className="p-6 text-center">
                    <Brain className="h-12 w-12 text-purple-400 mx-auto mb-3" />
                    <div className="text-2xl font-bold text-white">{userData.totalAgents}</div>
                    <div className="text-sm text-gray-400">AI Agents</div>
                  </CardContent>
                </Card>
                <Card className="bg-gray-800/50 border-gray-700">
                  <CardContent className="p-6 text-center">
                    <Zap className="h-12 w-12 text-yellow-400 mx-auto mb-3" />
                    <div className="text-2xl font-bold text-white">{userData.totalInteractions.toLocaleString()}</div>
                    <div className="text-sm text-gray-400">Total Interactions</div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Bots Tab */}
            <TabsContent value="bots" className="mt-6">
              <div className="space-y-4">
                {publicBots.map((bot) => (
                  <Card key={bot.id} className="bg-gray-800/50 border-gray-700 hover:border-gray-600 transition-colors">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-lg flex items-center justify-center">
                            <Bot className="h-6 w-6 text-white" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-white">{bot.name}</h3>
                            <p className="text-gray-400 text-sm">{bot.description}</p>
                            <div className="flex items-center space-x-4 mt-2">
                              <Badge variant="secondary" className="text-xs">{bot.category}</Badge>
                              <span className="text-sm text-gray-400">{bot.interactions} interactions</span>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-400 mr-1" />
                            <span className="text-sm text-yellow-400">{bot.rating}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Agents Tab */}
            <TabsContent value="agents" className="mt-6">
              <div className="space-y-4">
                {publicAgents.map((agent) => (
                  <Card key={agent.id} className="bg-gray-800/50 border-gray-700 hover:border-gray-600 transition-colors">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg flex items-center justify-center">
                            <Brain className="h-6 w-6 text-white" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-white">{agent.name}</h3>
                            <p className="text-gray-400 text-sm">{agent.description}</p>
                            <div className="flex items-center space-x-4 mt-2">
                              <Badge variant="secondary" className="text-xs">{agent.category}</Badge>
                              <span className="text-sm text-gray-400">{agent.executions} executions</span>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-400 mr-1" />
                            <span className="text-sm text-yellow-400">{agent.rating}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Usage Tab */}
            <TabsContent value="usage" className="mt-6">
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Public Usage Statistics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="text-gray-300 font-medium mb-2">Most Used Bot</h4>
                      <p className="text-white">Customer Support Bot</p>
                      <p className="text-gray-400 text-sm">2,500 interactions this month</p>
                    </div>
                    <div>
                      <h4 className="text-gray-300 font-medium mb-2">Top Performance</h4>
                      <p className="text-white">Content Moderator</p>
                      <p className="text-gray-400 text-sm">4.6 average rating</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;

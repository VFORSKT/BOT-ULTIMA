
import { useState } from "react";
import { useUser } from "@clerk/clerk-react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Upload, Bot, Key, Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

const ProfileSetup = () => {
  const { user, isLoaded } = useUser();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [sixMorphKey, setSixMorphKey] = useState("");
  const [profileData, setProfileData] = useState({
    displayName: user?.fullName || "",
    bio: "",
    logo: null as File | null,
  });

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setProfileData(prev => ({ ...prev, logo: file }));
    }
  };

  const copyBotKey = async () => {
    if (!sixMorphKey) return;
    
    try {
      await navigator.clipboard.writeText(sixMorphKey);
      setCopied(true);
      toast({
        title: "Copied!",
        description: "SixMorph Key copied to clipboard",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to copy key",
        variant: "destructive",
      });
    }
  };

  const generateSixMorphKey = async () => {
    try {
      const { data, error } = await supabase
        .rpc('create_sixmorph_key_for_user');

      if (error) {
        throw error;
      }

      setSixMorphKey(data);
      return data;
    } catch (error) {
      console.error('Error generating SixMorph Key:', error);
      toast({
        title: "Error",
        description: "Failed to generate SixMorph Key",
        variant: "destructive",
      });
      return null;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // First, generate the SixMorph Key
      const generatedKey = await generateSixMorphKey();
      if (!generatedKey) {
        return;
      }

      // Update user metadata with profile info and default plan
      await user?.update({
        unsafeMetadata: {
          displayName: profileData.displayName,
          bio: profileData.bio,
          sixMorphKey: generatedKey,
          profileSetupCompleted: true,
          plan: 'Free',
          planStatus: 'active',
          planExpiry: null,
        }
      });

      // Create/update profile in Supabase
      const { error: profileError } = await supabase
        .from('profiles')
        .upsert({
          id: user?.id,
          email: user?.emailAddresses[0]?.emailAddress,
          plan: 'free',
          role: 'user',
          username: profileData.displayName,
          bio: profileData.bio,
        });

      if (profileError) {
        console.error('Profile creation error:', profileError);
      }

      toast({
        title: "Profile Created!",
        description: "Your SixMorph profile is ready with your unique key",
      });

      navigate("/dashboard");
    } catch (error) {
      console.error('Profile setup error:', error);
      toast({
        title: "Error",
        description: "Failed to create profile",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isLoaded) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900 flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900 text-white p-6">
      <div className="max-w-2xl mx-auto pt-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center">
              <Bot className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-green-400 to-emerald-300 bg-clip-text text-transparent">
              Welcome to SixMorph
            </h1>
          </div>
          <p className="text-gray-400">Set up your profile and get your exclusive SixMorph Key</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Profile Setup Card */}
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Profile Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Logo Upload */}
              <div>
                <Label htmlFor="logo" className="text-gray-300">Profile Logo</Label>
                <div className="mt-2">
                  <label htmlFor="logo" className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-600 border-dashed rounded-lg cursor-pointer bg-gray-700/30 hover:bg-gray-700/50 transition-colors">
                    <div className="flex flex-col items-center justify-center pt-5 pb-6">
                      <Upload className="w-8 h-8 mb-4 text-gray-400" />
                      <p className="mb-2 text-sm text-gray-400">
                        <span className="font-semibold">Click to upload</span> your logo
                      </p>
                      <p className="text-xs text-gray-500">PNG, JPG or SVG (MAX. 2MB)</p>
                    </div>
                    <input 
                      id="logo" 
                      type="file" 
                      className="hidden" 
                      accept="image/*"
                      onChange={handleLogoUpload}
                    />
                  </label>
                  {profileData.logo && (
                    <p className="mt-2 text-sm text-green-400">✓ {profileData.logo.name}</p>
                  )}
                </div>
              </div>

              {/* Display Name */}
              <div>
                <Label htmlFor="displayName" className="text-gray-300">Display Name</Label>
                <Input
                  id="displayName"
                  value={profileData.displayName}
                  onChange={(e) => setProfileData(prev => ({ ...prev, displayName: e.target.value }))}
                  className="bg-gray-700 border-gray-600 text-white"
                  placeholder="Enter your display name"
                  required
                />
              </div>

              {/* Bio */}
              <div>
                <Label htmlFor="bio" className="text-gray-300">Bio</Label>
                <Textarea
                  id="bio"
                  value={profileData.bio}
                  onChange={(e) => setProfileData(prev => ({ ...prev, bio: e.target.value }))}
                  className="bg-gray-700 border-gray-600 text-white"
                  placeholder="Tell us about yourself..."
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* SixMorph Key Preview Card */}
          {sixMorphKey && (
            <Card className="bg-gradient-to-r from-green-800/20 to-emerald-800/20 border-green-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Key className="h-5 w-5 mr-2 text-green-400" />
                  Your SixMorph Key
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <p className="text-gray-300 text-sm">
                    Your unique SixMorph Key has been generated! Save it securely - you can use it for quick access to your projects.
                  </p>
                  <div className="flex items-center space-x-2">
                    <code className="flex-1 bg-gray-900/50 text-green-400 p-3 rounded-lg font-mono text-sm break-all">
                      {sixMorphKey}
                    </code>
                    <Button
                      type="button"
                      onClick={copyBotKey}
                      variant="outline"
                      size="sm"
                      className="border-green-500/30 hover:bg-green-500/20"
                    >
                      {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={isSubmitting || !profileData.displayName}
            className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white py-3"
          >
            {isSubmitting ? "Creating Profile..." : "Complete Profile Setup"}
          </Button>
        </form>
      </div>
    </div>
  );
};

export default ProfileSetup;

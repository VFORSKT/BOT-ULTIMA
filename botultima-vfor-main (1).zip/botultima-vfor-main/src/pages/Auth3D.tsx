import { useEffect, useRef, useState } from 'react';
import { SignIn, SignUp, useUser } from '@clerk/clerk-react';
import { Button } from "@/components/ui/button";
import { Bot } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import RobotWelcome from '@/components/RobotWelcome';

const Auth3D = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isSignUp, setIsSignUp] = useState(false);
  const [showWelcome, setShowWelcome] = useState(false);
  const { isSignedIn, isLoaded } = useUser();
  const navigate = useNavigate();

  // Show welcome animation on successful sign in
  useEffect(() => {
    if (isLoaded && isSignedIn && !showWelcome) {
      setShowWelcome(true);
      // Hide welcome after 4 seconds and redirect
      setTimeout(() => {
        setShowWelcome(false);
        navigate('/dashboard');
      }, 4000);
    }
  }, [isSignedIn, isLoaded, navigate, showWelcome]);

  // Wait for Clerk to load before checking auth status
  useEffect(() => {
    if (isLoaded && isSignedIn) {
      navigate('/dashboard');
    }
  }, [isSignedIn, isLoaded, navigate]);

  // Don't render anything until Clerk is loaded
  if (!isLoaded) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/10 to-gray-900 flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  // Redirect if already signed in
  useEffect(() => {
    if (isSignedIn) {
      navigate('/dashboard'); // Redirect to homepage instead of dashboard
    }
  }, [isSignedIn, navigate]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Animated forest particles
    const particles: Array<{
      x: number;
      y: number;
      size: number;
      speedX: number;
      speedY: number;
      opacity: number;
      color: string;
    }> = [];

    for (let i = 0; i < 50; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 4 + 1,
        speedX: (Math.random() - 0.5) * 0.5,
        speedY: (Math.random() - 0.5) * 0.5,
        opacity: Math.random() * 0.8 + 0.2,
        color: `hsl(${120 + Math.random() * 60}, 70%, 60%)`,
      });
    }

    const animate = () => {
      ctx.fillStyle = 'rgba(0, 20, 0, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const gradient = ctx.createRadialGradient(
        canvas.width / 2, canvas.height / 2, 0,
        canvas.width / 2, canvas.height / 2, canvas.width
      );
      gradient.addColorStop(0, 'rgba(0, 50, 0, 0.3)');
      gradient.addColorStop(1, 'rgba(0, 20, 0, 0.8)');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      particles.forEach(particle => {
        particle.x += particle.speedX;
        particle.y += particle.speedY;

        if (particle.x < 0 || particle.x > canvas.width) particle.speedX *= -1;
        if (particle.y < 0 || particle.y > canvas.height) particle.speedY *= -1;

        particle.opacity = 0.3 + Math.sin(Date.now() * 0.002 + particle.x * 0.01) * 0.3;

        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fillStyle = particle.color.replace('60%)', `60%, ${particle.opacity})`);
        ctx.fill();

        ctx.shadowColor = particle.color;
        ctx.shadowBlur = 10;
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
    };
  }, []);

  if (showWelcome) {
    return <RobotWelcome />;
  }

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* 3D Forest Background */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ background: 'linear-gradient(135deg, #001a00 0%, #003300 100%)' }}
      />

      {/* Floating Orbs */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute w-4 h-4 bg-green-400 rounded-full opacity-60 animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${3 + Math.random() * 2}s`,
              filter: 'blur(1px)',
              boxShadow: '0 0 20px rgba(34, 197, 94, 0.8)',
            }}
          />
        ))}
      </div>

      {/* Floating Logo */}
      <div className="absolute top-20 left-1/2 transform -translate-x-1/2 z-20">
        <div className="flex items-center space-x-3 animate-pulse">
          <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center shadow-2xl shadow-green-500/50">
            <Bot className="h-8 w-8 text-white" />
          </div>
          <span className="text-3xl font-bold bg-gradient-to-r from-green-400 to-emerald-300 bg-clip-text text-transparent">
            BOTultima 3.0
          </span>
        </div>
      </div>

      {/* Central Auth Box */}
      <div className="absolute inset-0 flex items-center justify-center z-10">
        <div className="bg-black/20 backdrop-blur-xl border border-green-500/30 rounded-2xl p-8 shadow-2xl shadow-green-500/25 max-w-md w-full mx-4">
          <div className="text-center mb-6">
            <div className="flex space-x-2 justify-center mb-4">
              <Button
                variant={!isSignUp ? "default" : "ghost"}
                onClick={() => setIsSignUp(false)}
                className={!isSignUp ? "bg-green-600 hover:bg-green-700" : "text-green-400 hover:bg-green-500/20"}
              >
                Sign In
              </Button>
              <Button
                variant={isSignUp ? "default" : "ghost"}
                onClick={() => setIsSignUp(true)}
                className={isSignUp ? "bg-green-600 hover:bg-green-700" : "text-green-400 hover:bg-green-500/20"}
              >
                Sign Up
              </Button>
            </div>
          </div>

          <div className="auth-container">
            {isSignUp ? (
              <SignUp
                appearance={{
                  baseTheme: undefined,
                  elements: {
                    formButtonPrimary: "bg-green-600 hover:bg-green-700 text-white",
                    card: "bg-transparent shadow-none",
                    headerTitle: "text-white",
                    headerSubtitle: "text-gray-300",
                    socialButtonsBlockButton: "border-green-500/30 text-white hover:bg-green-500/20",
                    formFieldInput: "bg-gray-800/50 border-green-500/30 text-white",
                    formFieldLabel: "text-gray-300",
                    footerActionLink: "text-green-400 hover:text-green-300",
                  }
                }}
                fallbackRedirectUrl="/dashboard"
                signInFallbackRedirectUrl="/dashboard"
              />
            ) : (
              <SignIn
                appearance={{
                  baseTheme: undefined,
                  elements: {
                    formButtonPrimary: "bg-green-600 hover:bg-green-700 text-white",
                    card: "bg-transparent shadow-none",
                    headerTitle: "text-white",
                    headerSubtitle: "text-gray-300",
                    socialButtonsBlockButton: "border-green-500/30 text-white hover:bg-green-500/20",
                    formFieldInput: "bg-gray-800/50 border-green-500/30 text-white",
                    formFieldLabel: "text-gray-300",
                    footerActionLink: "text-green-400 hover:text-green-300",
                  }
                }}
                fallbackRedirectUrl="/dashboard"
                signUpFallbackRedirectUrl="/dashboard"
              />
            )}
          </div>
        </div>
      </div>

      {/* Bottom Glow */}
      <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-96 h-32 bg-green-500/20 rounded-full blur-3xl"></div>
    </div>
  );
};

export default Auth3D;

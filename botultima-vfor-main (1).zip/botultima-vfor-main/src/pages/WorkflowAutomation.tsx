
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useHybridAuth } from "@/components/HybridAuth";
import WorkflowCanvas from "@/components/workflow/WorkflowCanvas";
import WorkflowToolsPanel from "@/components/workflow/WorkflowToolsPanel";
import { WorkflowNode, WorkflowEdge, WorkflowNodeData } from "@/types/WorkflowTypes";

const WorkflowAutomation = () => {
  const navigate = useNavigate();
  const { isAuthenticated, loading } = useHybridAuth();
  const [showToolsPanel, setShowToolsPanel] = useState(true);
  const [isToolsMinimized, setIsToolsMinimized] = useState(false);
  const [selectedNode, setSelectedNode] = useState<WorkflowNode | null>(null);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/10 to-gray-900 flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-2 border-green-400 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/10 to-gray-900 flex items-center justify-center">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-white mb-8">Authentication Required</h1>
          <p className="text-gray-400 mb-8">Please sign in to access the workflow builder.</p>
          <div className="space-y-4">
            <Button 
              onClick={() => navigate('/auth')}
              className="bg-green-600 hover:bg-green-700"
            >
              Sign In
            </Button>
            <Button 
              onClick={() => navigate('/')}
              variant="outline"
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Back to Home
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const handleSave = (nodes: WorkflowNode[], edges: WorkflowEdge[]) => {
    console.log('Saving workflow:', { nodes, edges });
  };

  const handleNodeSelect = (node: WorkflowNode | null) => {
    setSelectedNode(node);
  };

  const handleUpdateNode = (nodeId: string, updates: Partial<WorkflowNodeData>) => {
    console.log('Updating node:', { nodeId, updates });
  };

  return (
    <div className="h-screen flex flex-col bg-gray-950">
      {/* Header */}
      <div className="bg-gray-900/90 border-b border-gray-700 px-4 py-3 flex items-center justify-between z-40">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            onClick={() => navigate('/dashboard')}
            className="text-gray-300 hover:text-green-400"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
          <div className="flex items-center space-x-2">
            <img 
              src="/lovable-uploads/f2491956-759e-4c19-9f30-9178527e8e54.png" 
              alt="SixMorph Logo" 
              className="w-6 h-6" 
            />
            <h1 className="text-lg font-bold text-white">Workflow Builder</h1>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            onClick={() => setShowToolsPanel(!showToolsPanel)}
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            {showToolsPanel ? 'Hide Tools' : 'Show Tools'}
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 relative overflow-hidden">
        {/* Tools Panel */}
        {showToolsPanel && (
          <WorkflowToolsPanel
            onClose={() => setShowToolsPanel(false)}
            isMinimized={isToolsMinimized}
            onToggleMinimize={() => setIsToolsMinimized(!isToolsMinimized)}
          />
        )}

        {/* Workflow Canvas */}
        <div className="h-full">
          <WorkflowCanvas
            onSave={handleSave}
            onNodeSelect={handleNodeSelect}
            selectedNode={selectedNode}
            onUpdateNode={handleUpdateNode}
          />
        </div>
      </div>
    </div>
  );
};

export default WorkflowAutomation;


import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  User, 
  Bot, 
  Zap, 
  CreditCard, 
  Settings, 
  Edit3,
  Calendar,
  Activity,
  Crown,
  Shield,
  Star
} from "lucide-react";
import TokenUsageDashboard from "@/components/TokenUsageDashboard";

const Profile = () => {
  const [activeTab, setActiveTab] = useState("bots");

  const userBots = [
    {
      id: 1,
      name: "Customer Support Bot",
      status: "Active",
      created: "2024-01-15",
      interactions: 1250,
      rating: 4.8
    },
    {
      id: 2,
      name: "Sales Assistant",
      status: "Draft",
      created: "2024-02-01",
      interactions: 340,
      rating: 4.6
    },
    {
      id: 3,
      name: "FAQ Helper",
      status: "Active",
      created: "2024-01-20",
      interactions: 890,
      rating: 4.9
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900 text-white p-6">
      <div className="max-w-6xl mx-auto">
        {/* Profile Header */}
        <div className="mb-8">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center space-x-6">
                <div className="w-20 h-20 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center">
                  <User className="h-10 w-10 text-white" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h1 className="text-2xl font-bold">John Doe</h1>
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                      <Crown className="h-3 w-3 mr-1" />
                      Maker Plan
                    </Badge>
                  </div>
                  <p className="text-gray-400 mb-3">john.doe@example.com</p>
                  <div className="flex items-center space-x-4 text-sm text-gray-300">
                    <span className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      Joined Jan 2024
                    </span>
                    <span className="flex items-center">
                      <Activity className="h-4 w-4 mr-1" />
                      Last active today
                    </span>
                  </div>
                </div>
                <Button variant="outline" className="border-gray-600 hover:bg-gray-700">
                  <Edit3 className="h-4 w-4 mr-2" />
                  Edit Profile
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Profile Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3 bg-gray-800/50 border border-gray-700">
            <TabsTrigger value="bots" className="data-[state=active]:bg-green-600">
              <Bot className="h-4 w-4 mr-2" />
              My Bots
            </TabsTrigger>
            <TabsTrigger value="tokens" className="data-[state=active]:bg-green-600">
              <Zap className="h-4 w-4 mr-2" />
              Token Usage
            </TabsTrigger>
            <TabsTrigger value="subscription" className="data-[state=active]:bg-green-600">
              <CreditCard className="h-4 w-4 mr-2" />
              Subscription
            </TabsTrigger>
          </TabsList>

          {/* Bots Tab */}
          <TabsContent value="bots" className="mt-6">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold">My Bots</h2>
                <Button className="bg-green-600 hover:bg-green-700">
                  <Bot className="h-4 w-4 mr-2" />
                  Create New Bot
                </Button>
              </div>

              <div className="grid gap-4">
                {userBots.map((bot) => (
                  <Card key={bot.id} className="bg-gray-800/50 border-gray-700 hover:border-gray-600 transition-colors">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-lg flex items-center justify-center">
                            <Bot className="h-6 w-6 text-white" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-white">{bot.name}</h3>
                            <div className="flex items-center space-x-4 mt-1">
                              <Badge className={`${
                                bot.status === 'Active' 
                                  ? 'bg-green-500/20 text-green-400 border-green-500/30' 
                                  : 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
                              }`}>
                                {bot.status}
                              </Badge>
                              <span className="text-sm text-gray-400">
                                Created {new Date(bot.created).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-semibold text-white">{bot.interactions}</div>
                          <div className="text-sm text-gray-400">interactions</div>
                          <div className="flex items-center mt-1">
                            <Star className="h-4 w-4 text-yellow-400 mr-1" />
                            <span className="text-sm text-yellow-400">{bot.rating}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Tokens Tab */}
          <TabsContent value="tokens" className="mt-6">
            <TokenUsageDashboard />
          </TabsContent>

          {/* Subscription Tab */}
          <TabsContent value="subscription" className="mt-6">
            <div className="space-y-6">
              <h2 className="text-xl font-semibold">Subscription Details</h2>

              {/* Current Plan */}
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Crown className="h-5 w-5 mr-2 text-green-400" />
                    Current Plan: Maker
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-gray-700/50 rounded-lg">
                      <div className="text-2xl font-bold text-white">20K</div>
                      <div className="text-sm text-gray-400">Monthly Tokens</div>
                    </div>
                    <div className="text-center p-4 bg-gray-700/50 rounded-lg">
                      <div className="text-2xl font-bold text-white">5</div>
                      <div className="text-sm text-gray-400">Active Bots</div>
                    </div>
                    <div className="text-center p-4 bg-gray-700/50 rounded-lg">
                      <div className="text-2xl font-bold text-white">∞</div>
                      <div className="text-sm text-gray-400">API Calls</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-gray-700">
                    <div>
                      <div className="font-semibold text-white">$29/month</div>
                      <div className="text-sm text-gray-400">Next billing: March 15, 2024</div>
                    </div>
                    <Button variant="outline" className="border-gray-600 hover:bg-gray-700">
                      <Settings className="h-4 w-4 mr-2" />
                      Manage Plan
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Billing History */}
              <Card className="bg-gray-800/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white">Billing History</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[
                      { date: "2024-02-15", amount: "$29.00", status: "Paid" },
                      { date: "2024-01-15", amount: "$29.00", status: "Paid" },
                      { date: "2023-12-15", amount: "$29.00", status: "Paid" },
                    ].map((bill, index) => (
                      <div key={index} className="flex items-center justify-between py-2">
                        <div className="flex items-center space-x-3">
                          <CreditCard className="h-4 w-4 text-gray-400" />
                          <span className="text-white">{bill.date}</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <span className="text-white font-medium">{bill.amount}</span>
                          <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                            <Shield className="h-3 w-3 mr-1" />
                            {bill.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Profile;

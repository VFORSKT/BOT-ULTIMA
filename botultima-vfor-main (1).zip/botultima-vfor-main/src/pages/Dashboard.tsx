
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Bot, Workflow, Settings, User, Home, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useHybridAuth } from "@/components/HybridAuth";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface UserProfile {
  id: string;
  username: string;
  email: string;
  avatar_url?: string;
  bio?: string;
  plan: string;
  role: string;
}

interface Bot {
  id: string;
  name: string;
  description: string;
  category: string;
  created_at: string;
  is_deployed: boolean;
}

interface Workflow {
  id: string;
  name: string;
  description: string;
  category: string;
  created_at: string;
  is_published: boolean;
}

const Dashboard = () => {
  const navigate = useNavigate();
  const { user, loading, isAuthenticated } = useHybridAuth();
  const { toast } = useToast();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [bots, setBots] = useState<Bot[]>([]);
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      navigate('/auth');
      return;
    }
    
    if (user) {
      loadUserData();
    }
  }, [user, loading, isAuthenticated, navigate]);

  const loadUserData = async () => {
    try {
      setLoadingData(true);
      
      // Load user profile using user ID
      const userId = user?.id;
      if (!userId) return;

      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (profileError && profileError.code !== 'PGRST116') {
        console.error('Error loading profile:', profileError);
      } else if (profileData) {
        setProfile(profileData);
      }

      // Load user's bots
      const { data: botsData, error: botsError } = await supabase
        .from('bots')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (botsError) {
        console.error('Error loading bots:', botsError);
      } else {
        setBots(botsData || []);
      }

      // Load user's workflows
      const { data: workflowsData, error: workflowsError } = await supabase
        .from('workflows')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (workflowsError) {
        console.error('Error loading workflows:', workflowsError);
      } else {
        setWorkflows(workflowsData || []);
      }

    } catch (error) {
      console.error('Error loading user data:', error);
      toast({
        title: "Error",
        description: "Failed to load dashboard data",
        variant: "destructive",
      });
    } finally {
      setLoadingData(false);
    }
  };

  if (loading || loadingData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/10 to-gray-900 flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-2 border-green-400 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect in useEffect
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/10 to-gray-900">
      {/* Header */}
      <div className="bg-gray-900/50 border-b border-gray-700 px-4 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              onClick={() => navigate('/')}
              className="text-gray-300 hover:text-green-400"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
            <div className="flex items-center space-x-2">
              <img 
                src="/lovable-uploads/f2491956-759e-4c19-9f30-9178527e8e54.png" 
                alt="SixMorph Logo" 
                className="w-8 h-8" 
              />
              <h1 className="text-2xl font-bold text-white">Dashboard</h1>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Button
              onClick={() => navigate('/profile')}
              variant="outline"
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              <User className="h-4 w-4 mr-2" />
              Profile
            </Button>
            <Button
              onClick={() => navigate('/settings')}
              variant="outline"
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <div className="flex items-center space-x-4 mb-4">
            {profile?.avatar_url && (
              <img
                src={profile.avatar_url}
                alt="Profile"
                className="w-12 h-12 rounded-full border-2 border-green-400"
              />
            )}
            <div>
              <h2 className="text-3xl font-bold text-white">
                Welcome back, {profile?.username || user?.firstName || user?.fullName || 'User'}!
              </h2>
              <p className="text-gray-400">
                {profile?.bio || 'Ready to build something amazing?'}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
              {profile?.plan || 'Free'} Plan
            </Badge>
            <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">
              {bots.length} Bots
            </Badge>
            <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
              {workflows.length} Workflows
            </Badge>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-gray-800/50 border-green-500/30 backdrop-blur-sm hover:bg-gray-800/70 transition-colors cursor-pointer" onClick={() => navigate('/workflows')}>
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Workflow className="h-5 w-5 mr-2 text-green-400" />
                Create Workflow
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 text-sm">
                Build automated workflows with our visual builder
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/50 border-blue-500/30 backdrop-blur-sm hover:bg-gray-800/70 transition-colors cursor-pointer" onClick={() => navigate('/quiz')}>
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Bot className="h-5 w-5 mr-2 text-blue-400" />
                Take Quiz
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 text-sm">
                Get personalized recommendations for your projects
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-800/50 border-purple-500/30 backdrop-blur-sm hover:bg-gray-800/70 transition-colors cursor-pointer" onClick={() => navigate('/profile')}>
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <User className="h-5 w-5 mr-2 text-purple-400" />
                Edit Profile
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 text-sm">
                Update your profile and preferences
              </p>
            </CardContent>
          </Card>
        </div>

        {/* My Bots */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold text-white">My Bots</h3>
            <Button
              onClick={() => navigate('/workflows')}
              className="bg-green-600 hover:bg-green-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Bot
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {bots.length > 0 ? (
              bots.map((bot) => (
                <Card key={bot.id} className="bg-gray-800/50 border-gray-600 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="text-white text-lg">{bot.name}</CardTitle>
                    <Badge className={bot.is_deployed ? "bg-green-500/20 text-green-400" : "bg-gray-500/20 text-gray-400"}>
                      {bot.is_deployed ? 'Deployed' : 'Draft'}
                    </Badge>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-300 text-sm mb-4">{bot.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">
                        {new Date(bot.created_at).toLocaleDateString()}
                      </span>
                      <Button size="sm" variant="outline" className="border-gray-600">
                        Edit
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card className="bg-gray-800/50 border-gray-600 backdrop-blur-sm col-span-full">
                <CardContent className="text-center py-8">
                  <Bot className="h-12 w-12 text-gray-500 mx-auto mb-4" />
                  <p className="text-gray-400">No bots created yet</p>
                  <Button
                    onClick={() => navigate('/workflows')}
                    className="mt-4 bg-green-600 hover:bg-green-700"
                  >
                    Create Your First Bot
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* My Workflows */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold text-white">My Workflows</h3>
            <Button
              onClick={() => navigate('/workflows')}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Workflow
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {workflows.length > 0 ? (
              workflows.map((workflow) => (
                <Card key={workflow.id} className="bg-gray-800/50 border-gray-600 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="text-white text-lg">{workflow.name}</CardTitle>
                    <Badge className={workflow.is_published ? "bg-blue-500/20 text-blue-400" : "bg-gray-500/20 text-gray-400"}>
                      {workflow.is_published ? 'Published' : 'Draft'}
                    </Badge>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-300 text-sm mb-4">{workflow.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">
                        {new Date(workflow.created_at).toLocaleDateString()}
                      </span>
                      <Button size="sm" variant="outline" className="border-gray-600">
                        Edit
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card className="bg-gray-800/50 border-gray-600 backdrop-blur-sm col-span-full">
                <CardContent className="text-center py-8">
                  <Workflow className="h-12 w-12 text-gray-500 mx-auto mb-4" />
                  <p className="text-gray-400">No workflows created yet</p>
                  <Button
                    onClick={() => navigate('/workflows')}
                    className="mt-4 bg-blue-600 hover:bg-blue-700"
                  >
                    Create Your First Workflow
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

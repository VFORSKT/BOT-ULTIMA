
import TokenUsageDashboard from "@/components/TokenUsageDashboard";
import Navigation from "@/components/Navigation";

const TokenUsage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900">
      <Navigation />
      <div className="pt-20 px-6">
        <div className="max-w-7xl mx-auto">
          <TokenUsageDashboard />
        </div>
      </div>
    </div>
  );
};

export default TokenUsage;

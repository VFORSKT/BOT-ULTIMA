
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";

const Login = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // Redirect to the main auth page
    navigate('/auth', { replace: true });
  }, [navigate]);

  return null;
};

export default Login;

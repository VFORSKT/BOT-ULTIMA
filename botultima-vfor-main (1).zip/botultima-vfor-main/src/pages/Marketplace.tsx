
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Bot, 
  Download, 
  Star, 
  Search, 
  Filter, 
  Sparkles,
  Users,
  MessageSquare,
  Briefcase,
  ShoppingCart,
  GraduationCap,
  Heart,
  ChevronLeft
} from "lucide-react";
import Navigation from "@/components/Navigation";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

interface MarketplaceBot {
  id: string;
  name: string;
  description: string;
  category: string;
  downloads: number;
  rating: number;
  price: number;
  creator: string;
  thumbnail: string;
  tags: string[];
  featured: boolean;
}

const Marketplace = () => {
  const [bots, setBots] = useState<MarketplaceBot[]>([]);
  const [filteredBots, setFilteredBots] = useState<MarketplaceBot[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const categories = [
    { id: "all", name: "All Bots", icon: Bot },
    { id: "customer-support", name: "Customer Support", icon: MessageSquare },
    { id: "business", name: "Business", icon: Briefcase },
    { id: "ecommerce", name: "E-commerce", icon: ShoppingCart },
    { id: "education", name: "Education", icon: GraduationCap },
    { id: "entertainment", name: "Entertainment", icon: Heart },
    { id: "productivity", name: "Productivity", icon: Sparkles }
  ];

  // Sample marketplace data
  const sampleBots: MarketplaceBot[] = [
    {
      id: "1",
      name: "AI Customer Support Pro",
      description: "Advanced customer support bot with sentiment analysis and escalation handling",
      category: "customer-support",
      downloads: 1250,
      rating: 4.8,
      price: 0,
      creator: "VFOR Team",
      thumbnail: "/placeholder.svg",
      tags: ["support", "ai", "sentiment"],
      featured: true
    },
    {
      id: "2",
      name: "E-commerce Sales Assistant",
      description: "Boost sales with AI-powered product recommendations and order assistance",
      category: "ecommerce",
      downloads: 890,
      rating: 4.6,
      price: 0,
      creator: "ShopBot Studios",
      thumbnail: "/placeholder.svg",
      tags: ["sales", "recommendations", "orders"],
      featured: true
    },
    {
      id: "3",
      name: "Lead Qualification Bot",
      description: "Automatically qualify and score leads with intelligent conversation flows",
      category: "business",
      downloads: 670,
      rating: 4.7,
      price: 0,
      creator: "BizFlow Labs",
      thumbnail: "/placeholder.svg",
      tags: ["leads", "qualification", "crm"],
      featured: false
    },
    {
      id: "4",
      name: "Educational Quiz Master",
      description: "Interactive educational bot for creating and managing quizzes and assessments",
      category: "education",
      downloads: 540,
      rating: 4.5,
      price: 0,
      creator: "EduTech Pro",
      thumbnail: "/placeholder.svg",
      tags: ["education", "quiz", "assessment"],
      featured: false
    },
    {
      id: "5",
      name: "Task Manager Pro",
      description: "Smart task management with AI-powered scheduling and reminders",
      category: "productivity",
      downloads: 780,
      rating: 4.4,
      price: 0,
      creator: "ProductivityHub",
      thumbnail: "/placeholder.svg",
      tags: ["tasks", "productivity", "reminders"],
      featured: false
    },
    {
      id: "6",
      name: "Entertainment Trivia Bot",
      description: "Fun trivia games and entertainment content for engaging conversations",
      category: "entertainment",
      downloads: 920,
      rating: 4.3,
      price: 0,
      creator: "FunBot Creators",
      thumbnail: "/placeholder.svg",
      tags: ["trivia", "games", "fun"],
      featured: false
    }
  ];

  useEffect(() => {
    const loadBots = async () => {
      setLoading(true);
      try {
        // Load from Supabase first, then fall back to sample data
        const { data: dbBots } = await supabase
          .from('bots')
          .select('*')
          .eq('is_template', true);

        if (dbBots && dbBots.length > 0) {
          const formattedBots = dbBots.map(bot => ({
            id: bot.id,
            name: bot.name,
            description: bot.description || "No description available",
            category: bot.category || "general",
            downloads: bot.downloads || 0,
            rating: bot.rating || 4.0,
            price: 0,
            creator: "Community",
            thumbnail: "/placeholder.svg",
            tags: ["community", "template"],
            featured: false
          }));
          setBots([...sampleBots, ...formattedBots]);
        } else {
          setBots(sampleBots);
        }
      } catch (error) {
        console.error('Error loading marketplace bots:', error);
        setBots(sampleBots);
      } finally {
        setLoading(false);
      }
    };

    loadBots();
  }, []);

  useEffect(() => {
    let filtered = bots;

    if (selectedCategory !== "all") {
      filtered = filtered.filter(bot => bot.category === selectedCategory);
    }

    if (searchTerm) {
      filtered = filtered.filter(bot =>
        bot.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        bot.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        bot.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    setFilteredBots(filtered);
  }, [bots, selectedCategory, searchTerm]);

  const handleInstallBot = async (bot: MarketplaceBot) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        navigate('/auth');
        return;
      }

      // In a real implementation, this would copy the bot template to the user's account
      console.log('Installing bot:', bot.name);
      
      // Update download count
      const updatedBots = bots.map(b => 
        b.id === bot.id ? { ...b, downloads: b.downloads + 1 } : b
      );
      setBots(updatedBots);

      // Navigate to builder with the installed bot
      navigate('/builder');
    } catch (error) {
      console.error('Error installing bot:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900 text-white">
      <Navigation />
      
      <main className="pt-24 pb-12">
        <div className="max-w-7xl mx-auto px-4">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center space-x-4 mb-4">
              <Button 
                variant="ghost" 
                onClick={() => navigate('/dashboard')}
                className="text-gray-400 hover:text-white"
              >
                <ChevronLeft className="h-4 w-4 mr-1" />
                Back to Dashboard
              </Button>
            </div>
            
            <div className="text-center mb-8">
              <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-green-400 to-emerald-300 bg-clip-text text-transparent">
                Bot Marketplace
              </h1>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto">
                Discover, install, and customize pre-built bots created by the VFOR community
              </p>
            </div>

            {/* Search and Filter */}
            <div className="flex flex-col md:flex-row gap-4 max-w-2xl mx-auto">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search bots, categories, or features..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-gray-800/50 border-gray-600 text-white placeholder-gray-400"
                />
              </div>
              <Button variant="outline" className="border-gray-600 text-gray-300 hover:border-green-500/50">
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </Button>
            </div>
          </div>

          {/* Categories */}
          <div className="mb-8">
            <div className="flex flex-wrap gap-3 justify-center">
              {categories.map((category) => {
                const Icon = category.icon;
                return (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? "default" : "outline"}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`${
                      selectedCategory === category.id
                        ? "bg-green-600 hover:bg-green-700 border-green-500"
                        : "border-gray-600 text-gray-300 hover:border-green-500/50"
                    }`}
                  >
                    <Icon className="h-4 w-4 mr-2" />
                    {category.name}
                  </Button>
                );
              })}
            </div>
          </div>

          {/* Featured Bots */}
          {selectedCategory === "all" && (
            <div className="mb-12">
              <h2 className="text-2xl font-bold mb-6 flex items-center">
                <Sparkles className="h-6 w-6 mr-2 text-yellow-400" />
                Featured Bots
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredBots.filter(bot => bot.featured).map((bot) => (
                  <Card key={bot.id} className="bg-gradient-to-br from-gray-900/80 to-gray-800/80 border-yellow-500/30 hover:border-yellow-400/50 transition-all duration-300 transform hover:scale-105">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-12 h-12 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-xl flex items-center justify-center">
                            <Bot className="h-6 w-6 text-white" />
                          </div>
                          <div>
                            <CardTitle className="text-lg text-white">{bot.name}</CardTitle>
                            <p className="text-sm text-gray-400">by {bot.creator}</p>
                          </div>
                        </div>
                        <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                          Featured
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-gray-300 mb-4">
                        {bot.description}
                      </CardDescription>
                      
                      <div className="flex flex-wrap gap-2 mb-4">
                        {bot.tags.map((tag, index) => (
                          <Badge key={index} variant="outline" className="border-gray-600 text-gray-400">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                      
                      <div className="flex items-center justify-between text-sm text-gray-400 mb-4">
                        <div className="flex items-center space-x-1">
                          <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          <span>{bot.rating}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Download className="h-4 w-4" />
                          <span>{bot.downloads.toLocaleString()}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Users className="h-4 w-4" />
                          <span>Free</span>
                        </div>
                      </div>
                      
                      <Button 
                        onClick={() => handleInstallBot(bot)}
                        className="w-full bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700"
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Install Bot
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* All Bots */}
          <div>
            <h2 className="text-2xl font-bold mb-6">
              {selectedCategory === "all" ? "All Bots" : categories.find(c => c.id === selectedCategory)?.name}
              <span className="text-gray-400 text-lg ml-2">({filteredBots.length})</span>
            </h2>
            
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <Card key={i} className="bg-gray-900/50 border-gray-800/50 animate-pulse">
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-12 h-12 bg-gray-700 rounded-xl"></div>
                          <div className="space-y-2 flex-1">
                            <div className="h-4 bg-gray-700 rounded w-3/4"></div>
                            <div className="h-3 bg-gray-700 rounded w-1/2"></div>
                          </div>
                        </div>
                        <div className="h-3 bg-gray-700 rounded"></div>
                        <div className="h-3 bg-gray-700 rounded w-5/6"></div>
                        <div className="h-10 bg-gray-700 rounded"></div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredBots.filter(bot => selectedCategory === "all" || !bot.featured).map((bot) => (
                  <Card key={bot.id} className="bg-gray-900/50 border-gray-800/50 hover:border-green-500/30 transition-all duration-300 transform hover:scale-105">
                    <CardHeader>
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
                          <Bot className="h-6 w-6 text-white" />
                        </div>
                        <div>
                          <CardTitle className="text-lg text-white">{bot.name}</CardTitle>
                          <p className="text-sm text-gray-400">by {bot.creator}</p>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-gray-300 mb-4">
                        {bot.description}
                      </CardDescription>
                      
                      <div className="flex flex-wrap gap-2 mb-4">
                        {bot.tags.map((tag, index) => (
                          <Badge key={index} variant="outline" className="border-gray-600 text-gray-400">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                      
                      <div className="flex items-center justify-between text-sm text-gray-400 mb-4">
                        <div className="flex items-center space-x-1">
                          <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          <span>{bot.rating}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Download className="h-4 w-4" />
                          <span>{bot.downloads.toLocaleString()}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Users className="h-4 w-4" />
                          <span>Free</span>
                        </div>
                      </div>
                      
                      <Button 
                        onClick={() => handleInstallBot(bot)}
                        className="w-full bg-green-600 hover:bg-green-700"
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Install Bot
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {!loading && filteredBots.length === 0 && (
              <div className="text-center py-12">
                <Bot className="h-16 w-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-400 mb-2">No bots found</h3>
                <p className="text-gray-500">Try adjusting your search or category filters</p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Marketplace;

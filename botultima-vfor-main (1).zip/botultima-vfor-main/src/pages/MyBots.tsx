
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Bot, 
  Plus, 
  Search, 
  Filter, 
  Eye, 
  Edit, 
  Trash2, 
  Play, 
  Pause, 
  Settings,
  BarChart3,
  Calendar,
  Star
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import Navigation from "@/components/Navigation";

const MyBots = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const navigate = useNavigate();

  // Sample bot data - in real app this would come from database
  const [bots, setBots] = useState([
    {
      id: 1,
      name: "Customer Support Bot",
      description: "Handles customer inquiries and support tickets automatically",
      status: "active",
      platform: "Telegram",
      interactions: 1245,
      lastActive: "2 minutes ago",
      created: "2024-01-15",
      rating: 4.8,
      avatar: "🤖"
    },
    {
      id: 2,
      name: "Lead Generator",
      description: "Qualifies leads and schedules meetings with potential clients",
      status: "draft",
      platform: "WhatsApp",
      interactions: 0,
      lastActive: "Never",
      created: "2024-02-01",
      rating: 0,
      avatar: "💼"
    },
    {
      id: 3,
      name: "FAQ Helper",
      description: "Answers frequently asked questions about our products",
      status: "active",
      platform: "Discord",
      interactions: 890,
      lastActive: "1 hour ago",
      created: "2024-01-20",
      rating: 4.9,
      avatar: "❓"
    },
    {
      id: 4,
      name: "Order Tracker",
      description: "Helps customers track their orders and delivery status",
      status: "paused",
      platform: "Telegram",
      interactions: 567,
      lastActive: "3 days ago",
      created: "2024-01-10",
      rating: 4.5,
      avatar: "📦"
    }
  ]);

  const filteredBots = bots.filter(bot => {
    const matchesSearch = bot.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         bot.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === "all" || bot.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500/20 text-green-400 border-green-500/30";
      case "draft":
        return "bg-gray-500/20 text-gray-400 border-gray-500/30";
      case "paused":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30";
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/30";
    }
  };

  const handleToggleStatus = (botId: number) => {
    setBots(bots.map(bot => {
      if (bot.id === botId) {
        const newStatus = bot.status === "active" ? "paused" : "active";
        return { ...bot, status: newStatus };
      }
      return bot;
    }));
  };

  const handleDeleteBot = (botId: number) => {
    setBots(bots.filter(bot => bot.id !== botId));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/20 to-gray-900">
      <Navigation />
      
      <div className="pt-20 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-white mb-2">My Bots</h1>
                <p className="text-gray-400">Manage and monitor your AI bots</p>
              </div>
              <Button 
                className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                onClick={() => navigate('/builder')}
              >
                <Plus className="h-5 w-5 mr-2" />
                Create New Bot
              </Button>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="bg-gray-900/50 border-gray-800/50">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Total Bots</p>
                    <p className="text-2xl font-bold text-white">{bots.length}</p>
                  </div>
                  <Bot className="h-8 w-8 text-green-400" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-900/50 border-gray-800/50">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Active Bots</p>
                    <p className="text-2xl font-bold text-white">
                      {bots.filter(bot => bot.status === "active").length}
                    </p>
                  </div>
                  <Play className="h-8 w-8 text-blue-400" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-900/50 border-gray-800/50">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Total Interactions</p>
                    <p className="text-2xl font-bold text-white">
                      {bots.reduce((sum, bot) => sum + bot.interactions, 0).toLocaleString()}
                    </p>
                  </div>
                  <BarChart3 className="h-8 w-8 text-purple-400" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-900/50 border-gray-800/50">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Avg Rating</p>
                    <p className="text-2xl font-bold text-white">
                      {(bots.reduce((sum, bot) => sum + bot.rating, 0) / bots.length).toFixed(1)}
                    </p>
                  </div>
                  <Star className="h-8 w-8 text-yellow-400" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Search and Filter */}
          <div className="flex items-center space-x-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search bots..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-gray-800/50 border-gray-700 text-white"
              />
            </div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="bg-gray-800/50 border border-gray-700 text-white rounded-md px-3 py-2"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="draft">Draft</option>
              <option value="paused">Paused</option>
            </select>
          </div>

          {/* Bots Grid */}
          <div className="grid gap-6">
            {filteredBots.map((bot) => (
              <Card key={bot.id} className="bg-gray-900/50 border-gray-800/50 hover:border-green-500/30 transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-lg flex items-center justify-center text-2xl">
                        {bot.avatar}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="text-xl font-semibold text-white">{bot.name}</h3>
                          <Badge className={getStatusColor(bot.status)}>
                            {bot.status}
                          </Badge>
                        </div>
                        <p className="text-gray-400 mb-2">{bot.description}</p>
                        <div className="flex items-center space-x-6 text-sm text-gray-300">
                          <span>Platform: {bot.platform}</span>
                          <span>Interactions: {bot.interactions.toLocaleString()}</span>
                          <span>Last Active: {bot.lastActive}</span>
                          <span className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-400 mr-1" />
                            {bot.rating || "No rating"}
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-gray-600 hover:border-green-500/50"
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-gray-600 hover:border-blue-500/50"
                        onClick={() => navigate('/builder')}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-gray-600 hover:border-yellow-500/50"
                        onClick={() => handleToggleStatus(bot.id)}
                      >
                        {bot.status === "active" ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-gray-600 hover:border-red-500/50"
                        onClick={() => handleDeleteBot(bot.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredBots.length === 0 && (
            <div className="text-center py-12">
              <Bot className="h-16 w-16 text-gray-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-400 mb-4">No bots found</h3>
              <p className="text-gray-500 mb-6">
                {searchTerm || filterStatus !== "all" 
                  ? "Try adjusting your search or filter" 
                  : "Create your first bot to get started"
                }
              </p>
              <Button 
                onClick={() => navigate('/builder')}
                className="bg-green-600 hover:bg-green-700"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create New Bot
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MyBots;

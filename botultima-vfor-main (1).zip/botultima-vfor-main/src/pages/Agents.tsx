import { useState, useCallback, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Bot, 
  Settings, 
  Plus,
  ChevronLeft,
  Send,
  History,
  Lightbulb,
  Brain
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Node, Edge } from '@xyflow/react';
import { ReactFlowProvider } from '@xyflow/react';
import WorkflowCanvas from "@/components/workflow/WorkflowCanvas";
import NodePalette from "@/components/workflow/NodePalette";
import InspectorPanel from "@/components/workflow/InspectorPanel";
import IntegrationsPanel from "@/components/workflow/IntegrationsPanel";
import TutorialPopup from "@/components/workflow/TutorialPopup";
import { WorkflowNodeData } from "@/types/WorkflowTypes";
import Navigation from "@/components/Navigation";

const Agents = () => {
  const [selectedNode, setSelectedNode] = useState<Node<WorkflowNodeData> | null>(null);
  const [nodes, setNodes] = useState<Node<WorkflowNodeData>[]>([]);
  const [edges, setEdges] = useState<Edge[]>([]);
  const [showTutorial, setShowTutorial] = useState(false);
  const navigate = useNavigate();

  // Check if this is the user's first time with agents
  useEffect(() => {
    const hasSeenAgentTutorial = localStorage.getItem('botultima_agent_tutorial_seen');
    if (!hasSeenAgentTutorial) {
      setShowTutorial(true);
    }
  }, []);

  const onDragStart = useCallback((event: React.DragEvent, nodeType: string) => {
    event.dataTransfer.setData('application/reactflow', nodeType);
    event.dataTransfer.effectAllowed = 'move';
  }, []);

  const handleSaveAgent = useCallback((nodes: Node<WorkflowNodeData>[], edges: Edge[]) => {
    setNodes(nodes);
    setEdges(edges);
    console.log('Saving agent workflow:', { nodes, edges });
  }, []);

  const handleNodeSelect = useCallback((node: Node<WorkflowNodeData> | null) => {
    setSelectedNode(node);
  }, []);

  const handleUpdateNode = useCallback((nodeId: string, updates: Partial<WorkflowNodeData>) => {
    setNodes(prev => prev.map(node => 
      node.id === nodeId 
        ? { ...node, data: { ...node.data, ...updates } }
        : node
    ));
  }, []);

  const handleTutorialClose = () => {
    setShowTutorial(false);
    localStorage.setItem('botultima_agent_tutorial_seen', 'true');
  };

  const handleTryFlow = () => {
    // Load example agent workflow: Email → Extract → Store in Airtable
    const exampleNodes: Node<WorkflowNodeData>[] = [
      {
        id: 'trigger-agent',
        type: 'workflowNode',
        position: { x: 250, y: 50 },
        data: {
          label: 'Email Trigger',
          type: 'trigger',
          category: 'ai',
          config: {},
        },
      },
      {
        id: 'gmail-agent',
        type: 'workflowNode',
        position: { x: 250, y: 150 },
        data: {
          label: 'Read Email',
          type: 'gmail',
          category: 'action',
          config: {
            apiKey: 'gmail_api_key_placeholder',
          },
        },
      },
      {
        id: 'gpt-extract',
        type: 'workflowNode',
        position: { x: 250, y: 250 },
        data: {
          label: 'Extract Data',
          type: 'gpt',
          category: 'ai',
          config: {
            prompt: 'Extract customer name, email, and issue from this email content',
          },
        },
      },
      {
        id: 'airtable-store',
        type: 'workflowNode',
        position: { x: 250, y: 350 },
        data: {
          label: 'Store in Airtable',
          type: 'airtable',
          category: 'action',
          config: {
            apiKey: 'airtable_api_key_placeholder',
          },
        },
      },
    ];

    const exampleEdges: Edge[] = [
      { id: 'e1', source: 'trigger-agent', target: 'gmail-agent' },
      { id: 'e2', source: 'gmail-agent', target: 'gpt-extract' },
      { id: 'e3', source: 'gpt-extract', target: 'airtable-store' },
    ];

    setNodes(exampleNodes);
    setEdges(exampleEdges);
    setShowTutorial(false);
    localStorage.setItem('botultima_agent_tutorial_seen', 'true');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900/20 to-gray-900 text-white">
      <Navigation />
      
      <ReactFlowProvider>
        <div className="pt-20 min-h-screen flex">
          {/* Tutorial Popup */}
          <TutorialPopup 
            isOpen={showTutorial}
            onClose={handleTutorialClose}
            onTryFlow={handleTryFlow}
          />

          {/* Left Sidebar */}
          <div className="w-80 bg-gray-800/50 border-r border-gray-700 flex flex-col">
            {/* Header */}
            <div className="p-4 border-b border-gray-700">
              <div className="flex items-center justify-between mb-4">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => navigate('/dashboard')}
                  className="text-gray-400 hover:text-white"
                >
                  <ChevronLeft className="h-4 w-4 mr-1" />
                  Back
                </Button>
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline" className="bg-gray-700 border-gray-600 text-white hover:bg-gray-600">
                    <History className="h-4 w-4 mr-1" />
                    Versions
                  </Button>
                </div>
              </div>
              <h1 className="text-xl font-bold">AI Agent Creator</h1>
              <p className="text-gray-400 text-sm">Build intelligent automation agents</p>
            </div>

            {/* Tabs */}
            <Tabs defaultValue="nodes" className="flex-1 flex flex-col">
              <TabsList className="grid w-full grid-cols-3 bg-gray-700/50 m-4">
                <TabsTrigger value="nodes">Blocks</TabsTrigger>
                <TabsTrigger value="integrations">Integrations</TabsTrigger>
                <TabsTrigger value="templates">Templates</TabsTrigger>
              </TabsList>

              <TabsContent value="nodes" className="flex-1 p-4 space-y-4">
                <NodePalette onDragStart={onDragStart} />

                {/* Agent Templates */}
                <div className="border-t border-gray-700 pt-4">
                  <h3 className="text-sm font-semibold mb-3 text-gray-300 flex items-center">
                    <Brain className="h-4 w-4 mr-2" />
                    Agent Templates
                  </h3>
                  <div className="space-y-2">
                    {[
                      "Email → Extract → Airtable",
                      "Telegram → Analyze → Notion",
                      "API → Process → Gmail Reply",
                      "Document → Summarize → Store"
                    ].map((template, index) => (
                      <div 
                        key={index}
                        className="p-2 bg-purple-500/10 border border-purple-500/20 rounded text-xs text-purple-300 cursor-pointer hover:bg-purple-500/20"
                      >
                        {template}
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="integrations" className="flex-1 p-4">
                <IntegrationsPanel />
              </TabsContent>

              <TabsContent value="templates" className="flex-1 p-4">
                <div className="space-y-4">
                  <h3 className="text-sm font-semibold text-gray-300">Popular Agent Templates</h3>
                  <div className="space-y-3">
                    {[
                      { name: "Customer Support Agent", desc: "Auto-respond to support emails" },
                      { name: "Lead Qualifier", desc: "Extract and score leads from forms" },
                      { name: "Content Moderator", desc: "Review and filter user content" },
                      { name: "Data Processor", desc: "Transform and store incoming data" }
                    ].map((template, index) => (
                      <div key={index} className="p-3 bg-gray-700/50 rounded border border-gray-600 cursor-pointer hover:border-purple-500">
                        <h4 className="font-medium text-white">{template.name}</h4>
                        <p className="text-xs text-gray-400">{template.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Main Canvas Area */}
          <div className="flex-1 flex flex-col">
            {/* Top Toolbar */}
            <div className="h-14 bg-gray-800/50 border-b border-gray-700 flex items-center justify-between px-6">
              <div className="flex items-center space-x-4">
                <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                  <Brain className="h-3 w-3 mr-1" />
                  AI Agent
                </Badge>
                <span className="text-sm text-gray-400">{nodes.length} blocks, {edges.length} connections</span>
              </div>
              <div className="flex items-center space-x-2">
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setShowTutorial(true)}
                >
                  <Lightbulb className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Settings className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Canvas */}
            <div className="flex-1 flex">
              <div className="flex-1">
                <WorkflowCanvas 
                  onSave={handleSaveAgent}
                  initialNodes={nodes}
                  initialEdges={edges}
                  onNodeSelect={handleNodeSelect}
                  selectedNode={selectedNode}
                  onUpdateNode={handleUpdateNode}
                />
              </div>
              
              {/* Right Inspector Panel */}
              <div className="w-80 border-l border-gray-700">
                <InspectorPanel 
                  selectedNode={selectedNode}
                  onUpdateNode={handleUpdateNode}
                />
              </div>
            </div>
          </div>
        </div>
      </ReactFlowProvider>
    </div>
  );
};

export default Agents;

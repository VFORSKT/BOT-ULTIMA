
import { Node, Edge } from '@xyflow/react';

export interface WorkflowNodeData extends Record<string, unknown> {
  label: string;
  type: 'trigger' | 'gpt' | 'qwen' | 'deepseek' | 'mixtral' | 'text-classifier' | 'sentiment-analysis' | 
        'information-extractor' | 'summarization' | 'ai-transform' | 'gmail' | 'telegram' | 'notion' | 
        'discord' | 'slack' | 'airtable' | 'google-sheets' | 'whatsapp' | 'ai-data-transform' | 
        'code' | 'edit-fields' | 'date-time' | 'filter-data' | 'split-join' | 'remove-duplicates' |
        'condition' | 'merge' | 'loop' | 'compare' | 'throw-error' | 'sub-workflow' | 'webhook' |
        'execute-code' | 'http-request' | 'store-db' | 'log-supabase' | 'variables' | 'wait-approval' |
        'decision-email' | 'pause-user' | 'api' | 'reply' | 'end' | 'upload' | 'download' | 'docs' | 'agent' |
        'google-sheets-reader' | 'discord-webhook' | 'custom-code-runner' | 'mysql-db' | 'postgresql-db' |
        'mongodb' | 'email-sender' | 'sms-sender' | 'file-processor' | 'image-processor' | 'csv-parser' |
        'json-validator' | 'xml-parser' | 'pdf-generator' | 'scheduler' | 'timer';
  category: 'ai' | 'action' | 'transformation' | 'flow-control' | 'core' | 'human-loop' | 'basic' | 'database' | 'communication';
  config?: {
    prompt?: string;
    apiUrl?: string;
    apiKey?: string;
    conditions?: string;
    content?: string;
    model?: string;
    memory?: string;
    tools?: string[];
    temperature?: number;
    maxTokens?: number;
    fields?: string[];
    dateFormat?: string;
    filterCondition?: string;
    batchSize?: number;
    errorMessage?: string;
    webhookUrl?: string;
    method?: string;
    requestHeaders?: string;
    payload?: string;
    tableName?: string;
    logLevel?: string;
    variableName?: string;
    variableValue?: string;
    approvalMessage?: string;
    approvalType?: 'telegram' | 'email' | 'slack';
    pauseDuration?: number;
    
    // Database specific
    connectionString?: string;
    host?: string;
    port?: number;
    database?: string;
    username?: string;
    password?: string;
    query?: string;
    
    // Email specific
    smtpHost?: string;
    smtpPort?: number;
    smtpUsername?: string;
    smtpPassword?: string;
    fromEmail?: string;
    toEmail?: string;
    subject?: string;
    emailBody?: string;
    
    // Google Sheets Reader specific
    spreadsheetId?: string;
    range?: string;
    useHeaders?: boolean;
    
    // Discord Webhook specific
    botUsername?: string;
    avatarUrl?: string;
    embedTitle?: string;
    embedDescription?: string;
    
    // Custom Code Runner specific
    jsCode?: string;
    testInput?: string;
    
    // File processing
    fileFormat?: string;
    outputFormat?: string;
    processingOptions?: Record<string, any>;
    
    [key: string]: any;
  };
  isExecuting?: boolean;
  executionResult?: {
    success: boolean;
    output?: string;
    error?: string;
  };
  validationErrors?: string[];
  isValid?: boolean;
}

export type WorkflowNode = Node<WorkflowNodeData>;
export type WorkflowEdge = Edge;

export interface SerializedFlowData {
  nodes: {
    id: string;
    type: string;
    position: { x: number; y: number };
    data: {
      label: string;
      type: string;
      category: string;
      config: Record<string, any>;
      isExecuting?: boolean;
      executionResult?: {
        success: boolean;
        output?: string;
        error?: string;
      } | null;
    };
  }[];
  edges: {
    id: string;
    source: string;
    target: string;
    type?: string;
    label?: string | null;
    animated?: boolean;
  }[];
  timestamp: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

export interface SimulationState {
  isRunning: boolean;
  currentNodeId?: string;
  executionLog: {
    nodeId: string;
    timestamp: Date;
    status: 'success' | 'error' | 'running' | 'info';
    message: string;
    data?: any;
  }[];
}


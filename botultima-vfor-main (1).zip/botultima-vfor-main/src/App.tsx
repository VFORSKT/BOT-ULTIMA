
import { Suspense, lazy } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "@/components/AuthenticationManager";
import { ClerkAuthProvider } from "@/components/ClerkAuthProvider";
import { HybridAuthWrapper } from "@/components/HybridAuthWrapper";
import ErrorBoundary from "@/components/ErrorBoundary";

// Lazy load components
const Index = lazy(() => import("./pages/Index"));
const Auth = lazy(() => import("./pages/Auth"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const Profile = lazy(() => import("./pages/Profile"));
const Settings = lazy(() => import("./pages/Settings"));
const WorkflowAutomation = lazy(() => import("./pages/WorkflowAutomation"));
const Pricing = lazy(() => import("./pages/Pricing"));
const Quiz = lazy(() => import("./pages/Quiz"));

const queryClient = new QueryClient();

// Protected Route Component
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, loading } = useAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/10 to-gray-900 flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-2 border-green-400 border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  if (!user) {
    return <Navigate to="/auth" replace />;
  }
  
  return <>{children}</>;
};

// Public Route Component
const PublicRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, loading } = useAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/10 to-gray-900 flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-2 border-green-400 border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  return <>{children}</>;
};

const LoadingFallback = () => (
  <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900/10 to-gray-900 flex items-center justify-center">
    <div className="animate-spin h-8 w-8 border-2 border-green-400 border-t-transparent rounded-full"></div>
  </div>
);

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <ClerkAuthProvider>
        <AuthProvider>
          <TooltipProvider>
            <ErrorBoundary>
              <Toaster />
              <Sonner />
              <BrowserRouter>
                <Suspense fallback={<LoadingFallback />}>
                  <Routes>
                    <Route 
                      path="/" 
                      element={<Index />} 
                    />
                    <Route 
                      path="/auth" 
                      element={
                        <PublicRoute>
                          <Auth />
                        </PublicRoute>
                      } 
                    />
                    <Route 
                      path="/quiz" 
                      element={
                        <HybridAuthWrapper>
                          <Quiz />
                        </HybridAuthWrapper>
                      } 
                    />
                    <Route 
                      path="/pricing" 
                      element={<Pricing />} 
                    />
                    <Route 
                      path="/dashboard" 
                      element={
                        <HybridAuthWrapper>
                          <Dashboard />
                        </HybridAuthWrapper>
                      } 
                    />
                    <Route 
                      path="/profile" 
                      element={
                        <HybridAuthWrapper>
                          <Profile />
                        </HybridAuthWrapper>
                      } 
                    />
                    <Route 
                      path="/settings" 
                      element={
                        <HybridAuthWrapper>
                          <Settings />
                        </HybridAuthWrapper>
                      } 
                    />
                    <Route 
                      path="/workflows" 
                      element={
                        <HybridAuthWrapper>
                          <WorkflowAutomation />
                        </HybridAuthWrapper>
                      } 
                    />
                    <Route path="*" element={<Navigate to="/" replace />} />
                  </Routes>
                </Suspense>
              </BrowserRouter>
            </ErrorBoundary>
          </TooltipProvider>
        </AuthProvider>
      </ClerkAuthProvider>
    </QueryClientProvider>
  );
};

export default App;
